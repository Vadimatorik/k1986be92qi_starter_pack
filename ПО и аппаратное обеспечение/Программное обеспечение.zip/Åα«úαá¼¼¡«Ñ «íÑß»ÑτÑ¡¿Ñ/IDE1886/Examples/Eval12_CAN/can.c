#include "can.h"

void Send_Frame(char box,uns32 ID, char DLC, char R1,char R0, char RTR, char SSR, char IDE,
                char DB0,char DB1,char DB2,char DB3,char DB4,char DB5,char DB6, char DB7)
{
Init_Frame(box, ID, DLC, R1, R0, RTR, SSR, IDE, DB0, DB1, DB2, DB3, DB4, DB5, DB6, DB7);
Transmit_Frame(box);
Wait_Transmit_Frame(box);
}

void Transmit_Frame(char box)
{
	CAN_BSR = box & 0x07;
	CAN_RXCS = 0;
	CAN_CS = 1;
	CAN_TXCS = 0x08;
}

void Wait_Transmit_Frame(char box)
{
	CAN_BSR = box & 0x07;
	while(!TXBIF){
	}
	CAN_RXCS = 0;
	CAN_TXCS = 0;
	CAN_CS = 0;
}

void Init_Frame(char box,uns32 ID, char DLC, char R1,char R0, char RTR, char SSR, char IDE,
                char DB0,char DB1,char DB2,char DB3,char DB4,char DB5,char DB6, char DB7)
{
    char TEMP_BUF=0;
    CAN_BSR = box & 0x07;
	CAN_RXCS = 0;
	CAN_TXCS = 0;
	CAN_CS = 0;

	CAN_DB0 = DB0;
	CAN_DB1 = DB1;
 	CAN_DB2 = DB2;
	CAN_DB3 = DB3;
	CAN_DB4 = DB4;
	CAN_DB5 = DB5;
	CAN_DB6 = DB6;
	CAN_DB7 = DB7;
//	CAN_DLC = (DLC & 0x0F) | ((RTR & 0x01)<<6) | ((R1 & 0x01)<<5) |((R0 & 0x01)<<4) ;
    CAN_DLC = DLC & 0x0F;
    CAN_DLC |=(RTR & 0x01)<<6;
    CAN_DLC |=(R1 & 0x01)<<5;
    CAN_DLC |=(R0 & 0x01)<<4;

    CAN_ID0=0;
    CAN_ID1=0;
    CAN_ID2=0;
    CAN_ID3=0;
    char TMP1=0;
	if (IDE > 0x00)
	{
//------------------------------------------------------------------------------                    
    CAN_ID3 = ID;
    CAN_ID2 = ID >> 8;
//    CAN_ID1 = ((ID >> 16) & 0x03)|((ID >> 13) & 0xE0)|((SSR & 0x01) << 4)|0x08;
    CAN_ID0 = ID >> 21;
    CAN_ID1 = ID >> 16;
    CAN_ID1 = (CAN_ID1 << 3) & 0xE0;
    CAN_ID1 |= (IDE & 0x01) << 3;  //��������� ��� EID_EN
    CAN_ID1 |= (SSR & 0x01) << 4;  //��������� ��� SSR
    TMP1 = ID >> 16;
    TMP1 &= 0x03;
    CAN_ID1 |= TMP1;
    
//------------------------------------------------------------------------------	
	}
	else
	{
    CAN_ID0 = ID>>3;
//-----------------------------    
//	CAN_ID1 = ( (((ID & 0x07) << 5) & 0xE0) | ((SSR & 0x01) << 4) | ((IDE & 0x01) << 3));
//-----------------------------
    TEMP_BUF = ID & 0x07;
    TEMP_BUF = (TEMP_BUF << 5) & 0xE0;
    CAN_ID1 |= TEMP_BUF;
     TEMP_BUF = (SSR & 0x01)<<4;
    CAN_ID1 |= TEMP_BUF;
     TEMP_BUF = (IDE & 0x01)<<3;
    CAN_ID1 |= TEMP_BUF;
//-----------------------------
	}
}

void SetSpeed(char BRP,char PSEG, char SEG1, char SEG2, char SJW, char SAM)
{   char TEMP_BUF;
//	CAN_BRG1 = (BRP & 0x3F) | ((SJW & 0x03) << 6);
//-----------------------------
    CAN_BRG1 = BRP & 0x3F;
    TEMP_BUF = (SJW & 0x03)<<6;
    CAN_BRG1 |= TEMP_BUF;
//-----------------------------    
//	CAN_BRG2 = (PSEG & 0x07) | ((SEG1 & 0x07) <<3) | ((SAM & 0x01)<<6);
//-----------------------------
    CAN_BRG2 = PSEG & 0x07;
    TEMP_BUF = (SEG1 & 0x07)<<3;
    CAN_BRG2 |= TEMP_BUF;
    TEMP_BUF = (SAM & 0x01)<<6;
    CAN_BRG2 |= TEMP_BUF;
//-----------------------------    
	CAN_BRG3 = SEG2 & 0x07;
}

/*void Rec_Frame(char box,uns32* ID, char* DLC, char* R1,char* R0, char* RTR, char* SSR, char* IDE,
                char* DB0,char* DB1,char* DB2,char* DB3,char* DB4,char* DB5,char* DB6, char* DB7)
{
Reciv_Frame(box,0);
Wait_Reciv_Frame(box);
Get_Frame(box,ID,DLC, R1,R0,RTR,SSR,IDE,DB0,DB1,DB2,DB3,DB4,DB5,DB6,DB7);
}

void Reciv_Frame(char box, char MASK)
{
	CAN_BSR = box & 0x07;
	CAN_RXCS = 0;
	CAN_RXCS = MASK & 0x07;
	CAN_CS = 3;
}

void Wait_Reciv_Frame (char box)
{
	CAN_BSR = box & 0x07;
	while (!RXFULL) {}
}

void Get_Frame(char box,uns32* ID, char* DLC, char* R1,char* R0, char* RTR, char* SSR, char* IDE,
                char* DB0,char* DB1,char* DB2,char* DB3,char* DB4,char* DB5,char* DB6, char* DB7)
{
    uns32 TEMP1=0;            
    char T1=0;
	CAN_BSR = box & 0x07;
	
	if ( ((CAN_ID1 & 0x08) >> 3) == 1)
	{
//	*ID =  ((uns32)CAN_ID0 << 21)|(((uns32)CAN_ID1 & 0x03) <<16)|(((uns32)CAN_ID1 & 0xE0) <<13)|((uns32)CAN_ID2 <<8)|((uns32)CAN_ID3);

    TEMP1 = CAN_ID0;                    //---0_0000 0000_0000 0000_0000 xxxx_xxxx
    TEMP1 = TEMP1 << 8;                 //---0_0000 0000_0000 xxxx_xxxx 0000_0000
    T1 = CAN_ID1 & 0xE0;                //xxx0_0000
    TEMP1 |= T1;                        //---0_0000 0000_0000 xxxx_xxxx xxx0_0000
    TEMP1 = TEMP1 << 3;                 //---0_0000 0000_0xxx xxxx_xxxx 0000_0000
    T1 = CAN_ID1 & 0x03;                //0000_00xx
    T1 = T1 << 6;                       //xx00_0000
    TEMP1 |= T1;                        //---0_0000 0000_0xxx xxxx_xxxx xx00_0000
    TEMP1 = TEMP1 << 2;                 //---0_0000 000x_xxxx xxxx_xxxx 0000_0000
    TEMP1 |= CAN_ID2;                   //---0_0000 000x_xxxx xxxx_xxxx xxxx_xxxx
    TEMP1 = TEMP1 << 8;                 //---x_xxxx xxxx_xxxx xxxx_xxxx 0000_0000
    TEMP1 |= CAN_ID3;                   //---x_xxxx xxxx_xxxx xxxx_xxxx xxxx_xxxx
    *ID = TEMP1;
    }
    else
    {
//	*ID =  ((uns32)CAN_ID0 << 3) | ((uns32)CAN_ID1 & 0xE0);
    TEMP1 = CAN_ID0;
    TEMP1 = TEMP1 << 3;
    T1 = (CAN_ID1 & 0xE0) >>5;
    TEMP1 |= T1;
    *ID = TEMP1;
    }
	*SSR = (CAN_ID1 & 0x10) >> 4;
	*IDE = (CAN_ID1 & 0x08) >> 3;
	*RTR = (CAN_DLC & 0x40) >> 6;
	*R1 =  (CAN_DLC & 0x20) >> 5;
	*R0 =  (CAN_DLC & 0x10) >> 4;
	*DLC =  (CAN_DLC & 0x0F);

    *DB0 = CAN_DB0;
    *DB1 = CAN_DB1;
    *DB2 = CAN_DB2;
    *DB3 = CAN_DB3;
    *DB4 = CAN_DB4;
    *DB5 = CAN_DB5;
    *DB6 = CAN_DB6;
    *DB7 = CAN_DB7;
    
	CAN_RXCS = 0;
	CAN_TXCS = 0;
	CAN_CS = 0;
}
*/
void Set_Filter (char fil, uns32 Mask, uns32 Filter, char IDE, char SSR, char EIDE, char ESSR)
{
    char TEMP_BUF=0; 
	CAN_BSR = (fil & 0x01)<<4;  //���������� 0-����� ��������� � ������� 1 ��� 2 ����� � ������.
	
	if (IDE > 0x00)
	{
//-----------------------------
	CAN_FILTER_HH = Filter >> 24;
//-----------------------------
    CAN_FILTER_HL = Filter >> 16;
//-----------------------------
    CAN_FILTER_LH = Filter >> 8;                   
//-----------------------------
	CAN_FILTER_LL = Filter;
//-----------------------------
    CAN_MASK_HH = Mask >> 24;
//-----------------------------
    CAN_MASK_HL = Mask >> 16;
//-----------------------------
    CAN_MASK_LH = Mask >> 8;
//-----------------------------
    CAN_MASK_LL = Mask;                           
	}
	else
	{
//-----------------------------
    CAN_FILTER_HH = Filter >> 3;
//-----------------------------	
//	CAN_FILTER_HL = ( (((Filter & 0x07) << 5) & 0xE0) | ((IDE & 0x01) << 3));
//-----------------------------
    CAN_FILTER_HL = Filter & 0x07;
    CAN_FILTER_HL = CAN_FILTER_HL << 5;
    CAN_FILTER_HL &= 0xE0;
    TEMP_BUF = (SSR & 0x01) << 4;
    CAN_FILTER_HL |= TEMP_BUF;
    TEMP_BUF = (IDE & 0x01) << 3;
    CAN_FILTER_HL |= TEMP_BUF;    
//-----------------------------
	CAN_FILTER_LH = 0x00;
	CAN_FILTER_LL = 0x00;

    CAN_MASK_HH = Mask >> 3;
//-----------------------------
//	CAN_MASK_HL = ( (((Mask & 0x07) << 5) & 0xE0) | ((EIDE & 0x01) << 3));
//-----------------------------
    CAN_MASK_HL = Mask & 0x07;
    CAN_MASK_HL = CAN_MASK_HL << 5;
    CAN_MASK_HL &= 0xE0;
    TEMP_BUF = (EIDE & 0x01) << 3;
    CAN_MASK_HL |= TEMP_BUF;
    TEMP_BUF = (ESSR & 0x01) << 4;
    CAN_MASK_HL |= TEMP_BUF;
//-----------------------------
	CAN_MASK_LH = 0x00;
	CAN_MASK_LL = 0x00;
	}
}
/*
char Wait_Any_Reciv_Frame()
{
char i;
	do
	{
	CAN_BSR = i;
	if (i==5) i=0;
	else i=i+1;
	}
	while (!RXFULL);

if (i==0) i=5;
else i=i-1;

return i;
}

char Wait_Any_Transmit_Frame()
{
char i;
	do
	{
	CAN_BSR = i;
	if (i==5) i=0;
	else i=i+1;
	}
	while (!TXBIF);

if (i==0) i=5;
else i=i-1;

return i;
}
*/
void Init_USART(char BRG, char SYNC, char TXEN, char CREN, char SREN, char CSRC, char RX9, char TX9)
{
char TEMP_BUF1=0,TEMP_BUF2=0;     
RCSTA = 0;
SPBRG = BRG;
//TXSTA = ((CSRC & 0x01) << 7) | ((TX9 & 0x01) << 6) |((TXEN & 0x01) << 5) |((SYNC & 0x01) << 4);
//-----------------------------
   TEMP_BUF1 = (CSRC & 0x01)<<7;
   TEMP_BUF2 = (TX9 & 0x01)<<6;
   TEMP_BUF1 |= TEMP_BUF2;
   TEMP_BUF2 = (SYNC & 0x01)<<4;
   TEMP_BUF1 |= TEMP_BUF2;
   TEMP_BUF2 = (TXEN & 0x01)<<5;
   TEMP_BUF1 |= TEMP_BUF2;
   TXSTA = TEMP_BUF1;
//-----------------------------
//RCSTA = ((RX9 & 0x01) << 6)  | ((SREN & 0x01) << 5) |((CREN & 0x01) << 4);
//-----------------------------
   TEMP_BUF1 = (RX9 & 0x01)<<6;
   TEMP_BUF2 = (SREN & 0x01)<<5;
   TEMP_BUF1 |= TEMP_BUF2;
   TEMP_BUF2 = (CREN & 0x01)<<4;
   TEMP_BUF1 |= TEMP_BUF2;
//-----------------------------
   TEMP_BUF1 = (TEMP_BUF1 & 0x7F) | 0x80;
   RCSTA = TEMP_BUF1;
}

void EEPROM_On()
{
EE_CONT = 0;
EE_MODE = 0x80;
while (BUSY) {}
}

void EEPROM_Off()
{
while (BUSY) {}
EE_MODE = 0x00;
}

void ReadEEPROM(char *DATA,char ADR)
{
EE_ADR = ADR;
EE_MODE = EE_MODE & 0xF8;//| 0x1;
EE_MODE = EE_MODE | 0x01;
while (BUSY) {}
*DATA = EE_DATA;
}

void WriteEEPROM (char DATA, char ADR)
{
EE_ADR = ADR;
EE_DATA = DATA;
EE_MODE = EE_MODE & 0xF8;// | 0x2;
EE_MODE = EE_MODE | 0x02;
while (BUSY) {}
}

void EraseRowEEPROM (char ADR)
{
EE_ADR = ADR;
EE_MODE = EE_MODE & 0xF8; // | 0x3;
EE_MODE = EE_MODE | 0x03;
while (BUSY) {}
}

void EraseAllEEPROM()
{
EE_MODE = EE_MODE & 0xF8; //| 0x4;
EE_MODE = EE_MODE | 0x04;
while (BUSY) {}
}
