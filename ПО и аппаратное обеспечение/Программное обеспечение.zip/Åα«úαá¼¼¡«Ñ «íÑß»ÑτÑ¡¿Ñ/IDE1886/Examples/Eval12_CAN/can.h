//void Send_Frame(char box,uns32 ID, char DLC, char R1,char R0, char RTR, char SSR, char IDE,
//                char DB0,char DB1,char DB2,char DB3,char DB4,char DB5,char DB6, char DB7);
void Init_Frame(char box,uns32 ID, char DLC, char R1,char R0, char RTR, char SSR, char IDE,
                char DB0,char DB1,char DB2,char DB3,char DB4,char DB5,char DB6, char DB7);
void Transmit_Frame(char box);
void Wait_Transmit_Frame(char box);
//void SetSpeed(char BRP,char PSEG, char SEG1, char SEG2, char SJW, char SAM);

//void Reciv_Frame(char box, char MASK);
//void Wait_Reciv_Frame (char box);
//void Get_Frame (char box,uns32* ID, char *DLC, char *R1,char *R0, char *RTR, char *SSR, char *IDE,
//                char* DB0,char* DB1,char* DB2,char* DB3,char* DB4,char* DB5,char* DB6, char* DB7);
//void Rec_Frame (char box,uns32* ID, char *DLC, char *R1,char *R0, char *RTR, char *SSR, char *IDE,
//                char* DB0,char* DB1,char* DB2,char* DB3,char* DB4,char* DB5,char* DB6, char* DB7);
//void Set_Filter (char fil, uns32 Mask, uns32 Filter, char IDE, char SSR, char EIDE, char ESSR);
//char Wait_Any_Reciv_Frame();
//char Wait_Any_Transmit_Frame();

void Init_USART(char BRG, char SYNC, char TXEN, char CREN, char SREN, char CSRC, char RX9, char TX9);

void EEPROM_On();
void EEPROM_Off();
void ReadEEPROM(char *DATA,char ADR);
void WriteEEPROM (char DATA, char ADR);
void EraseRowEEPROM (char ADR);
void EraseAllEEPROM();
