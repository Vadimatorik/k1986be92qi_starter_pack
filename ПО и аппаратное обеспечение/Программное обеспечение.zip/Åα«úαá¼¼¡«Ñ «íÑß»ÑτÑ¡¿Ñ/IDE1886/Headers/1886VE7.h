/*
 *	Header file for the
 *	1886BE7 chip
 */

#pragma chip VE7, core 16 b, code 16384, ram 26 : 0x3FF
#pragma limitedSkipUsage 1   // enable limited skip mode

/* Predefined:
INDF0, FSR0,
PCL, PCLATH,
ALUSTA, T0STA, CPUSTA, INTSTA,
INDF1, FSR1,
WREG,
TMR0L, TMR0H,
TBLPTR, TBLPTRL, TBLPTRH,
BSR, BSRL, BSRH,
PRODL, PRODH,
Carry,DC,Zero_,Overflow
*/

char	DBG1	@ 0x0FF;
char	DBG2	@ 0x1FF;
char	DBG3	@ 0x2FF;
char	DBG4	@ 0x3FF;

	/* Bank 0 */
char	LIN_CNTR	@ 0x11;
char	LIN_BRG	@ 0x12;
char	RCSTA1	@ 0x13;
char	RCREG1	@ 0x14;
char	TXSTA1	@ 0x15;
char	TXREG1	@ 0x16;
char	SPBRG1	@ 0x17;

char	LINCNTR	@ 0x11;
char	LINBRG	@ 0x12;
char	RCSTA		@ 0x13;
char	RCREG		@ 0x14;
char	TXSTA		@ 0x15;
char	TXREG		@ 0x16;
char	SPBRG		@ 0x17;

	/* Bank 1 */
char	DDRA		@ 0x110;
char	PORTA		@ 0x111;

	/* Bank 5 */
char	PIR1		@ 0x510;
char	PIE1		@ 0x511;

char	EE_CONT	@ 0x514;
char	EE_MODE	@ 0x515;
char	EE_DATA	@ 0x516;
char	EE_ADR	@ 0x517;

	/* Bank 6 */
char	DBH		@ 0x610;
char	DBL		@ 0x611;
char	EE_DIV	@ 0x613;
char	EEDIV		@ 0x613;

	/* Bank 14 */
char	EE_CON	@ 0xE11;
char	EECON		@ 0xE11;

	/* Bank 15 */
char	ED_LSB	@ 0xF12;
char	ED_MSB	@ 0xF13;
char	EE_MOD	@ 0xF14;
char	EA_MSB	@ 0xF15;
char	EA_LSB	@ 0xF16;
char	CFREG		@ 0xF17;

char	EDLSB		@ 0xF12;
char	EDMSB		@ 0xF13;
char	EEMOD		@ 0xF14;
char	EAMSB		@ 0xF15;
char	EALSB		@ 0xF16;


/*	RCSTA bits	*/
bit SPEN1		@ RCSTA.7;
bit RX91		@ RCSTA.6;
bit SREN1		@ RCSTA.5;
bit CREN1		@ RCSTA.4;
bit FERR1		@ RCSTA.2;
bit OERR1		@ RCSTA.1;
bit RX9D1		@ RCSTA.0;

bit SPEN		@ RCSTA.7;
bit RX9		@ RCSTA.6;
bit SREN		@ RCSTA.5;
bit CREN		@ RCSTA.4;
bit FERR		@ RCSTA.2;
bit OERR		@ RCSTA.1;
bit RX9D		@ RCSTA.0;

/*	TXSTA bits	*/
bit CSRC1		@ TXSTA.7;
bit TX91		@ TXSTA.6;
bit TXEN1		@ TXSTA.5;
bit SYNC1		@ TXSTA.4;
bit TRMT1		@ TXSTA.1;
bit TX9D1		@ TXSTA.0;

bit CSRC		@ TXSTA.7;
bit TX9		@ TXSTA.6;
bit TXEN		@ TXSTA.5;
bit SYNC		@ TXSTA.4;
bit TRMT		@ TXSTA.1;
bit TX9D		@ TXSTA.0;

/* ===================== PORT ================================= */
/* PORTA bits */
bit RA7		@ PORTA.7;
bit RA6		@ PORTA.6;
bit RA5		@ PORTA.5;
bit RA4 		@ PORTA.4;
bit RA3		@ PORTA.3;
bit RA2		@ PORTA.2;
bit RA1		@ PORTA.1;
bit RA0 		@ PORTA.0;

bit PORTA7		@ PORTA.7;
bit PORTA6		@ PORTA.6;
bit PORTA5		@ PORTA.5;
bit PORTA4 		@ PORTA.4;
bit PORTA3		@ PORTA.3;
bit PORTA2		@ PORTA.2;
bit PORTA1		@ PORTA.1;
bit PORTA0 		@ PORTA.0;

/*	DDRA bits	*/
bit DDRA7		@ DDRA.7;
bit DDRA6		@ DDRA.6;
bit DDRA5		@ DDRA.5;
bit DDRA4		@ DDRA.4;
bit DDRA3		@ DDRA.3;
bit DDRA2		@ DDRA.2;
bit DDRA1 		@ DDRA.1;
bit DDRA0 		@ DDRA.0;

/* ===================== INTERRUPT ================================= */
/*	PIR1 bits	*/
bit DBUGIF		@ PIR1.3;
bit EEPROMIF	@ PIR1.2;
bit TX1IF		@ PIR1.1;
bit RC1IF		@ PIR1.0;
bit TXIF		@ PIR1.1;
bit RCIF		@ PIR1.0;

/*	PIE1 bits	*/
bit EEPROMIE	@ PIE1.2;
bit TX1IE		@ PIE1.1;
bit RC1IE		@ PIE1.0;
bit TXIE		@ PIE1.1;
bit RCIE		@ PIE1.0;

/* ===================== LIN ===================================== */
/*	LINCNTR bits	*/
bit BRKCNT3		@ LINCNTR.7;
bit BRKCNT2		@ LINCNTR.6;
bit BRKCNT1		@ LINCNTR.5;
bit BRKCNT0		@ LINCNTR.4;
bit BRK		@ LINCNTR.3;
bit SYNCH		@ LINCNTR.2;
bit ERR		@ LINCNTR.1;
bit LINEN		@ LINCNTR.0;

/* ===================== EEEPROM ================================= */
/*	EE_CONT bits	*/
bit TEST_p		@ EE_CONT.7;
bit EE_TEST		@ EE_CONT.6;
bit CP_TEST		@ EE_CONT.5;
bit VEE2		@ EE_CONT.4;
bit VEE1		@ EE_CONT.3;
bit BRG2		@ EE_CONT.2;
bit BRG1		@ EE_CONT.1;
bit BRG0		@ EE_CONT.0;

bit TEST_P		@ EE_CONT.7;
bit EETEST		@ EE_CONT.6;
bit CPTEST		@ EE_CONT.5;

/*	EE_MODE bits	*/
bit EE_EN		@ EE_MODE.7;
bit IE_BUSY		@ EE_MODE.5;
bit IF_BUSY		@ EE_MODE.4;
bit EE_MODE2	@ EE_MODE.2;
bit EE_MODE1	@ EE_MODE.1;
bit EE_MODE0	@ EE_MODE.0;

bit EN_EE		@ EE_MODE.7;
bit IEBUSY		@ EE_MODE.5;
bit BUSY		@ EE_MODE.4;
bit MODE2		@ EE_MODE.2;
bit MODE1		@ EE_MODE.1;
bit MODE0		@ EE_MODE.0;

/*	EE_CON bits	*/
bit LOCK		@ EE_CON.7;
bit ERROR		@ EE_CON.6;
bit EET		@ EE_CON.5;
bit EBW		@ EE_CON.4;
bit EBE		@ EE_CON.3;
bit EER		@ EE_CON.2;
bit EWR		@ EE_CON.1;
bit ERD		@ EE_CON.0;

/*	EE_MOD bits	*/
bit STATE		@ EEMOD.7;
bit RESET		@ EEMOD.6;
bit CPEN		@ EEMOD.5;
bit HWS		@ EEMOD.4;
bit AM		@ EEMOD.3;
bit TM2		@ EEMOD.2;
bit TM1		@ EEMOD.1;
bit ESTBY		@ EEMOD.0;

/*	EA_MSB bits	*/
bit CPRDY		@ EAMSB.7;;
bit EA10		@ EAMSB.2;
bit EA9		@ EAMSB.1;
bit EA8		@ EAMSB.0;

/*	EA_LSB bits	*/
bit EA7		@ EALSB.7;
bit EA6		@ EALSB.6;
bit EA5		@ EALSB.5;
bit EA4		@ EALSB.4;
bit EA3		@ EALSB.3;
bit EA2		@ EALSB.2;
bit EA1		@ EALSB.1;
bit EA0		@ EALSB.0;


/*	UNBANK bits:	*/
/*	ALUSTA bits	*/
bit FS3			@ ALUSTA.7;
bit FS2			@ ALUSTA.6;
bit FS1			@ ALUSTA.5;
bit FS0			@ ALUSTA.4;
bit OV			@ ALUSTA.3;
bit Z				@ ALUSTA.2;
bit C				@ ALUSTA.0;

/*	T0STA bits	*/
bit T0PS0			@ T0STA.1;
bit PS0			@ T0STA.1;
bit T0PS1			@ T0STA.2;
bit PS1			@ T0STA.2;
bit T0PS2			@ T0STA.3;
bit PS2			@ T0STA.3;
bit T0PS3			@ T0STA.4;
bit PS3			@ T0STA.4;
bit T0CS			@ T0STA.5;
bit T0SE			@ T0STA.6;
bit INTEDG			@ T0STA.7;

/*	CPUSTA bits	*/
bit BOR_			@ CPUSTA.0;
bit BOR			@ CPUSTA.0;
bit POR_			@ CPUSTA.1;
bit POR			@ CPUSTA.1;
bit PD			@ CPUSTA.2;
bit TO			@ CPUSTA.3;
bit GLINTD			@ CPUSTA.4;
bit STKAV			@ CPUSTA.5;
bit ESLP			@ CPUSTA.6;

/*	INTSTA bits	*/
bit INTE			@ INTSTA.0;
bit T0IE			@ INTSTA.1;
bit T0CKIE			@ INTSTA.2;
bit PEIE			@ INTSTA.3;
bit INTF			@ INTSTA.4;
bit T0IF			@ INTSTA.5;
bit T0CKIF			@ INTSTA.6;
bit PEIF			@ INTSTA.7;
