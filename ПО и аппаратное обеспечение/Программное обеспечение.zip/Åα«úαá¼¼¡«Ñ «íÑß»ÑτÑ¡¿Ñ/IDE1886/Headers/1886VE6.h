/*
 *	Header file for the
 *	1886BE6 chip
 */

#pragma chip VE6, core 16 b, code 16384, ram 26 : 0x3FF
#pragma limitedSkipUsage 1   // enable limited skip mode

/* Predefined:
INDF0, FSR0,
PCL, PCLATH,
ALUSTA, T0STA, CPUSTA, INTSTA,
INDF1, FSR1,
WREG,
TMR0L, TMR0H,
TBLPTR, TBLPTRL, TBLPTRH,
BSR, BSRL, BSRH,
PRODL, PRODH,
Carry,DC,Zero_,Overflow
*/

char	DBG1	@ 0x0FF;
char	DBG2	@ 0x1FF;
char	DBG3	@ 0x2FF;
char	DBG4	@ 0x3FF;

	/* Bank 0 */
char	LIN_CTRL	@ 0x011;
char	LIN_BRG	@ 0x012;
char	RCSTA1	@ 0x013;
char	RCREG1	@ 0x014;
char	TXSTA1	@ 0x015;
char	TXREG1	@ 0x016;
char	SPBRG1	@ 0x017;
char	LIN1_CNTR	@ 0x011;
char	LIN1_BRG	@ 0x012;

	/* Bank 1 */
char	DDRA		@ 0x110;
char	PORTA		@ 0x111;
char	DDRC		@ 0x112;
char	PORTC		@ 0x113;
char	DDRD		@ 0x114;
char	PORTD		@ 0x115;

	/* Bank 2 */
char	TMR1		@ 0x210;
char	TMR1H		@ 0x211;
char	TMR2		@ 0x212;
char	TMR2H		@ 0x213;
char	PR1		@ 0x214;
char	PR1H		@ 0x215;
char	PR2		@ 0x216;
char	PR2H		@ 0x217;
char	CA1L		@ 0x216;
char	CA1H		@ 0x217;

#define	CA1L	PR3L
#define	CA1H	PR3H

	/* Bank 3 */
char	PW1DCL	@ 0x310;
char	PW2DCL	@ 0x311;
char	PW1DCH	@ 0x312;
char	PW2DCH	@ 0x313;
char	CA2L		@ 0x314;
char	CA2H		@ 0x315;
char	TCON1		@ 0x316;
char	TCON2		@ 0x317;
	
	/* Bank 4 */
char	PW1DCHH	@ 0x410;
char	PW2DCHH	@ 0x411;
char	DAC_CONT	@ 0x412;
char	DAC1L		@ 0x413;
char	DAC1H		@ 0x414;
char	DAC2L		@ 0x415;
char	DAC2H		@ 0x416;
char	COMPARE	@ 0x417;

	/* Bank 5 */
char	PIR1		@ 0x510;
char	PIE1		@ 0x511;
char	PIR2		@ 0x512;
char	PIE2		@ 0x513;
char	EE_CON	@ 0x514;
char	EE_CONT	@ 0x514;
char	EE_MODE	@ 0x515;
char	EE_DATA	@ 0x516;
char	EE_ADR	@ 0x517;

	/* Bank 6 */
char	DBH		@ 0x610;
char	DBL		@ 0x611;
char	EE_DIV	@ 0x613;
char	EEDIV		@ 0x613;
char	ADCON0	@ 0x614;
char	ADCON1	@ 0x615;
char	ADRESL	@ 0x616;
char	ADRESH	@ 0x617;
char	ADRES		@ 0x616;

	/* Bank 7 */
char	LIN2_CTRL	@ 0x711;
char	LIN2_CNTR	@ 0x711;
char	LIN2_BRG	@ 0x712;
char	RCSTA2	@ 0x713;
char	RCREG2	@ 0x714;
char	TXSTA2	@ 0x715;
char	TXREG2	@ 0x716;
char	SPBRG2	@ 0x717;

	/* Bank 14 */
char	EECONL	@ 0xE11;
char	EECONH	@ 0xE12;

	/* Bank 15 */
char	EDLSB		@ 0xF12;
char	EDMSB		@ 0xF13;
char	EEMOD		@ 0xF14;
char	EAMSB		@ 0xF15;
char	EALSB		@ 0xF16;
char	CFREG		@ 0xF17;
char	TSTMD1	@ 0xF14;
char	TSTMD2	@ 0xF16;

/*	ALUSTA bits */
bit C		@ ALUSTA.0;
bit Z		@ ALUSTA.2;
bit OV	@ ALUSTA.3;
bit FS0	@ ALUSTA.4;
bit FS1	@ ALUSTA.5;
bit FS2	@ ALUSTA.6;
bit FS3	@ ALUSTA.7;

/*	T0STA bits	*/
bit T0PS0	@ T0STA.1;
bit T0PS1	@ T0STA.2;
bit T0PS2	@ T0STA.3;
bit T0PS3	@ T0STA.4;
bit T0CS	@ T0STA.5;
bit T0SE	@ T0STA.6;
bit INTEDG	@ T0STA.7;

bit PS0	@ T0STA.1;
bit PS1	@ T0STA.2;
bit PS2	@ T0STA.3;
bit PS3	@ T0STA.4;

/*	CPUSTA bits	*/
bit BOR_	@ CPUSTA.0;
bit POR_	@ CPUSTA.1;
bit PD	@ CPUSTA.2;
bit TO	@ CPUSTA.3;
bit GLINTD	@ CPUSTA.4;
bit STKAV	@ CPUSTA.5;
bit ESLP	@ CPUSTA.6;

bit BOR	@ CPUSTA.0;
bit POR	@ CPUSTA.1;

/*	INTSTA bits	*/
bit INTE	@ INTSTA.0;
bit T0IE	@ INTSTA.1;
bit T0CKIE	@ INTSTA.2;
bit PEIE	@ INTSTA.3;
bit INTF	@ INTSTA.4;
bit T0IF	@ INTSTA.5;
bit T0CKIF	@ INTSTA.6;
bit PEIF	@ INTSTA.7;

/*	RCSTA1 bits	*/
bit SPEN1	@ RCSTA1.7;
bit RX91	@ RCSTA1.6;
bit SREN1	@ RCSTA1.5;
bit CREN1	@ RCSTA1.4;
bit FERR1	@ RCSTA1.2;
bit OERR1	@ RCSTA1.1;
bit RX9D1	@ RCSTA1.0;

/*	TXSTA1 bits	*/
bit CSRC1	@ TXSTA1.7;
bit TX91	@ TXSTA1.6;
bit TXEN1	@ TXSTA1.5;
bit SYNC1	@ TXSTA1.4;
bit TRMT1	@ TXSTA1.1;
bit TX9D1	@ TXSTA1.0;

/* ===================== PORT ================================= */
/* PORTA bits */
bit RA7	@ PORTA.7;
bit RA6	@ PORTA.6;
bit RA5	@ PORTA.5;
bit RA4	@ PORTA.4;
bit RA3	@ PORTA.3;
bit RA2	@ PORTA.2;
bit RA1	@ PORTA.1;
bit RA0	@ PORTA.0;

bit PORTA7	@ PORTA.7;
bit PORTA6	@ PORTA.6;
bit PORTA5	@ PORTA.5;
bit PORTA4	@ PORTA.4;
bit PORTA3	@ PORTA.3;
bit PORTA2	@ PORTA.2;
bit PORTA1	@ PORTA.1;
bit PORTA0	@ PORTA.0;

/*	DDRA bits	*/
bit DDRA7	@ DDRA.7;
bit DDRA6	@ DDRA.6;
bit DDRA5	@ DDRA.5;
bit DDRA4	@ DDRA.4;
bit DDRA3	@ DDRA.3;
bit DDRA2	@ DDRA.2;

/* PORTC bits */
bit RC7	@ PORTC.7;
bit RC6	@ PORTC.6;
bit RC5	@ PORTC.5;
bit RC4	@ PORTC.4;
bit RC3	@ PORTC.3;
bit RC2	@ PORTC.2;
bit RC1	@ PORTC.1;
bit RC0	@ PORTC.0;

bit PORTC7	@ PORTC.7;
bit PORTC6	@ PORTC.6;
bit PORTC5	@ PORTC.5;
bit PORTC4	@ PORTC.4;
bit PORTC3	@ PORTC.3;
bit PORTC2	@ PORTC.2;
bit PORTC1	@ PORTC.1;
bit PORTC0	@ PORTC.0;

/*	DDRC bits	*/
bit DDRC7	@ DDRC.7;
bit DDRC6	@ DDRC.6;
bit DDRC5	@ DDRC.5;
bit DDRC4	@ DDRC.4;
bit DDRC3	@ DDRC.3;
bit DDRC2	@ DDRC.2;
bit DDRC1	@ DDRC.1;
bit DDRC0	@ DDRC.0;

/* PORTD bits */
bit RD7	@ PORTD.7;
bit RD6	@ PORTD.6;
bit RD5	@ PORTD.5;
bit RD4	@ PORTD.4;
bit RD3	@ PORTD.3;
bit RD2	@ PORTD.2;
bit RD1	@ PORTD.1;
bit RD0	@ PORTD.0;

bit PORTD7	@ PORTD.7;
bit PORTD6	@ PORTD.6;
bit PORTD5	@ PORTD.5;
bit PORTD4	@ PORTD.4;
bit PORTD3	@ PORTD.3;
bit PORTD2	@ PORTD.2;
bit PORTD1	@ PORTD.1;
bit PORTD0	@ PORTD.0;

/*	DDRD bits	*/
bit DDRD7	@ DDRD.7;
bit DDRD6	@ DDRD.6;
bit DDRD5	@ DDRD.5;
bit DDRD4	@ DDRD.4;
bit DDRD3	@ DDRD.3;
bit DDRD2	@ DDRD.2;
bit DDRD1	@ DDRD.1;
bit DDRD0	@ DDRD.0;

/* ===================== INTERRUPT ================================= */
/*	PIR1 bits	*/
bit EEPROMIF	@ PIR1.7;
bit ADCIF		@ PIR1.6;
bit TMR2IF		@ PIR1.5;
bit TMR1IF		@ PIR1.4;
bit CA2IF		@ PIR1.3;
bit CA1IF		@ PIR1.2;
bit TX1IF		@ PIR1.1;
bit RC1IF		@ PIR1.0;

bit T2IF		@ PIR1.5;
bit T1IF		@ PIR1.4;
bit CAP2IF		@ PIR1.3;
bit CAP1IF		@ PIR1.2;

/*	PIE1 bits	*/
bit EEPROMIE	@ PIE1.7;
bit ADCIE		@ PIE1.6;
bit TMR2IE		@ PIE1.5;
bit TMR1IE		@ PIE1.4;
bit CA2IE		@ PIE1.3;
bit CA1IE		@ PIE1.2;
bit TX1IE		@ PIE1.1;
bit RC1IE		@ PIE1.0;

bit T2IE		@ PIE1.5;
bit T1IE		@ PIE1.4;
bit CAP2IE		@ PIE1.3;
bit CAP1IE		@ PIE1.2;

/*	PIR2 bits	*/
bit COMPIF		@ PIR2.2;
bit TX2IF		@ PIR2.1;
bit RC2IF		@ PIR2.0;

/*	PIE2 bits	*/
bit COMPIE		@ PIE2.2;
bit TX2IE		@ PIE2.1;
bit RC2IE		@ PIE2.0;

/* ===================== CONTROL ================================= */
/* PW1DCL bits */
bit DC1PW1		@ PW1DCL.7;
bit DC0PW1		@ PW1DCL.6;
bit PW1_DC1		@ PW1DCL.7;
bit PW1_DC0		@ PW1DCL.6;

/* PW2DCL bits */
bit PW2_DC1		@ PW2DCL.7;
bit PW2_DC0		@ PW2DCL.6;
bit DC1PW2		@ PW2DCL.7;
bit DC0PW2		@ PW2DCL.6;
      			
/* PW1DCH bits */
bit DC9PW1		@ PW1DCH.7;
bit DC8PW1		@ PW1DCH.6;
bit DC7PW1		@ PW1DCH.5;
bit DC6PW1		@ PW1DCH.4;
bit DC5PW1		@ PW1DCH.3;
bit DC4PW1		@ PW1DCH.2;
bit DC3PW1 		@ PW1DCH.1;
bit DC2PW1		@ PW1DCH.0;

bit PW1_DC9		@ PW1DCH.7;
bit PW1_DC8		@ PW1DCH.6;
bit PW1_DC7		@ PW1DCH.5;
bit PW1_DC6		@ PW1DCH.4;
bit PW1_DC5		@ PW1DCH.3;
bit PW1_DC4		@ PW1DCH.2;
bit PW1_DC3		@ PW1DCH.1;
bit PW1_DC2		@ PW1DCH.0;

/* PW2DCH bits */
bit DC9PW2		@ PW2DCH.7;
bit DC8PW2		@ PW2DCH.6;
bit DC7PW2		@ PW2DCH.5;
bit DC6PW2		@ PW2DCH.4;
bit DC5PW2		@ PW2DCH.3;
bit DC4PW2		@ PW2DCH.2;
bit DC3PW2		@ PW2DCH.1;
bit DC2PW2		@ PW2DCH.0;

bit PW2_DC9		@ PW2DCH.7;
bit PW2_DC8		@ PW2DCH.6;
bit PW2_DC7		@ PW2DCH.5;
bit PW2_DC6		@ PW2DCH.4;
bit PW2_DC5		@ PW2DCH.3;
bit PW2_DC4		@ PW2DCH.2;
bit PW2_DC3		@ PW2DCH.1;
bit PW2_DC2		@ PW2DCH.0;

/* PW1DCHH bits */
bit DC17PW1		@ PW1DCHH.7;
bit DC16PW1		@ PW1DCHH.6;
bit DC15PW1		@ PW1DCHH.5;
bit DC14PW1		@ PW1DCHH.4;
bit DC13PW1		@ PW1DCHH.3;
bit DC12PW1		@ PW1DCHH.2;
bit DC11PW1		@ PW1DCHH.1;
bit DC10PW1		@ PW1DCHH.0;

bit PW1_DC17	@ PW1DCHH.7;
bit PW1_DC16	@ PW1DCHH.6;
bit PW1_DC15	@ PW1DCHH.5;
bit PW1_DC14	@ PW1DCHH.4;
bit PW1_DC13	@ PW1DCHH.3;
bit PW1_DC12	@ PW1DCHH.2;
bit PW1_DC11	@ PW1DCHH.1;
bit PW1_DC10	@ PW1DCHH.0;

/* PW2DCHH bits */
bit DC17PW2		@ PW2DCHH.7;
bit DC16PW2		@ PW2DCHH.6;
bit DC15PW2		@ PW2DCHH.5;
bit DC14PW2		@ PW2DCHH.4;
bit DC13PW2		@ PW2DCHH.3;
bit DC12PW2		@ PW2DCHH.2;
bit DC11PW2		@ PW2DCHH.1;
bit DC10PW2		@ PW2DCHH.0;

bit PW2_DC17	@ PW2DCHH.7;
bit PW2_DC16	@ PW2DCHH.6;
bit PW2_DC15	@ PW2DCHH.5;
bit PW2_DC14	@ PW2DCHH.4;
bit PW2_DC13	@ PW2DCHH.3;
bit PW2_DC12	@ PW2DCHH.2;
bit PW2_DC11	@ PW2DCHH.1;
bit PW2_DC10	@ PW2DCHH.0;

/*	TCON1 bits	*/
bit CA2ED1		@ TCON1.7;
bit CA2ED0		@ TCON1.6;
bit CA1ED1		@ TCON1.5;
bit CA1ED0		@ TCON1.4;
bit TMR2CS		@ TCON1.2;
bit TMR1CS		@ TCON1.0;

/*	TCON2 bits	*/
bit CA2OVF		@ TCON2.7;
bit CA1OVF		@ TCON2.6;
bit PWM2ON		@ TCON2.5;
bit PWM1ON		@ TCON2.4;
bit CA1_PR2		@ TCON2.3;
bit TMR2ON		@ TCON2.2;
bit TMR1ON		@ TCON2.0;

/*	ADCON0 bits	*/
bit CHS2		@ ADCON0.6;
bit CHS1		@ ADCON0.5;
bit CHS0		@ ADCON0.4;
bit GO		@ ADCON0.2;
bit ADON		@ ADCON0.0;
bit GO_DONE		@ ADCON0.2;

/*	ADCON1 bits	*/
bit ADCS1		@ ADCON1.7;
bit ADCS0		@ ADCON1.6;
bit ADFM		@ ADCON1.5;
bit PCFG3		@ ADCON1.3;
bit PCFG2		@ ADCON1.2;
bit PCFG1		@ ADCON1.1;
bit PCFG0		@ ADCON1.0;

/* ===================== LIN ===================================== */
/*	LIN1_CNTR bits */
bit LIN1_BRKCNT3	@ LIN1_CNTR.7;
bit LIN1_BRKCNT2	@ LIN1_CNTR.6;
bit LIN1_BRKCNT1	@ LIN1_CNTR.5;
bit LIN1_BRKCNT0	@ LIN1_CNTR.4;
bit LIN1_BRK	@ LIN1_CNTR.3;
bit LIN1_SYNCH	@ LIN1_CNTR.2;
bit LIN1_ERR	@ LIN1_CNTR.1;
bit LIN1_EN		@ LIN1_CNTR.0;

/*	LIN2_CNTR bits */
bit LIN2_BRKCNT3	@ LIN2_CNTR.7;
bit LIN2_BRKCNT2	@ LIN2_CNTR.6;
bit LIN2_BRKCNT1	@ LIN2_CNTR.5;
bit LIN2_BRKCNT0	@ LIN2_CNTR.4;
bit LIN2_BRK	@ LIN2_CNTR.3;
bit LIN2_SYNCH	@ LIN2_CNTR.2;
bit LIN2_ERR	@ LIN2_CNTR.1;
bit LIN2_EN		@ LIN2_CNTR.0;

/* ===================== EEEPROM ================================= */
/*	EE_CONT bits */
bit TEST_p		@ EE_CONT.7;
bit TEST_P		@ EE_CONT.7;
bit EE_TEST		@ EE_CONT.6;
bit CP_TEST		@ EE_CONT.5;
bit EETEST		@ EE_CONT.6;
bit CPTEST		@ EE_CONT.5;
bit VEE2		@ EE_CONT.4;
bit VEE1		@ EE_CONT.3;
bit BRG2		@ EE_CONT.2;
bit BRG1		@ EE_CONT.1;
bit BRG0		@ EE_CONT.0;
bit EEBRG2		@ EE_CONT.2;
bit EEBRG1		@ EE_CONT.1;
bit EEBRG0		@ EE_CONT.0;

/*	EE_MODE bits	*/
bit EE_EN		@ EE_MODE.7;
bit EN_EE		@ EE_MODE.7;
bit IE_BUSY		@ EE_MODE.5;
bit EE_BUSY		@ EE_MODE.4;
bit EE_MODE2	@ EE_MODE.2;
bit EE_MODE1	@ EE_MODE.1;
bit EE_MODE0	@ EE_MODE.0;

bit IEBUSY		@ EE_MODE.5;
bit BUSY		@ EE_MODE.4;
bit MODE2		@ EE_MODE.2;
bit MODE1		@ EE_MODE.1;
bit MODE0		@ EE_MODE.0;

/* ===================== DAC ===================================== */

bit SYNC_A		@ DAC_CONT.7;
bit DACON1		@ DAC_CONT.6;
bit ENOUT1		@ DAC_CONT.5;
bit MREF1		@ DAC_CONT.4;
bit DACON0		@ DAC_CONT.3;
bit ENOUT0		@ DAC_CONT.2;
bit MREF0		@ DAC_CONT.1;
bit DACFM		@ DAC_CONT.0;

/* ===================== COMPARE ===================================== */

bit RESULT		@ COMPARE.7;
bit STAGE		@ COMPARE.6;
bit C_IF		@ COMPARE.5;
bit E_L		@ COMPARE.4;
bit PH_NL		@ COMPARE.3;
bit CONTR1		@ COMPARE.2;
bit CONTR0		@ COMPARE.1;
bit COMP_ON		@ COMPARE.0;

/* =============================================================== */

/*	RCSTA2 bits */
bit SPEN2		@ RCSTA2.7;
bit RX92		@ RCSTA2.6;
bit SREN2		@ RCSTA2.5;
bit CREN2		@ RCSTA2.4;
bit FERR2		@ RCSTA2.2;
bit OERR2		@ RCSTA2.1;
bit RX9D2		@ RCSTA2.0;

/*	TXSTA1 bits	*/
bit CSRC2		@ TXSTA2.7;
bit TX92		@ TXSTA2.6;
bit TXEN2		@ TXSTA2.5;
bit SYNC2		@ TXSTA2.4;
bit TRMT2		@ TXSTA2.1;
bit TX9D2		@ TXSTA2.0;
