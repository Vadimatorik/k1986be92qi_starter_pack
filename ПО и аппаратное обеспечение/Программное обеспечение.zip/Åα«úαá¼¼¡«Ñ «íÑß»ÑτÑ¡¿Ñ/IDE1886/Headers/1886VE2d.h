/*
 *	Header file for
 *	1886BE2 chip
 */

#pragma chip VE2, core 16 b, code 16384, ram 26 : 0x3FF
#pragma limitedSkipUsage 1   // enable limited skip mode

/* Predefined:
INDF0, FSR0,
PCL, PCLATH,
ALUSTA, T0STA, CPUSTA, INTSTA,
INDF1, FSR1,
WREG,
TMR0L, TMR0H,
TBLPTR, TBLPTRL, TBLPTRH,
BSR, BSRL, BSRH,
PRODL, PRODH,
Carry,DC,Zero_,Overflow
*/

	/*  Bank 0  */
char 	PORTA	@ 0x10;
char 	DDRB	@ 0x11;
char 	PORTB	@ 0x12;
char 	RCSTA1	@ 0x13;
char 	RCREG1	@ 0x14;
char 	TXSTA1	@ 0x15;
char 	TXREG1	@ 0x16;
char 	SPBRG1	@ 0x17;

	/*  Bank 1  */
char 	DDRC	@ 0x110;
char 	PORTC	@ 0x111;
char 	DDRD	@ 0x112;
char 	PORTD	@ 0x113;
char 	DDRE	@ 0x114;
char 	PORTE	@ 0x115;
char 	PIR1	@ 0x116;
char 	PIE1	@ 0x117;

	/*  Bank 2  */
char 	TMR1	@ 0x210;
char 	TMR2	@ 0x211;
char 	TMR3L	@ 0x212;
char 	TMR3H	@ 0x213;
char 	PR1	@ 0x214;
char 	PR2	@ 0x215;
char 	PR3L	@ 0x216;
char 	PR3H	@ 0x217;
char 	CA1L	@ 0x216;
char 	CA1H	@ 0x217;

	/*  Bank 3  */
char 	PW1DCL	@ 0x310;
char 	PW2DCL	@ 0x311;
char 	PW1DCH	@ 0x312;
char 	PW2DCH	@ 0x313;
char 	CA2L	@ 0x314;
char 	CA2H	@ 0x315;
char 	TCON1	@ 0x316;
char 	TCON2	@ 0x317;
	
	/*  Bank 4 */
char 	PIR2	@ 0x410;
char 	PIE2	@ 0x411;
char 	RCSTA2	@ 0x413;
char 	RCREG2	@ 0x414;
char 	TXSTA2	@ 0x415;
char 	TXREG2	@ 0x416;
char 	SPBRG2	@ 0x417;

	/*  Bank 5  */
char 	DDRF	@ 0x510;
char 	PORTF	@ 0x511;
char 	DDRG	@ 0x512;
char 	PORTG	@ 0x513;
char 	ADCON0	@ 0x514;
char 	ADCON1	@ 0x515;
char 	ADRESL	@ 0x516;
char 	ADRESH	@ 0x517;

	/*  Bank 6  */
char 	SSPADD	@ 0x610;
char 	SSPCON1	@ 0x611;
char 	SSPCON2	@ 0x612;
char 	SSPSTAT	@ 0x613;
char 	SSPBUF	@ 0x614;

	/*  Bank 7  */
char 	PW3DCL	@ 0x710;
char 	PW3DCH	@ 0x711;
char 	CA3L	@ 0x712;
char 	CA3H	@ 0x713;
char 	CA4L	@ 0x714;
char 	CA4H	@ 0x715;
char 	TCON3	@ 0x716;

/*	T0STA bits	*/
bit T0PS0  @ T0STA.1;
bit T0PS1  @ T0STA.2;
bit T0PS2  @ T0STA.3;
bit T0PS3  @ T0STA.4;
bit T0CS   @ T0STA.5;
bit T0SE   @ T0STA.6;
bit INTEDG @ T0STA.7;

/*	CPUSTA bits	*/
bit BOR_   @ CPUSTA.0;
bit POR_   @ CPUSTA.1;
bit PD     @ CPUSTA.2;
bit TO     @ CPUSTA.3;
bit GLINTD @ CPUSTA.4;
bit STKAV  @ CPUSTA.5;

/*	INTSTA bits	*/
bit INTE   @ INTSTA.0;
bit T0IE   @ INTSTA.1;
bit T0CKIE @ INTSTA.2;
bit PEIE   @ INTSTA.3;
bit INTF   @ INTSTA.4;
bit T0IF   @ INTSTA.5;
bit T0CKIF @ INTSTA.6;
bit PEIF   @ INTSTA.7;

/*      PORTA bits      */
bit  RBPU	 @ PORTA.7;
bit  RA5     @ PORTA.5;
bit  RA4     @ PORTA.4;
bit  RA3     @ PORTA.3;
bit  RA2     @ PORTA.2;
bit  RA1     @ PORTA.1;
bit  RA0     @ PORTA.0;
bit  PORTA0     @ PORTA.0;
bit  PORTA1     @ PORTA.1;
bit  PORTA2     @ PORTA.2;
bit  PORTA3     @ PORTA.3;
bit  PORTA4     @ PORTA.4;
bit  PORTA5     @ PORTA.5;

/*      PORTB bits      */
bit      RB7     @ PORTB.7;
bit      RB6     @ PORTB.6;
bit      RB5     @ PORTB.5;
bit      RB4     @ PORTB.4;
bit      RB3     @ PORTB.3;
bit      RB2     @ PORTB.2;
bit      RB1     @ PORTB.1;
bit      RB0     @ PORTB.0;
bit      PORTB0     @ PORTB.0;
bit      PORTB1     @ PORTB.1;
bit      PORTB2     @ PORTB.2;
bit      PORTB3     @ PORTB.3;
bit      PORTB4     @ PORTB.4;
bit      PORTB5     @ PORTB.5;
bit      PORTB6     @ PORTB.6;
bit      PORTB7     @ PORTB.7;

/*	DDRB bits	*/
bit	   DDRB7   @ DDRB.7;
bit	   DDRB6   @ DDRB.6;
bit	   DDRB5   @ DDRB.5;
bit	   DDRB4   @ DDRB.4;
bit	   DDRB3   @ DDRB.3;
bit	   DDRB2   @ DDRB.2;
bit	   DDRB1   @ DDRB.1;
bit	   DDRB0   @ DDRB.0;

/*	RCSTA1 bits	*/
bit	SPEN1	@ RCSTA1.7;
bit	RX91	@ RCSTA1.6;
bit	SREN1	@ RCSTA1.5;
bit	CREN1	@ RCSTA1.4;
bit	FERR1	@ RCSTA1.2;
bit	OERR1	@ RCSTA1.1;
bit	RX9D1	@ RCSTA1.0;

/*	TXSTA1 bits	*/
bit	CSRC1	@ TXSTA1.7;
bit	TX91	@ TXSTA1.6;
bit	TXEN1	@ TXSTA1.5;
bit	SYNC1	@ TXSTA1.4;
bit	TRMT1	@ TXSTA1.1;
bit	TX9D1	@ TXSTA1.0;

/*      PORTC bits      */
bit      RC7     @ PORTC.7;
bit      RC6     @ PORTC.6;
bit      RC5     @ PORTC.5;
bit      RC4     @ PORTC.4;
bit      RC3     @ PORTC.3;
bit      RC2     @ PORTC.2;
bit      RC1     @ PORTC.1;
bit      RC0     @ PORTC.0;
bit      PORTC0     @ PORTC.0;
bit      PORTC1     @ PORTC.1;
bit      PORTC2     @ PORTC.2;
bit      PORTC3     @ PORTC.3;
bit      PORTC4     @ PORTC.4;
bit      PORTC5     @ PORTC.5;
bit      PORTC6     @ PORTC.6;
bit      PORTC7     @ PORTC.7;

/*	DDRC bits	*/
bit	   DDRC7   @ DDRC.7;
bit	   DDRC6   @ DDRC.6;
bit	   DDRC5   @ DDRC.5;
bit	   DDRC4   @ DDRC.4;
bit	   DDRC3   @ DDRC.3;
bit	   DDRC2   @ DDRC.2;
bit	   DDRC1   @ DDRC.1;
bit	   DDRC0   @ DDRC.0;

/*      PORTD bits      */
bit      RD7     @ PORTD.7;
bit      RD6     @ PORTD.6;
bit      RD5     @ PORTD.5;
bit      RD4     @ PORTD.4;
bit      RD3     @ PORTD.3;
bit      RD2     @ PORTD.2;
bit      RD1     @ PORTD.1;
bit      RD0     @ PORTD.0;
bit      PORTD0     @ PORTD.0;
bit      PORTD1     @ PORTD.1;
bit      PORTD2     @ PORTD.2;
bit      PORTD3     @ PORTD.3;
bit      PORTD4     @ PORTD.4;
bit      PORTD5     @ PORTD.5;
bit      PORTD6     @ PORTD.6;
bit      PORTD7     @ PORTD.7;

/*	DDRD bits	*/
bit	   DDRD7   @ DDRD.7;
bit	   DDRD6   @ DDRD.6;
bit	   DDRD5   @ DDRD.5;
bit	   DDRD4   @ DDRD.4;
bit	   DDRD3   @ DDRD.3;
bit	   DDRD2   @ DDRD.2;
bit	   DDRD1   @ DDRD.1;
bit	   DDRD0   @ DDRD.0;

/*      PORTE bits      */
bit        RE3     @ PORTE.3;
bit        RE2     @ PORTE.2;
bit        RE1     @ PORTE.1;
bit        RE0     @ PORTE.0;
bit        PORTE0     @ PORTE.0;
bit        PORTE1     @ PORTE.1;
bit        PORTE2     @ PORTE.2;
bit        PORTE3     @ PORTE.3;

/*	DDRE bits	*/
bit	   DDRE3   @ DDRE.3;
bit	   DDRE2   @ DDRE.2;
bit	   DDRE1   @ DDRE.1;
bit	   DDRE0   @ DDRE.0;

/*	PIR1 bits	*/
bit	RBIF	@ PIR1.7;
bit	TMR3IF	@ PIR1.6;
bit	TMR2IF	@ PIR1.5;
bit	TMR1IF	@ PIR1.4;
bit	CA2IF	@ PIR1.3;
bit	CA1IF	@ PIR1.2;
bit	TX1IF	@ PIR1.1;
bit	RC1IF	@ PIR1.0;

/*	PIE1 bits	*/
bit	RBIE	@ PIE1.7;
bit	TMR3IE	@ PIE1.6;
bit	TMR2IE	@ PIE1.5;
bit	TMR1IE	@ PIE1.4;
bit	CA2IE	@ PIE1.3;
bit	CA1IE	@ PIE1.2;
bit	TX1IE	@ PIE1.1;
bit	RC1IE	@ PIE1.0;

/*      PW1DCL bits     */
bit        DC1PW1  @ PW1DCL.7;
bit        DC0PW1  @ PW1DCL.6;

/*      PW2DCL  bits    */
bit        DC1PW2  @ PW2DCL.7;
bit        DC0PW2  @ PW2DCL.6;
bit        TM2PW2  @ PW2DCL.5;

/*      PW1DCH bits     */
bit        DC9PW1  @ PW1DCH.7;
bit        DC8PW1  @ PW1DCH.6;
bit        DC7PW1  @ PW1DCH.5;
bit        DC6PW1  @ PW1DCH.4;
bit        DC5PW1  @ PW1DCH.3;
bit        DC4PW1  @ PW1DCH.2;
bit        DC3PW1  @ PW1DCH.1;
bit        DC2PW1  @ PW1DCH.0;

/*      PW2DCH bits     */
bit        DC9PW2  @ PW2DCH.7;
bit        DC8PW2  @ PW2DCH.6;
bit        DC7PW2  @ PW2DCH.5;
bit        DC6PW2  @ PW2DCH.4;
bit        DC5PW2  @ PW2DCH.3;
bit        DC4PW2  @ PW2DCH.2;
bit        DC3PW2  @ PW2DCH.1;
bit        DC2PW2  @ PW2DCH.0;

/*	TCON1 bits	*/
bit	CA2ED1	@ TCON1.7;
bit	CA2ED0	@ TCON1.6;
bit	CA1ED1	@ TCON1.5;
bit	CA1ED0	@ TCON1.4;
bit	T16	@ TCON1.3;
bit	TMR3CS	@ TCON1.2;
bit	TMR2CS	@ TCON1.1;
bit	TMR1CS	@ TCON1.0;

/*	TCON2 bits	*/
bit	CA2OVF	@ TCON2.7;
bit	CA1OVF	@ TCON2.6;
bit	PWM2ON	@ TCON2.5;
bit	PWM1ON	@ TCON2.4;
bit	CA1	@ TCON2.3;
bit	TMR3ON	@ TCON2.2;
bit	TMR2ON	@ TCON2.1;
bit	TMR1ON	@ TCON2.0;

/*	PIR2 bits	*/
bit	SSPIF	@ PIR2.7;
bit	BCLIF	@ PIR2.6;
bit	ADIF	@ PIR2.5;
bit	CA4IF	@ PIR2.3;
bit	CA3IF	@ PIR2.2;
bit	TX2IF	@ PIR2.1;
bit	RC2IF	@ PIR2.0;

/*	PIE2 bits	*/
bit	SSPIE	@ PIE2.7;
bit	BCLIE	@ PIE2.6;
bit	ADIE	@ PIE2.5;
bit	CA4IE	@ PIE2.3;
bit	CA3IE	@ PIE2.2;
bit	TX2IE	@ PIE2.1;
bit	RC2IE	@ PIE2.0;

/*	RCSTA2 bits	*/
bit	SPEN2	@ RCSTA2.7;
bit	RX92	@ RCSTA2.6;
bit	SREN2	@ RCSTA2.5;
bit	CREN2	@ RCSTA2.4;
bit	FERR2	@ RCSTA2.2;
bit	OERR2	@ RCSTA2.1;
bit	RX9D2	@ RCSTA2.0;

/*	TXSTA2 bits	*/
bit	CSRC2	@ TXSTA2.7;
bit	TX92	@ TXSTA2.6;
bit	TXEN2	@ TXSTA2.5;
bit	SYNC2	@ TXSTA2.4;
bit	TRMT2	@ TXSTA2.1;
bit	TX9D2	@ TXSTA2.0;

/*      PORTF bits      */
bit        RF7     @ PORTF.7;
bit        RF6     @ PORTF.6;
bit        RF5     @ PORTF.5;
bit        RF4     @ PORTF.4;
bit        RF3     @ PORTF.3;
bit        RF2     @ PORTF.2;
bit        RF1     @ PORTF.1;
bit        RF0     @ PORTF.0;
bit        PORTF0     @ PORTF.0;
bit        PORTF1     @ PORTF.1;
bit        PORTF2     @ PORTF.2;
bit        PORTF3     @ PORTF.3;
bit        PORTF4     @ PORTF.4;
bit        PORTF5     @ PORTF.5;
bit        PORTF6     @ PORTF.6;
bit        PORTF7     @ PORTF.7;

/*	DDRF bits	*/
bit	   DDRF7   @ DDRF.7;
bit	   DDRF6   @ DDRF.6;
bit	   DDRF5   @ DDRF.5;
bit	   DDRF4   @ DDRF.4;
bit	   DDRF3   @ DDRF.3;
bit	   DDRF2   @ DDRF.2;
bit	   DDRF1   @ DDRF.1;
bit	   DDRF0   @ DDRF.0;

/*      PORTG bits      */
bit        RG7     @ PORTG.7;
bit        RG6     @ PORTG.6;
bit        RG5     @ PORTG.5;
bit        RG4     @ PORTG.4;
bit        RG3     @ PORTG.3;
bit        RG2     @ PORTG.2;
bit        RG1     @ PORTG.1;
bit        RG0     @ PORTG.0;
bit        PORTG0     @ PORTG.0;
bit        PORTG1     @ PORTG.1;
bit        PORTG2     @ PORTG.2;
bit        PORTG3     @ PORTG.3;
bit        PORTG4     @ PORTG.4;
bit        PORTG5     @ PORTG.5;
bit        PORTG6     @ PORTG.6;
bit        PORTG7     @ PORTG.7;

/*	DDRG bits	*/
bit	   DDRG7   @ DDRG.7;
bit	   DDRG6   @ DDRG.6;
bit	   DDRG5   @ DDRG.5;
bit	   DDRG4   @ DDRG.4;
bit	   DDRG3   @ DDRG.3;
bit	   DDRG2   @ DDRG.2;
bit	   DDRG1   @ DDRG.1;
bit	   DDRG0   @ DDRG.0;

/*	ADCON0 bits	*/
bit	CHS3	@ ADCON0.7;
bit	CHS2	@ ADCON0.6;
bit	CHS1	@ ADCON0.5;
bit	CHS0	@ ADCON0.4;
bit	GO	@ ADCON0.2;
bit	ADON	@ ADCON0.0;

/*	ADCON1 bits	*/
bit	ADCS1	@ ADCON1.7;
bit	ADCS0	@ ADCON1.6;
bit	ADFM	@ ADCON1.5;
bit	PCFG3	@ ADCON1.3;
bit	PCFG2	@ ADCON1.2;
bit	PCFG1	@ ADCON1.1;
bit	PCFG0	@ ADCON1.0;

/*	SSPCON1 bits	*/
bit	WCOL	@ SSPCON1.7;
bit	SSPOV	@ SSPCON1.6;
bit	SSPEN	@ SSPCON1.5;
bit	CKP	@ SSPCON1.4;
bit	SSPM3	@ SSPCON1.3;
bit	SSPM2	@ SSPCON1.2;
bit	SSPM1	@ SSPCON1.1;
bit	SSPM0	@ SSPCON1.0;

/*	SSPCON2 bits	*/
bit	GCEN	@ SSPCON2.7;
bit	ACKSTAT	@ SSPCON2.6;
bit	ACKDT	@ SSPCON2.5;
bit	ACKEN	@ SSPCON2.4;
bit	RCEN	@ SSPCON2.3;
bit	PEN	@ SSPCON2.2;
bit	RSEN	@ SSPCON2.1;
bit	SEN	@ SSPCON2.0;

/*      SSPSTAT bits    */
bit        STAT_SMP        @ SSPSTAT.7;
bit        STAT_CKE        @ SSPSTAT.6;
bit        STAT_DA         @ SSPSTAT.5;
bit        STAT_P          @ SSPSTAT.4;
bit        STAT_S          @ SSPSTAT.3;
bit        STAT_RW         @ SSPSTAT.2;
bit        STAT_UA         @ SSPSTAT.1;
bit        STAT_BF         @ SSPSTAT.0;

/*      PW3DCL  bits    */
bit        DC1PW3  @ PW3DCL.7;
bit        DC0PW3  @ PW3DCL.6;
bit        TM2PW3  @ PW3DCL.5;

/*      PW3DCH bits     */
bit        DC9PW3  @ PW3DCH.7;
bit        DC8PW3  @ PW3DCH.6;
bit        DC7PW3  @ PW3DCH.5;
bit        DC6PW3  @ PW3DCH.4;
bit        DC5PW3  @ PW3DCH.3;
bit        DC4PW3  @ PW3DCH.2;
bit        DC3PW3  @ PW3DCH.1;
bit        DC2PW3  @ PW3DCH.0;

/*	TCON3 bits	*/
bit	CA4OVF	@ TCON3.6;
bit	CA3OVF	@ TCON3.5;
bit	CA4ED1	@ TCON3.4;
bit	CA4ED0	@ TCON3.3;
bit	CA3ED1	@ TCON3.2;
bit	CA3ED0	@ TCON3.1;
bit	PWM3ON	@ TCON3.0;
/*******************************/
#define DebugBreakPoint #asm \
DW 0x7E02,0x7D03,0x2903,0xFFB8 \
#endasm \
/*  movfp PCL,dbgPCL \
    movfp PCLATH,dbgPCLATH \
    clrf PCLATH,f \
    call DebugPoint \*/
