// Header file
#pragma chip VE5, core 16 b, code 16384, ram 26 : 0x3FF
#pragma limitedSkipUsage 1   // enable limited skip mode

/* Predefined:
INDF0, FSR0,
PCL, PCLATH,
ALUSTA, T0STA, CPUSTA, INTSTA,
INDF1, FSR1,
WREG,
TMR0L, TMR0H,
TBLPTR, TBLPTRL, TBLPTRH,
BSR, BSRL, BSRH,
PRODL, PRODH,
Carry,DC,Zero_,Overflow
*/

/*---------------------------*/
/*---------- BANK0 ----------*/
/*---------------------------*/
char RCSTA1		@ 0x13;
char RCSTA		@ 0x13;

/*---RCSTA bits---*/
bit RX9D		@ RCSTA.0;
bit OERR		@ RCSTA.1;
bit FERR		@ RCSTA.2;
bit CREN		@ RCSTA.4;
bit SREN		@ RCSTA.5;
bit RX9		@ RCSTA.6;
bit SPEN		@ RCSTA.7;

bit RX9D1		@ RCSTA.0;
bit OERR1		@ RCSTA.1;
bit FERR1		@ RCSTA.2;
bit CREN1		@ RCSTA.4;
bit SREN1		@ RCSTA.5;
bit RX9_1		@ RCSTA.6;
bit SPEN1		@ RCSTA.7;

char RCREG1		@ 0x14;
char RCREG		@ 0x14;
char TXSTA1		@ 0x15;
char TXSTA		@ 0x15;

/*---TXSTA bits---*/
bit TX9D		@ TXSTA.0; 
bit TRMT		@ TXSTA.1; 
bit SYNC		@ TXSTA.4; 
bit TXEN		@ TXSTA.5; 
bit TX9		@ TXSTA.6; 
bit CSRC		@ TXSTA.7; 

bit TX9D1		@ TXSTA.0;
bit TRMT1		@ TXSTA.1;
bit SYNC1		@ TXSTA.4;
bit TXEN1		@ TXSTA.5;
bit TX9_1		@ TXSTA.6;
bit CSRC1		@ TXSTA.7;

char TXREG1		@ 0x16;
char TXREG		@ 0x16; 
char SPBRG1		@ 0x17;
char SPBRG		@ 0x17; 

char LIN_CNTR	@ 0x11; 

/*---LIN_CNTR bits---*/
bit LINEL		@ LIN_CNTR.0; 
bit ERR		@ LIN_CNTR.1; 
bit SYNCH		@ LIN_CNTR.2; 
bit BRK		@ LIN_CNTR.3; 
bit BRKCNT0		@ LIN_CNTR.4; 
bit BRKCNT1		@ LIN_CNTR.5; 
bit BRKCNT2		@ LIN_CNTR.6; 
bit BRKCNT3		@ LIN_CNTR.7; 

char LIN_BRG	@ 0x12; 

/*---------------------------*/
/*---------- BANK1 ----------*/
/*---------------------------*/
char DDRA		@ 0x110;

/*---DDRA bits---*/
bit DDRA5		@ DDRA.5;
bit DDRA4		@ DDRA.4;
bit DDRA3		@ DDRA.3;
bit DDRA2		@ DDRA.2;
bit DDRA1		@ DDRA.1;
bit DDRA0		@ DDRA.0;

char PORTA		@ 0x111;

/*---PORTA bits---*/
bit PORTA5		@ PORTA.5;
bit PORTA4		@ PORTA.4;
bit PORTA3		@ PORTA.3;
bit PORTA2		@ PORTA.2;
bit PORTA1		@ PORTA.1;
bit PORTA0		@ PORTA.0;

char DDRC		@ 0x112;

/*---DDRC bits---*/
bit DDRC7		@ DDRC.7;
bit DDRC6		@ DDRC.6;
bit DDRC5		@ DDRC.5;
bit DDRC4		@ DDRC.4;
bit DDRC3		@ DDRC.3;
bit DDRC2		@ DDRC.2;
bit DDRC1		@ DDRC.1;
bit DDRC0		@ DDRC.0;

char PORTC		@ 0x113;

/*---PORTC bits---*/

bit PORTC7		@PORTC.7;
bit PORTC6		@PORTC.6;
bit PORTC5		@PORTC.5;
bit PORTC4		@PORTC.4;
bit PORTC3		@PORTC.3;
bit PORTC2		@PORTC.2;
bit PORTC1		@PORTC.1;
bit PORTC0		@PORTC.0;

char DDRD		@ 0x114;

/*---DDRD bits---*/
bit DDRD7		@ DDRD.7;
bit DDRD6		@ DDRD.6;
bit DDRD5		@ DDRD.5;
bit DDRD4		@ DDRD.4;
bit DDRD3		@ DDRD.3;
bit DDRD2		@ DDRD.2;
bit DDRD1		@ DDRD.1;
bit DDRD0		@ DDRD.0;

char PORTD		@ 0x115;

/*---PORTD bits---*/
bit PORTD7		@ PORTD.7;
bit PORTD6		@ PORTD.6;
bit PORTD5		@ PORTD.5;
bit PORTD4		@ PORTD.4;
bit PORTD3		@ PORTD.3;
bit PORTD2		@ PORTD.2;
bit PORTD1		@ PORTD.1;
bit PORTD0		@ PORTD.0;

char DDRE		@ 0x116;

/*---DDRE bits---*/
bit DDRE3		@ DDRE.3;
bit DDRE2		@ DDRE.2;
bit DDRE1		@ DDRE.1;
bit DDRE0		@ DDRE.0;

char PORTE		@ 0x117;

/*---PORTE bits---*/
bit PORTE3		@ PORTE.3;
bit PORTE2		@ PORTE.2;
bit PORTE1		@ PORTE.1;
bit PORTE0		@ PORTE.0;

/*---------------------------*/
/*---------- BANK2 ----------*/
/*---------------------------*/
char TMR1		@ 0x210;

char TMR3L		@ 0x212;
char TMR3H		@ 0x213;

char TMR2L		@ 0x212; 
char TMR2H		@ 0x213; 

char PR1		@ 0x214;

char PR3L		@ 0x216;

char PR2L		@ 0x216; 
char PR2H		@ 0x217; 

char CA1L		@ 0x216;
char PR3H		@ 0x217;
char CA1H		@ 0x217;

/*---------------------------*/
/*---------- BANK3 ----------*/
/*---------------------------*/
char PW1DCL		@ 0x310;

/*---PW1DCL bits---*/
bit DC1PW1		@ PW1DCL.7; 
bit DC0PW1		@ PW1DCL.6; 

char PW2DCL		@ 0x311;

/*---PW2DCL bits---*/
bit DC1PW2		@ PW2DCL.7; 
bit DC0PW2		@ PW2DCL.6; 

char PW1DCH		@ 0x312;

/*---PW1DCH bits---*/
bit DC9PW1		@ PW1DCH.7; 
bit DC8PW1		@ PW1DCH.6; 
bit DC7PW1		@ PW1DCH.5; 
bit DC6PW1		@ PW1DCH.4; 
bit DC5PW1		@ PW1DCH.3; 
bit DC4PW1		@ PW1DCH.2; 
bit DC3PW1		@ PW1DCH.1; 
bit DC2PW1		@ PW1DCH.0; 

char PW2DCH		@ 0x313;

/*---PW2DCH bits---*/
bit DC9PW2		@ PW2DCH.7; 
bit DC8PW2		@ PW2DCH.6; 
bit DC7PW2		@ PW2DCH.5; 
bit DC6PW2		@ PW2DCH.4; 
bit DC5PW2		@ PW2DCH.3; 
bit DC4PW2		@ PW2DCH.2; 
bit DC3PW2		@ PW2DCH.1; 
bit DC2PW2		@ PW2DCH.0; 

char CA2L		@ 0x314;
char CA2H		@ 0x315;
char TCON1		@ 0x316;

/*---TCON1 bits---*/
bit CA2ED1		@ TCON1.7; 
bit CA2ED0		@ TCON1.6; 
bit CA1ED1		@ TCON1.5; 
bit CA1ED0		@ TCON1.4; 
bit TMR2CS		@ TCON1.2; 
bit TMR1CS		@ TCON1.0; 

char TCON2		@ 0x317;

/*---TCON2 bits---*/
bit CA2OVF		@ TCON2.7; 
bit CA1OVF		@ TCON2.6; 
bit PWM2ON		@ TCON2.5; 
bit PWM1ON		@ TCON2.4; 
bit CA1_PR2		@ TCON2.3; 
bit TMR2ON		@ TCON2.2; 
bit TMR1ON		@ TCON2.0; 

/*---------------------------*/
/*---------- BANK4 ----------*/
/*---------------------------*/
char	CAN_FILTER_LL	@ 0x414;
char	CAN_FILTER_LH	@ 0x415;
char	CAN_FILTER_HL	@ 0x416;
char	CAN_FILTER_HH	@ 0x417;
long	CAN_FILTER		@ 0x414;
char	CAN_MASK_LL		@ 0x410;
char	CAN_MASK_LH		@ 0x411;
char	CAN_MASK_HL		@ 0x412;
char	CAN_MASK_HH		@ 0x413;
long	CAN_MASK		@ 0x410;

char	CAN_FLTR11_21	@ 0x414; 
char	CAN_FLTR12_22	@ 0x415; 
char	CAN_FLTR13_23	@ 0x416; 
char	CAN_FLTR14_24	@ 0x417; 
long	CAN_FLTR		@ 0x414; 
char	CAN_MASK11_21	@ 0x410; 
char	CAN_MASK12_22	@ 0x411; 
char	CAN_MASK13_32	@ 0x412; 
char	CAN_MASK14_24	@ 0x413; 

#define CAN_FLTR1		CAN_FLTR
#define CAN_MASK1		CAN_MASK
#define CAN_FLTR2		CAN_FLTR
#define CAN_MASK2		CAN_MASK

/*---------------------------*/
/*---------- BANK5 ----------*/
/*---------------------------*/
char PIR1		@ 0x510;

/*---PIR1 bits---*/
bit EEPROMIF	@ PIR1.7; 
bit ADCIF		@ PIR1.6; 
bit T2IF		@ PIR1.5; 
bit T1IF		@ PIR1.4; 
bit CAP2IF		@ PIR1.3; 
bit CAP1IF		@ PIR1.2; 
bit TXIF		@ PIR1.1; 
bit RCIF		@ PIR1.0; 

char PIE1		@ 0x511;

/*---PIE1 bits---*/
bit EEPROMIE	@ PIE1.7; 
bit ADCIE		@ PIE1.6; 
bit T2IE		@ PIE1.5; 
bit T1IE		@ PIE1.4; 
bit CAP2IE		@ PIE1.3; 
bit CAP1IE		@ PIE1.2; 
bit TXIE		@ PIE1.1; 
bit RCIE		@ PIE1.0; 

char PIR2		@ 0x512;

/*---PIR2 bits---*/
bit CANB5IF		@ PIR2.5; 
bit CANB4IF		@ PIR2.4; 
bit CANB3IF		@ PIR2.3; 
bit CANB2IF		@ PIR2.2; 
bit CANB1IF		@ PIR2.1; 
bit CANB0IF		@ PIR2.0; 

char PIE2		@ 0x513;

/*---PIE2 bits---*/
bit CANB5IE		@ PIE2.5; 
bit CANB4IE		@ PIE2.4; 
bit CANB3IE		@ PIE2.3; 
bit CANB2IE		@ PIE2.2; 
bit CANB1IE		@ PIE2.1; 
bit CANB0IE		@ PIE2.0; 

char EE_CONT	@ 0x514; 

/*---EE_CONT bits---*/
bit TEST_P		@ EE_CONT.7; 
bit EETEST		@ EE_CONT.6; 
bit CPTEST		@ EE_CONT.5; 
bit VEE2		@ EE_CONT.4; 
bit VEE1		@ EE_CONT.3; 
bit BRG2		@ EE_CONT.2; 
bit BRG1		@ EE_CONT.1; 
bit BRG0		@ EE_CONT.0; 

char EE_MODE	@ 0x515; 

/*---EE_MODE bits---*/
bit EE_EN		@ EE_MODE.7; 
bit IEBUSY		@ EE_MODE.5; 
bit BUSY		@ EE_MODE.4; 
bit MODE2		@ EE_MODE.2; 
bit MODE1		@ EE_MODE.1; 
bit MODE0		@ EE_MODE.0; 

char EE_DATA	@ 0x516; 
char EE_ADR		@ 0x517; 

/*---------------------------*/
/*---------- BANK6 ----------*/
/*---------------------------*/
char DBH		@ 0x610; 
char DBL		@ 0x611; 
char EE_DIV		@ 0x613; 

char ADCON0		@ 0x614;

/*---ADCON0 bits---*/
bit CHS2		@ ADCON0.6; 
bit CHS1		@ ADCON0.5; 
bit CHS0		@ ADCON0.4; 
bit GO_DONE		@ ADCON0.2; 
bit ADON		@ ADCON0.0; 

char ADCON1		@ 0x615;

/*---ADCON1 bits---*/
bit ADCS1		@ ADCON1.7; 
bit ADCS0		@ ADCON1.6; 
bit ADFM		@ ADCON1.5; 
bit PCFG3		@ ADCON1.3; 
bit PCFG2		@ ADCON1.2; 
bit PCFG1		@ ADCON1.1; 
bit PCFG0		@ ADCON1.0; 

char ADRESL		@ 0x616;
char ADRESH		@ 0x617;

/*---------------------------*/
/*---------- BANK7 ----------*/
/*---------------------------*/
char CAN_CNTR	@0x710; 

/*---CAN_CNTR bits---*/
bit ERR_STATE1	@ CAN_CNTR.7; 
bit ERR_STATE0	@ CAN_CNTR.6; 
bit OVL_SEND	@ CAN_CNTR.5; 
bit ROP		@ CAN_CNTR.4; 
bit SAP		@ CAN_CNTR.3; 
bit STM		@ CAN_CNTR.2; 
bit ROM		@ CAN_CNTR.1; 
bit CANEN		@ CAN_CNTR.0; 

char CAN_STAT	@0x711; 

/*---CAN_STAT bits---*/
bit RXBUSY		@ CAN_STAT.5; 
bit TXBUSY		@ CAN_STAT.4; 
bit STUFFERR	@ CAN_STAT.3; 
bit FRAMEERR	@ CAN_STAT.2; 
bit CRCERR		@ CAN_STAT.1; 
bit RXBITERR	@ CAN_STAT.0; 

char CAN_BRG1	@0x712; 

/*---CAN_BRG1 bits---*/
bit SJW1		@ CAN_BRG1.7; 
bit SJW0		@ CAN_BRG1.6; 
bit BRP5		@ CAN_BRG1.5; 
bit BRP4		@ CAN_BRG1.4; 
bit BRP3		@ CAN_BRG1.3; 
bit BRP2		@ CAN_BRG1.2; 
bit BRP1		@ CAN_BRG1.1; 
bit BRP0		@ CAN_BRG1.0; 

char CAN_BRG2	@0x713; 

/*---CAN_BRG2 bits---*/
bit SAM		@ CAN_BRG2.6; 
bit SEG12		@ CAN_BRG2.5; 
bit SEG11		@ CAN_BRG2.4; 
bit SEG10		@ CAN_BRG2.3; 
bit PRSEG2		@ CAN_BRG2.2; 
bit PRSEG1		@ CAN_BRG2.1; 
bit PRSEG0		@ CAN_BRG2.0; 

char CAN_BRG3	@0x714; 

/*---CAN_BRG3 bits---*/
bit SEG22		@ CAN_BRG3.2; 
bit SEG21		@ CAN_BRG3.1; 
bit SEG20		@ CAN_BRG3.0; 

char CAN_BSR	@ 0x715; 

/*---CAN_BSR bits---*/
bit MLS		@ CAN_BSR.4; 
bit BSR2		@ CAN_BSR.2; 
bit BSR1		@ CAN_BSR.1; 
bit BSR0		@ CAN_BSR.0; 

char CANERXCNT	@ 0x716; 
char CANETXCNT	@ 0x717; 

/*---------------------------*/
/*---------- BANK8 ----------*/
/*---------------------------*/
char CAN_RXCS	@ 0x810; 

/*---CAN_RXCS bits---*/
bit RXFULL		@ CAN_RXCS.7; 	
bit BITERR		@ CAN_RXCS.6; 
bit RXRTR		@ CAN_RXCS.5; 
bit OF		@ CAN_RXCS.4; 
bit OFEN		@ CAN_RXCS.3; 
bit MASKACTID2	@ CAN_RXCS.2; 
bit MASKACTID1	@ CAN_RXCS.1; 
bit MASKACTID0	@ CAN_RXCS.0; 

char CAN_TXCS	@ 0x811; 

/*---CAN_TXCS bits---*/
bit TXBIF		@ CAN_TXCS.7; 
bit TXABRT		@ CAN_TXCS.6; 
bit TXLARB		@ CAN_TXCS.5; 
bit TXERR		@ CAN_TXCS.4; 
bit ACKERR		@ CAN_TXCS.4;
bit TXREQ		@ CAN_TXCS.3; 
bit RTREN		@ CAN_TXCS.2; 
bit PRIOR1		@ CAN_TXCS.1; 
bit PRIOR0		@ CAN_TXCS.0; 

char CAN_CS		@0x812; 

/*---CAN_CS bits---*/
bit CANRXIE		@ CAN_CS.7; 
bit CANTXIE		@ CAN_CS.6; 
bit ERRIE		@ CAN_CS.5; 
bit RX_TXN		@ CAN_CS.1; 
bit EN		@ CAN_CS.0; 

char CAN_ID0	@ 0x813; 
char CAN_ID1	@ 0x814; 

/*---CAN_ID1 bits---*/
bit SSR		@ CAN_ID1.4; 
bit EIDEN		@ CAN_ID1.3; 

char CAN_ID2	@ 0x815; 
char CAN_ID3	@ 0x816; 
char CAN_DLC	@ 0x817; 

/*---CAN_DLC bits---*/
bit RTRRX		@ CAN_DLC.6; 
bit R1		@ CAN_DLC.5; 
bit R0		@ CAN_DLC.4; 
bit DLC3		@ CAN_DLC.3; 
bit DLC2		@ CAN_DLC.2; 
bit DLC1		@ CAN_DLC.1; 
bit DLC0		@ CAN_DLC.0; 

/*---------------------------*/
/*---------- BANK9 ----------*/
/*---------------------------*/
char CAN_DB0	@ 0x910; 
char CAN_DB1	@ 0x911; 
char CAN_DB2	@ 0x912; 
char CAN_DB3	@ 0x913; 
char CAN_DB4	@ 0x914; 
char CAN_DB5	@ 0x915; 
char CAN_DB6	@ 0x916; 
char CAN_DB7	@ 0x917; 

/*---------------------------*/
/*---------- BANK14 ---------*/
/*---------------------------*/
char EECONL		@0xE11; 

/*---EECONL bits---*/
bit LOCKL		@ EECONL.7; 
bit ERRL		@ EECONL.6; 
bit EETL		@ EECONL.5; 
bit EBWL		@ EECONL.4; 
bit EBEL		@ EECONL.3; 
bit EERL		@ EECONL.2; 
bit EWRL		@ EECONL.1; 
bit ERDL		@ EECONL.0; 

char EECONH		@0xE12; 

/*---EECONH bits---*/
bit LOCKH		@ EECONH.7; 
bit ERRH		@ EECONH.6; 
bit EETH		@ EECONH.5; 
bit EBWH		@ EECONH.4; 
bit EBEH		@ EECONH.3; 
bit EERH		@ EECONH.2; 
bit EWRH		@ EECONH.1; 
bit ERDH		@ EECONH.0; 

/*---------------------------*/
/*---------- BANK15 ---------*/
/*---------------------------*/
char EDLSB		@ 0xF12; 
char EDMSB		@ 0xE13; 
char EEMOD		@ 0xF14; 

/*---EEMOD bits---*/
bit STATE		@ EEMOD.7; 
bit RESET		@ EEMOD.6; 
bit CPEN		@ EEMOD.5; 
bit HWS		@ EEMOD.4; 
bit AM		@ EEMOD.3; 
bit TM1		@ EEMOD.2; 
bit TM2		@ EEMOD.1; 
bit ESTBY		@ EEMOD.0; 

char EAMSB		@ 0xE15; 
char EALSB		@ 0xE16; 
char CFREG		@ 0xE17; 

/*	UNBANK bits:	*/
/*	ALUSTA bits	*/
bit FS3			@ ALUSTA.7;
bit FS2			@ ALUSTA.6;
bit FS1			@ ALUSTA.5;
bit FS0			@ ALUSTA.4;
bit OV			@ ALUSTA.3;
bit Z				@ ALUSTA.2;
bit C				@ ALUSTA.0;

/*	T0STA bits	*/
bit T0PS0			@ T0STA.1;
bit PS0			@ T0STA.1;
bit T0PS1			@ T0STA.2;
bit PS1			@ T0STA.2;
bit T0PS2			@ T0STA.3;
bit PS2			@ T0STA.3;
bit T0PS3			@ T0STA.4;
bit PS3			@ T0STA.4;
bit T0CS			@ T0STA.5;
bit T0SE			@ T0STA.6;
bit INTEDG			@ T0STA.7;

/*	CPUSTA bits	*/
bit BOR_			@ CPUSTA.0;
bit BOR			@ CPUSTA.0;
bit POR_			@ CPUSTA.1;
bit POR			@ CPUSTA.1;
bit PD			@ CPUSTA.2;
bit TO			@ CPUSTA.3;
bit GLINTD			@ CPUSTA.4;
bit STKAV			@ CPUSTA.5;
bit ESLP			@ CPUSTA.6;

/*	INTSTA bits	*/
bit INTE			@ INTSTA.0;
bit T0IE			@ INTSTA.1;
bit T0CKIE			@ INTSTA.2;
bit PEIE			@ INTSTA.3;
bit INTF			@ INTSTA.4;
bit T0IF			@ INTSTA.5;
bit T0CKIF			@ INTSTA.6;
bit PEIF			@ INTSTA.7;
