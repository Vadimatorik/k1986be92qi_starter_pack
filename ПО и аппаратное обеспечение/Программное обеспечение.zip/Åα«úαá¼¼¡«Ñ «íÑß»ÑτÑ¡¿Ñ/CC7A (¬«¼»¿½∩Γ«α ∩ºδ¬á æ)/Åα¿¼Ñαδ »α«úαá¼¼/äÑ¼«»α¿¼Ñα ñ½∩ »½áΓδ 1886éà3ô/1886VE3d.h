/*
 *	Header file for
 *	1886BE3  chip
 *	1886BE31 chip
 */

#pragma chip VE3, core 16 b, code 32751, ram 26 : 0x3FF
#pragma limitedSkipUsage 1   // enable limited skip mode

/* Predefined:
INDF0, FSR0,
PCL, PCLATH,
ALUSTA, T0STA, CPUSTA, INTSTA,
INDF1, FSR1,
WREG,
TMR0L, TMR0H,
TBLPTR, TBLPTRL, TBLPTRH,
BSR, BSRL, BSRH,
PRODL, PRODH,
Carry,DC,Zero_,Overflow
*/

	/*  Bank 0  */
char EP1_CFG1		@ 0x010;
char EP1_CFG2		@ 0x011;
char EP2_CFG1		@ 0x012;
char EP2_CFG2		@ 0x013;

	/*  Bank 1  */
char DESCR_ADR		@ 0x110;
char DESC_ADR		@ 0x110;
char DESCR_DATA		@ 0x111;
char DESC_DATA		@ 0x111;
char PORTA			@ 0x112;
char PORT_A			@ 0x112;
char DDRD			@ 0x113;
char DDR_D			@ 0x113;
char PORTD			@ 0x114;
char DDRC			@ 0x115;
char DDR_C			@ 0x115;
char PORTC			@ 0x116;
char PORT_C			@ 0x116;

	/*  Bank 2  */
char EP1_REG		@ 0x210;
char EP2_REG		@ 0x211;
char NAND_DATA2		@ 0x212;
char CPRT_DATA2		@ 0x213;
char PIR1			@ 0x214;
char PIE1			@ 0x215;

	/*  Bank 3  */
char EP1_STAT		@ 0x310;
char EP2_STAT		@ 0x311;
char EP1_CNT		@ 0x314;
char EP2_CNT		@ 0x315;
	
	/*  Bank 4 */
char USB_ADR		@ 0x410;
char USB_ERROR		@ 0x411;
char USB_STAT		@ 0x412;
char USB_CTRL		@ 0x413;
char USB_IE1		@ 0x414;
char USB_IE2		@ 0x415;
char USB_IE3		@ 0x416;
char USB_IE4		@ 0x417;

	/*  Bank 5  */
char DDRE			@ 0x511;
char DDR_E			@ 0x511;
char PORTE			@ 0x512;
char PORT_E			@ 0x512;
char RCSTA1			@ 0x513;
char RCSTA			@ 0x513;
char RCREG1			@ 0x514;
char RCREG			@ 0x514;
char TXSTA1			@ 0x515;
char TXSTA			@ 0x515;
char TXREG1			@ 0x516;
char TXREG			@ 0x516;
char SPBRG1			@ 0x517;
char SPBRG			@ 0x517;


	/*  Bank 6  */
char NAND_MODE		@ 0x610;
char NAND_DATA		@ 0x611;
char WRDIV			@ 0x613;
char WRDIF			@ 0x613;
char EE_CON			@ 0x614;
char EE_CONT		@ 0x614;
char EEPROM_CONT		@ 0x614;
char EE_MODE		@ 0x615;
char EEPROM_MODE		@ 0x615;
char EE_DATA		@ 0x616;
char EEPROM_DATA		@ 0x616;
char EE_ADDR		@ 0x617;
char EEPROM_ADDR		@ 0x617;

	/*  Bank 7  */
char CRPT_CWR		@ 0x710;
char CRPT_SR		@ 0x711;
char CRPT_DATA		@ 0x712;
char CRPT_DR		@ 0x712;
char CRPT_KR		@ 0x713;
char CRPT_CR		@ 0x714;
char CRPT_SYNR		@ 0x715;
char CRPT_ITER		@ 0x716;
char CRPT_IMIT		@ 0x717;

/*	RCSTA bits	*/
bit SPEN1			@ RCSTA.7;
bit RX91			@ RCSTA.6;
bit SREN1			@ RCSTA.5;
bit CREN1			@ RCSTA.4;
bit FERR1			@ RCSTA.2;
bit OERR1			@ RCSTA.1;
bit RX9D1			@ RCSTA.0;

bit SPEN			@ RCSTA.7;
bit RX9			@ RCSTA.6;
bit SREN			@ RCSTA.5;
bit CREN			@ RCSTA.4;
bit FERR			@ RCSTA.2;
bit OERR			@ RCSTA.1;
bit RX9D			@ RCSTA.0;

/*	TXSTA bits	*/
bit CSRC1			@ TXSTA.7;
bit TX91			@ TXSTA.6;
bit TXEN1			@ TXSTA.5;
bit SYNC1			@ TXSTA.4;
bit TRMT1			@ TXSTA.1;
bit TX9D1			@ TXSTA.0;

bit CSRC			@ TXSTA.7;
bit TX9			@ TXSTA.6;
bit TXEN			@ TXSTA.5;
bit SYNC			@ TXSTA.4;
bit TRMT			@ TXSTA.1;
bit TX9D			@ TXSTA.0;

/*      PORTA bits      */
bit PORTA3			@ PORTA.3;
bit PORTA2			@ PORTA.2;
bit PORTA1			@ PORTA.1;
bit PORTA0			@ PORTA.0;

/*      PORTC bits      */
bit RC7			@ PORTC.7;
bit RC6			@ PORTC.6;
bit RC5			@ PORTC.5;
bit RC4			@ PORTC.4;
bit RC3			@ PORTC.3;
bit RC2			@ PORTC.2;
bit RC1			@ PORTC.1;
bit RC0			@ PORTC.0;

bit PORTC7			@ PORTC.7;
bit PORTC6			@ PORTC.6;
bit PORTC5			@ PORTC.5;
bit PORTC4			@ PORTC.4;
bit PORTC3			@ PORTC.3;
bit PORTC2			@ PORTC.2;
bit PORTC1			@ PORTC.1;
bit PORTC0			@ PORTC.0;

/*	DDRC bits	*/
bit DDRC7			@ DDRC.7;
bit DDRC6			@ DDRC.6;
bit DDRC5			@ DDRC.5;
bit DDRC4			@ DDRC.4;
bit DDRC3			@ DDRC.3;
bit DDRC2			@ DDRC.2;
bit DDRC1			@ DDRC.1;
bit DDRC0			@ DDRC.0;

/*      PORTD bits      */
bit RD7			@ PORTD.7;
bit RD6			@ PORTD.6;
bit RD5			@ PORTD.5;
bit RD4			@ PORTD.4;
bit RD3			@ PORTD.3;
bit RD2			@ PORTD.2;
bit RD1			@ PORTD.1;
bit RD0			@ PORTD.0;

bit PORTD7			@ PORTD.7;
bit PORTD6			@ PORTD.6;
bit PORTD5			@ PORTD.5;
bit PORTD4			@ PORTD.4;
bit PORTD3			@ PORTD.3;
bit PORTD2			@ PORTD.2;
bit PORTD1			@ PORTD.1;
bit PORTD0			@ PORTD.0;

/*	DDRD bits	*/
bit DDRD7			@ DDRD.7;
bit DDRD6			@ DDRD.6;
bit DDRD5			@ DDRD.5;
bit DDRD4			@ DDRD.4;
bit DDRD3			@ DDRD.3;
bit DDRD2			@ DDRD.2;
bit DDRD1			@ DDRD.1;
bit DDRD0			@ DDRD.0;

/*      PORTE bits      */
bit RE7			@ PORTE.7;
bit RE6			@ PORTE.6;
bit RE5			@ PORTE.5;
bit RE4			@ PORTE.4;
bit RE3			@ PORTE.3;
bit RE2			@ PORTE.2;
bit RE1			@ PORTE.1;
bit RE0			@ PORTE.0;

bit PORTE7			@ PORTE.7;
bit PORTE6			@ PORTE.6;
bit PORTE5			@ PORTE.5;
bit PORTE4			@ PORTE.4;
bit PORTE3			@ PORTE.3;
bit PORTE2			@ PORTE.2;
bit PORTE1			@ PORTE.1;
bit PORTE0			@ PORTE.0;

/*	DDRE bits	*/
bit DDRE7			@ DDRE.7;
bit DDRE6			@ DDRE.6;
bit DDRE5			@ DDRE.5;
bit DDRE4			@ DDRE.4;
bit DDRE3			@ DDRE.3;
bit DDRE2			@ DDRE.2;
bit DDRE1			@ DDRE.1;
bit DDRE0			@ DDRE.0;

/*	PIR1 bits	*/
bit CRYPTOIF		@ PIR1.5;
bit CRPTIF			@ PIR1.5;
bit EEPROMIF		@ PIR1.4;
bit NANDIF			@ PIR1.3;
bit USBIF			@ PIR1.2;
bit TX1IF			@ PIR1.1;
bit RC1IF			@ PIR1.0;

/*	PIE1 bits	*/
bit CRYPTOIE		@ PIE1.5;
bit CRPTIE			@ PIE1.5;
bit EEIE			@ PIE1.4;
bit EEPROMIE		@ PIE1.4;
bit NANDIE			@ PIE1.3;
bit USBIE			@ PIE1.2;
bit TXIE			@ PIE1.1;
bit RCIE			@ PIE1.0;

/*	EP1_STAT bits	*/
bit BLK1			@ EP1_STAT.5;
bit BLK1_DATA		@ EP1_STAT.5;
bit ACTIV1			@ EP1_STAT.4;
bit FULL1			@ EP1_STAT.1;
bit EMPTY1			@ EP1_STAT.0;

/*	EP2_STAT bits	*/
bit BLK2			@ EP2_STAT.5;
bit BLK2_DATA		@ EP2_STAT.5;
bit ACTIV2			@ EP2_STAT.4;
bit FULL2			@ EP2_STAT.1;
bit EMPTY2			@ EP2_STAT.0;

/*	EP1_CFG2 bits	*/
bit BLOCK_EP1		@ EP1_CFG2.6;
bit TYPE1_EP1		@ EP1_CFG2.5;
bit TYPE0_EP1		@ EP1_CFG2.4;
bit MODE2_EP1		@ EP1_CFG2.3;
bit MODE1_EP1		@ EP1_CFG2.2;
bit MODE0_EP1		@ EP1_CFG2.1;

/*	EP2_CFG2 bits	*/
bit BLOCK_EP2		@ EP2_CFG2.6;
bit TYPE1_EP2		@ EP2_CFG2.5;
bit TYPE0_EP2		@ EP2_CFG2.4;
bit MODE2_EP2		@ EP2_CFG2.3;
bit MODE1_EP2		@ EP2_CFG2.2;
bit MODE0_EP2		@ EP2_CFG2.1;

/*	USB_ERROR bits	*/
bit BUS_ERR			@ USB_ERROR.7;
bit DROP_FRM		@ USB_ERROR.6;
bit TO_ERR			@ USB_ERROR.5;
bit SEQ_ERR			@ USB_ERROR.4;
bit NSE_ERR			@ USB_ERROR.3;
bit PID_ERR			@ USB_ERROR.2;
bit CRC16_ERR		@ USB_ERROR.1;
bit CRC5_ERR		@ USB_ERROR.0;

/*	USB_STAT bits	*/
bit ADR_SET			@ USB_STAT.6;
bit CONF_SET		@ USB_STAT.5;
bit USB_RST			@ USB_STAT.4;
bit EP_SEL2			@ USB_STAT.3;
bit EP_SEL1			@ USB_STAT.2;
bit EP_SEL0			@ USB_STAT.1;
bit USB_BUSY		@ USB_STAT.0;

bit EP2_SEL			@ USB_STAT.3;
bit EP1_SEL			@ USB_STAT.2;
bit EP0_SEL			@ USB_STAT.1;

/*	USB_CTRL bits	*/
bit USB_TEST2		@ USB_CTRL.3;
bit USB_TEST1		@ USB_CTRL.2;
bit USB_TEST		@ USB_CTRL.2;
bit FULLOW			@ USB_CTRL.1;
bit FULL_LOW		@ USB_CTRL.1;
bit USB_EN			@ USB_CTRL.0;

/*	USB_IE1 bits	*/
bit EP2_FULL_IE		@ USB_IE1.3;
bit EP2_EMPTY_IE		@ USB_IE1.2;
bit EP1_FULL_IE		@ USB_IE1.1;
bit EP1_EMPTY_IE		@ USB_IE1.0;

/*	USB_IE2 bits	*/
bit USB_RST_IE		@ USB_IE2.7;
bit USB_BUSY_IE		@ USB_IE2.6;

/*	USB_IE3 bits	*/
bit BUS_ERR_IE		@ USB_IE3.7;
bit DROP_IE			@ USB_IE3.6;
bit DROP_FRM_IE		@ USB_IE3.6;
bit TO_ERR_IE		@ USB_IE3.5;
bit SEQ_ERR_IE		@ USB_IE3.4;
bit NSE_ERR_IE		@ USB_IE3.3;
bit PID_ERR_IE		@ USB_IE3.2;
bit CRC16_ERR_IE		@ USB_IE3.1;
bit CRC5_ERR_IE		@ USB_IE3.0;

/*	USB_IE4 bits	*/
bit USB_ALL_IE		@ USB_IE4.3;
bit ADR_SET_IE		@ USB_IE4.1;
bit CONF_SET_IE		@ USB_IE4.0;

/*    NAND_MODE bits	*/
bit EN_NAND			@ NAND_MODE.7;
bit LOW_SPEED		@ NAND_MODE.6;
bit LOW_SPEED_NAND	@ NAND_MODE.6;
bit IE_BUSY_NAND		@ NAND_MODE.5;
bit BUSY_NAND		@ NAND_MODE.4;
bit MODE_NAND3		@ NAND_MODE.3;
bit MODE3_NAND		@ NAND_MODE.3;
bit MODE_NAND2		@ NAND_MODE.2;
bit MODE2_NAND		@ NAND_MODE.2;
bit MODE_NAND1		@ NAND_MODE.1;
bit MODE1_NAND		@ NAND_MODE.1;
bit MODE_NAND0		@ NAND_MODE.0;
bit MODE0_NAND		@ NAND_MODE.0;

/*    EEPROM_CONT bits	*/
bit EETEST			@ EEPROM_CONT.6;
bit CPTEST			@ EEPROM_CONT.5;
bit VEE2			@ EEPROM_CONT.4;
bit VEE1			@ EEPROM_CONT.3;
bit BRG2			@ EEPROM_CONT.2;
bit BRG1			@ EEPROM_CONT.1;
bit BRG0			@ EEPROM_CONT.0;

/*    EEPROM_MODE bits	*/
bit EN_EE			@ EEPROM_MODE.7;
bit IE_BUSY_EE		@ EEPROM_MODE.5;
bit BUSY_EE			@ EEPROM_MODE.4;
bit MODE_EE2		@ EEPROM_MODE.2;
bit MODE2_EE		@ EEPROM_MODE.2;
bit MODE_EE1		@ EEPROM_MODE.1;
bit MODE1_EE		@ EEPROM_MODE.1;
bit MODE_EE0		@ EEPROM_MODE.0;
bit MODE0_EE		@ EEPROM_MODE.0;

/*    CRPT_CWR  bits	*/
bit BIST			@ CRPT_CWR.7;
bit RST			@ CRPT_CWR.6;
bit CRPT_IE			@ CRPT_CWR.5;
bit IE_CRPT			@ CRPT_CWR.5;
bit DIR			@ CRPT_CWR.4;
bit START			@ CRPT_CWR.3;
bit IM			@ CRPT_CWR.2;
bit MODE_CRPT1		@ CRPT_CWR.1;
bit MODE1_CRPT		@ CRPT_CWR.1;
bit MODE_CRPT0		@ CRPT_CWR.0;
bit MODE0_CRPT		@ CRPT_CWR.0;

/*    CRPT_SR  bits	*/
bit DNC_BIST		@ CRPT_SR.7;
bit CRPT_ERROR		@ CRPT_SR.1;
bit ERROR_CRPT		@ CRPT_SR.1;
bit READY			@ CRPT_SR.0;
bit READY_CRPT		@ CRPT_SR.0;

/*    CRPT_ITER  bits	*/
bit	   EN_CRPT   	@ CRPT_SR.6;

/*	UNBANK bits:	*/
/*	ALUSTA bits	*/
bit FS3			@ ALUSTA.7;
bit FS2			@ ALUSTA.6;
bit FS1			@ ALUSTA.5;
bit FS0			@ ALUSTA.4;
bit OV			@ ALUSTA.3;
bit Z				@ ALUSTA.2;
bit C				@ ALUSTA.0;

/*	T0STA bits	*/
bit T0PS0			@ T0STA.1;
bit PS0			@ T0STA.1;
bit T0PS1			@ T0STA.2;
bit PS1			@ T0STA.2;
bit T0PS2			@ T0STA.3;
bit PS2			@ T0STA.3;
bit T0PS3			@ T0STA.4;
bit PS3			@ T0STA.4;
bit T0CS			@ T0STA.5;
bit T0SE			@ T0STA.6;
bit INTEDG			@ T0STA.7;

/*	CPUSTA bits	*/
bit BOR_			@ CPUSTA.0;
bit BOR			@ CPUSTA.0;
bit POR_			@ CPUSTA.1;
bit POR			@ CPUSTA.1;
bit PD			@ CPUSTA.2;
bit TO			@ CPUSTA.3;
bit GLINTD			@ CPUSTA.4;
bit STKAV			@ CPUSTA.5;
bit ESLP			@ CPUSTA.6;

/*	INTSTA bits	*/
bit INTE			@ INTSTA.0;
bit T0IE			@ INTSTA.1;
bit T0CKIE			@ INTSTA.2;
bit PEIE			@ INTSTA.3;
bit INTF			@ INTSTA.4;
bit T0IF			@ INTSTA.5;
bit T0CKIF			@ INTSTA.6;
bit PEIF			@ INTSTA.7;

#define DebugBreakPoint #asm \
DW 0x7E02,0x7D03,0x2903,0xFFB8 \
#endasm \
