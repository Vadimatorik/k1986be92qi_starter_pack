shrBank char dbgBSR @ 0x1F;
shrBank char dbgPCL @ 0x1E;
shrBank char dbgPCLATH @ 0x1D;
char dbgALU @ 0x3FC;
char dbgFSR @ 0x3FE;
char dbgWRG @ 0x3FF;
char dbgByte @ 0x3FA;

void dbgoutport();
void dbginport();
#pragma origin 0x1FB8
void DebugPoint()
{
#asm
    movfp BSR,dbgBSR
	movlr 3
    movwf dbgWRG
	movpf ALUSTA,dbgALU
	movpf FSR0,dbgFSR
#endasm
	TXSTA1 = 0x10; //SYNC,Slave
    RCSTA1 = 0x90; //SPEN,CREN	    
    while(RC1IF){WREG = RCREG1;}
    dbginport();
    dbgByte = WREG;
#asm
sel_mode:
	call	dbginport ;movlb 0
	movlr	3         ;Restore BSR! 
	movwf	dbgByte
	movlw	0x55
	cpfseq	dbgByte
	goto	no_55
	call	dbginport	; 55h, BSR, Addr
	movwf	dbgByte
	call	dbginport
	movwf	FSR0
	movfp	dbgByte,BSR
	movfp	INDF0,W
	call	dbgoutport
	goto	sel_mode
no_55:
	movlw	0xAA 
	cpfseq	dbgByte
	goto	no_AA
	call	dbginport	; AAh, BSR, Addr, Data, out:0Fh
	movwf	dbgByte
	call	dbginport
	movwf	FSR0
	call	dbginport
	movfp	dbgByte,BSR
	movpf	W,INDF0
	movlw	0xF0
	call	dbgoutport
	goto	sel_mode
no_AA:
	movlw	0x0F0	; F0h return
	cpfseq	dbgByte  
	goto	sel_mode
;	
	movfp dbgFSR,FSR0
	movfp dbgPCL,PCLATH
	movfp dbgALU,ALUSTA
    movfp dbgWRG,WREG
    movfp dbgBSR,BSR
#endasm
}
void dbginport()
{    while(!RC1IF);
    WREG = RCREG1;}
void dbgoutport()
{   CREN1=0; //RCSTA1
	TXEN1=1; //TXSTA1
    TXREG1 = WREG;
    while(!TRMT1);
    TXEN1=0; //TXSTA1
    CREN1=1; //RCSTA1
}
