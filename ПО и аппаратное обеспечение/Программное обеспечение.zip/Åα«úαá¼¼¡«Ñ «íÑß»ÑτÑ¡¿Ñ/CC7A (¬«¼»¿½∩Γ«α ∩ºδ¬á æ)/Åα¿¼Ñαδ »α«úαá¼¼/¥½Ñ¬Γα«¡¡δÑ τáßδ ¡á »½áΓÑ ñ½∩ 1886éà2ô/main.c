
#include <VE2_CC.h>
#pragma taskOptions 1
//#pragma taskOptions 2
//#pragma taskOptions 3

static unsigned  int i;

static unsigned  char secRTC;
static unsigned  char minRTC;
static unsigned  char hourRTC;

static unsigned  char secSW;
static unsigned  char minSW;
static unsigned  char hourSW;

static unsigned  char secAC;
static unsigned  char minAC;
static unsigned  char hourAC;

static unsigned  char sec;
static unsigned  char min;
static unsigned  char hour;
          
unsigned char CodWords[16];
unsigned char Separator;

unsigned char WrkState;
unsigned char Inc;

Task  Display(void)
{   sec  = 0x00;
    min  = 0x00;
    hour = 0x00;
    
    while(1)
    {
     if         (WrkState  ==   0x00)
                     { sec  = secRTC;
                       min  = minRTC;
                       hour = hourRTC;}
     else  if   (WrkState  ==   0x01)
                     { sec  = secSW;
                       min  = minSW;
                       hour = hourSW;}
     else      
                     { sec  = secAC;
                       min  = minAC;
                       hour = hourAC;}
     
     PORTC =   0x00; 
     PORTC =   CodWords[sec&0x0F];
     PORTD =   0x08;
     for  (i=0;i<=2;i++)    PORTD =   0x00;   //sec low;

     PORTC =   0x00; 
     PORTC =   CodWords[sec>>4];
     PORTD =   0x04;
     for  (i=0;i<=2;i++)    PORTD =   0x00;  //sec high;     
          
     PORTC =   0x00; 
     PORTC =   Separator;
     PORTD =   0x02;
     for  (i=0;i<=2;i++)  PORTD =   0x00;  //separator;

     PORTC =   0x00; 
     PORTC =   CodWords[min&0x0F];
     PORTD =   0x01;
     for  (i=0;i<=2;i++)  PORTD =   0x00;//min high;

     PORTC =   0x00; 
     PORTC =   CodWords[min>>4];
     PORTD =   0x10;
     for  (i=0;i<=2;i++)  PORTD =   0x00;//min low;
     
     PORTC =   0x00; 
     PORTC =   Separator;
     PORTD =   0x20;
     for  (i=0;i<=2;i++)  PORTD =   0x00;//separator;

     PORTC =   0x00; 
     PORTC =   CodWords[hour&0x0F];
     PORTD =   0x40;
     for  (i=0;i<=2;i++)   PORTD =   0x00;//hour high;
     
     PORTC =   0x00; 
     PORTC =   CodWords[hour>>4];
     PORTD =   0x80;
     for  (i=0;i<=2;i++)     PORTD =   0x00;//hour low;
     waitState();
    }
}

Task  AC(void)
{
while(1)
{   while(!((RE2  == 0) && (RE3 == 1) && (WrkState == 0x02)))
      {
       if ((RE1  == 0) && (RE3 == 1) && (WrkState == 0x02))
        { switch (secAC)
            {case 0x09: secAC=0x10;
                        break;
             case 0x19: secAC=0x20;
                        break;            
             case 0x29: secAC=0x30;
                        break;
             case 0x39: secAC=0x40;
                        break;
             case 0x49: secAC=0x50;
                        break;
             case 0x59: secAC=0x00;
                        break;
             default:   secAC++;
                        break;}
         while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0x02)));
         while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0x02)));
         while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0x02)));
                 }
      if ((RE0  == 0) && (RE3 == 1) && (WrkState == 0x02)) 
      { switch (secAC)
            {case 0x00: secAC=0x59;
                        break;
             case 0x50: secAC=0x49;
                        break;            
             case 0x40: secAC=0x39;
                        break;
             case 0x30: secAC=0x29;
                        break;
             case 0x20: secAC=0x19;
                        break;
             case 0x10: secAC=0x09;
                        break;
             default:   secAC--;
                        break;}
       while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0x02)));
       while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0x02)));
       while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0x02)));
      }
       waitState();  
      }
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0x02)));
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0x02)));
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0x02)));
     
     while(!((RE2  == 0) && (RE3 == 1) && (WrkState == 0x02)))
      {
       if ((RE1  == 0) && (RE3 == 1) && (WrkState == 0x02))
        { switch (minAC)
            {case 0x09: minAC=0x10;
                        break;
             case 0x19: minAC=0x20;
                        break;            
             case 0x29: minAC=0x30;
                        break;
             case 0x39: minAC=0x40;
                        break;
             case 0x49: minAC=0x50;
                        break;
             case 0x59: minAC=0x00;
                        break;
             default:   minAC++;
                        break;}
         while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0x02)));
         while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0x02)));
         while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0x02)));
       }
      
      if ((RE0  == 0) && (RE3 == 1) && (WrkState == 0x02)) 
      { switch (minAC)
            {case 0x00: minAC=0x59;
                        break;
             case 0x50: minAC=0x49;
                        break;            
             case 0x40: minAC=0x39;
                        break;
             case 0x30: minAC=0x29;
                        break;
             case 0x20: minAC=0x19;
                        break;
             case 0x10: minAC=0x09;
                        break;
             default:   minAC--;
                        break;
              }
               
        while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0x02)));
        while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0x02)));
        while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0x02)));
      }
        waitState();  
     }
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0x02)));
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0x02)));
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0x02)));
     
     while(!((RE2  == 0) && (RE3 == 1) && (WrkState == 0x02)))
      {
       if ((RE1  == 0) && (RE3 == 1) && (WrkState == 0x02))
        { switch (hourAC)
            {case 0x09: hourAC=0x10;
                        break;
             case 0x19: hourAC=0x20;
                        break;            
             case 0x23: hourAC=0x00;
                        break;
             default:   hourAC++;
                        break;}
           while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0x02)));
           while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0x02)));
           while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0x02)));
        }
       if ((RE0  == 0) && (RE3 == 1) && (WrkState == 0x02)) 
       { switch (hourAC)
           {case 0x00: hourAC=0x23;
                       break;
            case 0x20: hourAC=0x19;
                       break;            
            case 0x10: hourAC=0x09;
                       break;
            default:   hourAC--;
                       break;}
          while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0x02)));
          while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0x02)));
          while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0x02)));
       }
    
       waitState();  
      }
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0x02)));
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0x02)));
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0x02)));
     
     while(!((RE2  == 0) && (RE3 == 1) && (WrkState == 0x02)))
     {if ((secRTC==secAC)&&(minRTC==minAC)&&(hourRTC==hourAC))
       {
            PORTF = 0x00;
            waitState();
       }
     waitState();
       }
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0x02)));
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0x02)));
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0x02)));
     PORTF = 0xFF;
}      
}


Task  SW(void)
   { 

     while(!((RE0  == 0) && (RE3 == 1) && (WrkState == 1))) 
     {
     if((RE2 == 0) && (RE3 == 1) && (WrkState == 1))
             {
             secSW  = 0x00;
             minSW  = 0x00;
             hourSW = 0x00;
          }
     waitState();
     }
     
     while(!((RE1  == 0) && (RE3 == 1) && (WrkState == 1)))
     {
     if(!((RE2 == 0) && (RE3 == 1) && (WrkState == 1)))
     {
       if(Inc == 0xFF)
             { switch (secSW)
                       {
                           case 0x09: secSW=0x10;
                                      break;
                           case 0x19: secSW=0x20;
                                      break;            
                           case 0x29: secSW=0x30;
                                      break;
                           case 0x39: secSW=0x40;
                                      break;
                           case 0x49: secSW=0x50;
                                      break;
                           case 0x59: secSW=0x00;
                                      break;
                           default:   secSW++;
                                      break; 
                        }
                
               if(secSW  ==  0x00)
                      {                        
                          switch (minSW)
                                  {case 0x09: minSW=0x10;
                                              break;
                                   case 0x19: minSW=0x20;
                                              break;            
                                   case 0x29: minSW=0x30;
                                              break;
                                   case 0x39: minSW=0x40;
                                              break;
                                   case 0x49: minSW=0x50;
                                              break;
                                   case 0x59: minSW=0x00;
                                              break;
                                   default:   minSW++;
                                              break;}
                         if(minSW  ==  0x00)
                             {   hourSW    =   hourSW+1;
                                 if         (hourSW == 0x0A) hourSW = 0x10;
                                 else if    (hourSW == 0x1A) hourSW = 0x20;
                                 else if    (hourSW == 0x24) hourSW = 0x00;
                                 else;
                             }
                         else; 
                      }
                 else;
                 }
       else;
     }
     else 
     {
          secSW  = 0x00;
          minSW  = 0x00;
          hourSW = 0x00;
     }
     waitState();
     }
  }




Task  RTC(void)
   { 
     while(!((RE2  == 0) && (RE3 == 1) && (WrkState == 0)))
     {
      if(Inc == 0xFF)
             { switch (secRTC)
                       {
                           case 0x09: secRTC=0x10;
                                      break;
                           case 0x19: secRTC=0x20;
                                      break;            
                           case 0x29: secRTC=0x30;
                                      break;
                           case 0x39: secRTC=0x40;
                                      break;
                           case 0x49: secRTC=0x50;
                                      break;
                           case 0x59: secRTC=0x00;
                                      break;
                           default:   secRTC++;
                                      break; 
                        }
                
               if(secRTC  ==  0x00)
                      {                        
                          switch (minRTC)
                                  {case 0x09: minRTC=0x10;
                                              break;
                                   case 0x19: minRTC=0x20;
                                              break;            
                                   case 0x29: minRTC=0x30;
                                              break;
                                   case 0x39: minRTC=0x40;
                                              break;
                                   case 0x49: minRTC=0x50;
                                              break;
                                   case 0x59: minRTC=0x00;
                                              break;
                                   default:   minRTC++;
                                              break;}
                         if(minRTC  ==  0x00)
                             {   hourRTC    =   hourRTC+1;
                                 if         (hourRTC == 0x0A) hourRTC = 0x10;
                                 else if    (hourRTC == 0x1A) hourRTC = 0x20;
                                 else if    (hourRTC == 0x24) hourRTC = 0x00;
                                 else;
                             }
                         else; 
                      }
               else;
             }
      else;
     waitState();
     }
     
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0)));
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0)));
     
     while(!((RE2  == 0) && (RE3 == 1) && (WrkState == 0)))
      {
       if ((RE1  == 0) && (RE3 == 1) && (WrkState == 0))
        { switch (secRTC)
            {case 0x09: secRTC=0x10;
                        break;
             case 0x19: secRTC=0x20;
                        break;            
             case 0x29: secRTC=0x30;
                        break;
             case 0x39: secRTC=0x40;
                        break;
             case 0x49: secRTC=0x50;
                        break;
             case 0x59: secRTC=0x00;
                        break;
             default:   secRTC++;
                        break;}
         while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0)));
         while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0)));
         while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0)));
                 }
      if ((RE0  == 0) && (RE3 == 1) && (WrkState == 0)) 
      { switch (secRTC)
            {case 0x00: secRTC=0x59;
                        break;
             case 0x50: secRTC=0x49;
                        break;            
             case 0x40: secRTC=0x39;
                        break;
             case 0x30: secRTC=0x29;
                        break;
             case 0x20: secRTC=0x19;
                        break;
             case 0x10: secRTC=0x09;
                        break;
             default:   secRTC--;
                        break;}
         while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0)));
         while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0)));
         while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0)));
      }
       waitState();  
     }
     
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0)));
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0)));
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0)));
         
     
     while(!((RE2  == 0) && (RE3 == 1) && (WrkState == 0)))
      {
       if ((RE1  == 0) && (RE3 == 1) && (WrkState == 0))
        { switch (minRTC)
            {case 0x09: minRTC=0x10;
                        break;
             case 0x19: minRTC=0x20;
                        break;            
             case 0x29: minRTC=0x30;
                        break;
             case 0x39: minRTC=0x40;
                        break;
             case 0x49: minRTC=0x50;
                        break;
             case 0x59: minRTC=0x00;
                        break;
             default:   minRTC++;
                        break;}
         while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0)));
         while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0)));
         while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0)));
       }
      
      if ((RE0  == 0) && (RE3 == 1) && (WrkState == 0)) 
      { switch (minRTC)
            {case 0x00: minRTC=0x59;
                        break;
             case 0x50: minRTC=0x49;
                        break;            
             case 0x40: minRTC=0x39;
                        break;
             case 0x30: minRTC=0x29;
                        break;
             case 0x20: minRTC=0x19;
                        break;
             case 0x10: minRTC=0x09;
                        break;
             default:   minRTC--;
                        break;
              }
        while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0)));
        while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0)));
        while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0)));
      }
        waitState();  
     }

     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0)));
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0)));
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0)));
     
     while(!((RE2  == 0) && (RE3 == 1) && (WrkState == 0)))
      {
       if ((RE1  == 0) && (RE3 == 1) && (WrkState == 0))
        { switch (hourRTC)
            {case 0x09: hourRTC=0x10;
                        break;
             case 0x19: hourRTC=0x20;
                        break;            
             case 0x23: hourRTC=0x00;
                        break;
             default:   hourRTC++;
                        break;}
           while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0)));
           while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0)));
           while(!((RE1  == 1) && (RE3 == 1) && (WrkState == 0)));
        }
       if ((RE0  == 0) && (RE3 == 1) && (WrkState == 0)) 
       { switch (hourRTC)
           {case 0x00: hourRTC=0x23;
                       break;
            case 0x20: hourRTC=0x19;
                       break;            
            case 0x10: hourRTC=0x09;
                       break;
            default:   hourRTC--;
                       break;}
          while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0)));
          while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0)));
          while(!((RE0  == 1) && (RE3 == 1) && (WrkState == 0)));
       }
    
       waitState();  
      }
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0)));
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0)));
     while(!((RE2  == 1) && (RE3 == 1) && (WrkState == 0)));
     }


void main(void)

{
   CodWords[0]    = 0x3F; CodWords[1]  = 0x06;  CodWords[2]    = 0x5B;  CodWords[3]    = 0x4F;
   CodWords[4]    = 0x66; CodWords[5]  = 0x6D;  CodWords[6]    = 0x7D;  CodWords[7]    = 0x07;
   CodWords[8]    = 0x7F; CodWords[9]  = 0x6F;  CodWords[10]   = 0xF7;  CodWords[11]   = 0xFF;
   CodWords[12]   = 0xB9; CodWords[13] = 0xBF;  CodWords[14]   = 0xF9;  CodWords[15]   = 0xF1;   
   
   Separator      = 0x40;
   
   T0STA     =    0xF0;   
   TMR0H     =    0x00;
   TMR0L     =    0x00;
       
   DDRC      =   0x00;
   DDRD      =   0x00;
   DDRF      =   0x00;
   PORTC     =   0xFF;
   PORTD     =   0xFF;
   PORTF     =   0x00;
   WrkState  =   0x00;

   secRTC    =  0x00;
   minRTC    =  0x00;
   hourRTC   =  0x00;
   
   secSW    =  0x00;
   minSW    =  0x00;
   hourSW   =  0x00;

   secAC    =  0x00;
   minAC    =  0x00;
   hourAC   =  0x00;

   PORTF     =   0xFF;

   startTask(Display);   
   startTask(SW);
   startTask(RTC);
   startTask(AC);
 
   while(1)
     {    if      (RE3==0)
          {
          if      (RE0==0)  WrkState  =   0x00;
          else if (RE1==0)  WrkState  =   0x01;
          else if (RE2==0)  WrkState  =   0x02;
          else;
          }
          else;

          
          if(TMR0H   >=  0x3D)
          if(TMR0L   >=  0x09) 
             {   TMR0H     =   0x00;
                 TMR0L     =   0x00;
                 Inc       =   0xFF;
             }
          else Inc = 0x00;
          else Inc = 0x00;
         
          taskSlicer(); 
     }

}


