#include <mil1886BE5.h>
#include "can.h"
 
void Send_Frame(char box,unsigned long int ID, char DLC, char R1,char R0, char RTR, char SSR, char IDE,
                char DB0,char DB1,char DB2,char DB3,char DB4,char DB5,char DB6, char DB7)
{
Init_Frame(box,ID, DLC, R1,R0, RTR, SSR, IDE,DB0,DB1,DB2,DB3,DB4,DB5,DB6,DB7);
Transmit_Frame(box);
Wait_Transmit_Frame(box);
}

void Transmit_Frame(char box)
{
	CAN_BSR = box & 0x07;
	CAN_RXSTAT = 0;
	CAN_BUFSTAT = 1;
	CAN_TXSTAT = 0x08;
}

void Wait_Transmit_Frame(char box)
{
	CAN_BSR = box & 0x07;
	while(!TX_BIF){
//	PORTC = CAN_TXERRCNT;
	}
	CAN_RXSTAT = 0;
	CAN_TXSTAT = 0;
	CAN_BUFSTAT = 0;
}

void Init_Frame(char box,unsigned long int ID, char DLC, char R1,char R0, char RTR, char SSR, char IDE,
                char DB0,char DB1,char DB2,char DB3,char DB4,char DB5,char DB6, char DB7)
{
	CAN_BSR = box & 0x07;
	CAN_RXSTAT = 0;
	CAN_TXSTAT = 0;
	CAN_BUFSTAT = 0;

	CAN_DB0 = DB0;
	CAN_DB1 = DB1;
	CAN_DB2 = DB2;
	CAN_DB3 = DB3;
	CAN_DB4 = DB4;
	CAN_DB5 = DB5;
	CAN_DB6 = DB6;
	CAN_DB7 = DB7;
	CAN_DLC = (DLC & 0x0f) | ((RTR & 0x01)<<6) | ((R1 & 0x01)<<5) |((R0 & 0x01)<<4) ;

	if (IDE > 0x00)
	{
	CAN_ID0 = (ID >> 21) & 0xFF;
	CAN_ID1 = (((ID >> 16) & 0x03) | ((ID >> 13) & 0xE0) | ((SSR & 0x01) << 4) | ((IDE & 0x01) << 3));
	CAN_ID2 = (ID  >> 8) & 0xFF; 
	CAN_ID3 = ID & 0xFF;
	}
	else
	{
	CAN_ID0 = ( ID >> 3) & 0xFF;
	CAN_ID1 = ( (((ID & 0x07) << 5) & 0xE0) | ((SSR & 0x01) << 4) | ((IDE & 0x01) << 3));
	}
}

void SetSpeed(char BRP,char PSEG, char SEG1, char SEG2, char SJW, char SAM)
{
	CAN_BRG1 = (BRP & 0x3F) | ((SJW & 0x03) << 6);
	CAN_BRG2 = (PSEG & 0x07) | ((SEG1 & 0x07) <<3) | ((SAM & 0x01)<<6);
	CAN_BRG3 = (SEG2 & 0x07);
}

void Rec_Frame(char box,unsigned long int* ID, char* DLC, char* R1,char* R0, char* RTR, char* SSR, char* IDE,
                char* DB0,char* DB1,char* DB2,char* DB3,char* DB4,char* DB5,char* DB6, char* DB7)
{
Reciv_Frame(box,0);
Wait_Reciv_Frame(box);
Get_Frame(box,ID,DLC, R1,R0,RTR,SSR,IDE,DB0,DB1,DB2,DB3,DB4,DB5,DB6,DB7);
}

void Reciv_Frame(char box, char MASK)
{
	CAN_BSR = box & 0x07;
	CAN_RXSTAT = 0;
	CAN_RXSTAT = MASK & 0x07;
	CAN_BUFSTAT = 3;
}

void Wait_Reciv_Frame (char box)
{
	CAN_BSR = box & 0x07;
	while (!RX_FULL) {}
}

void Get_Frame(char box,unsigned long int* ID, char* DLC, char* R1,char* R0, char* RTR, char* SSR, char* IDE,
                char* DB0,char* DB1,char* DB2,char* DB3,char* DB4,char* DB5,char* DB6, char* DB7)
{
	CAN_BSR = box & 0x07;
	
	if ( ((CAN_ID1 & 0x08) >> 3) == 1)
	*ID =  ((unsigned long int)CAN_ID0 << 21) | (((unsigned long int)CAN_ID1 & 0x03) <<16) | (((unsigned long int)CAN_ID1 & 0xE0) <<13) | ((unsigned long int)CAN_ID2 <<8) |((unsigned long int)CAN_ID3);
	else
	*ID =  ((unsigned long int)CAN_ID0 << 3) | ((unsigned long int)CAN_ID1 & 0xE0);

	*SSR = (CAN_ID1 & 0x10) >> 4;
	*IDE = (CAN_ID1 & 0x08) >> 3;
	*RTR = (CAN_DLC & 0x40) >> 6;
	*R1 =  (CAN_DLC & 0x20) >> 5;
	*R0 =  (CAN_DLC & 0x10) >> 4;
	*DLC =  (CAN_DLC & 0x0F);

	*DB0 = CAN_DB0;
	*DB1 = CAN_DB1;
	*DB2 = CAN_DB2;
	*DB3 = CAN_DB3;
	*DB4 = CAN_DB4;
	*DB5 = CAN_DB5;
	*DB6 = CAN_DB6;
	*DB7 = CAN_DB7;

	CAN_RXSTAT = 0;
	CAN_TXSTAT = 0;
	CAN_BUFSTAT = 0;
}

void Set_Filter (char fil, unsigned long int Mask, unsigned long int Filter, char IDE, char SSR, char EIDE, char ESSR)
{
	CAN_BSR = (fil & 0x01)<<4;
	
	if (IDE > 0x00)
	{
	CAN_FILTER_HH = (Filter >> 21) & 0xFF;
	CAN_FILTER_HL = (((Filter >> 16) & 0x03) | ((Filter >> 13) & 0xE0) | ((SSR & 0x01) << 4) | ((IDE & 0x01) << 3));
	CAN_FILTER_LH = (Filter  >> 8) & 0xFF; 
	CAN_FILTER_LL = Filter & 0xFF;

	CAN_MASK_HH = (Mask >> 21) & 0xFF;
	CAN_MASK_HL = (((Mask >> 16) & 0x03) | ((Mask >> 13) & 0xE0) | ((ESSR & 0x01) << 4) | ((EIDE & 0x01) << 3));
	CAN_MASK_LH = (Mask  >> 8) & 0xFF; 
	CAN_MASK_LL = Mask & 0xFF;

	}
	else
	{
	CAN_FILTER_HH = ( Filter >> 3) & 0xFF;
	CAN_FILTER_HL = ( (((Filter & 0x07) << 5) & 0xE0) | ((IDE & 0x01) << 3));
	CAN_FILTER_LH = 0x00;
	CAN_FILTER_LL = 0x00;

	CAN_MASK_HH = ( Mask >> 3) & 0xFF;
	CAN_MASK_HL = ( (((Mask & 0x07) << 5) & 0xE0) | ((EIDE & 0x01) << 3));
	CAN_MASK_LH = 0x00;
	CAN_MASK_LL = 0x00;
	}
}
/*
char Wait_Any_Reciv_Frame()
{
char i;
	do
	{
	CAN_BSR = i;
	if (i==5) i=0;
	else i=i+1;
	}
	while (!RX_FULL);

if (i==0) i=5;
else i=i-1;

return i;
}

char Wait_Any_Transmit_Frame()
{
char i;
	do
	{
	CAN_BSR = i;
	if (i==5) i=0;
	else i=i+1;
	}
	while (!TX_BIF);

if (i==0) i=5;
else i=i-1;

return i;
}
*/
void Init_USART(char BRG, char SYNC, char TXEN, char CREN, char SREN, char CSRC, char RX9, char TX9)
{
RCSTA1 = 0;
SPBRG1 = BRG;
TXSTA1 = ((CSRC & 0x01) << 7) | ((TX9 & 0x01) << 6) |((TXEN & 0x01) << 5) |((SYNC & 0x01) << 4);
RCSTA1 = ((RX9 & 0x01) << 6)  | ((SREN & 0x01) << 5) |((CREN & 0x01) << 4);
RCSTA1 = (RCSTA1 & 0x7F) | 0x80;
}

void EEPROM_On()
{
EE_CON = 0;
EE_MODE = 0x80;
while (EE_BUSY) {}
}

void EEPROM_Off()
{
while (EE_BUSY) {}
EE_MODE = 0x00;
}

void ReadEEPROM(char *DATA,char ADR)
{
EE_ADR = ADR;
EE_MODE = EE_MODE & 0xf8 | 0x1;
while (EE_BUSY) {}
*DATA = EE_DATA;
}

void WriteEEPROM (char DATA, char ADR)
{
EE_ADR = ADR;
EE_DATA = DATA;
EE_MODE = EE_MODE & 0xf8 | 0x2;
while (EE_BUSY) {}
}

void EraseRowEEPROM (char ADR)
{
EE_ADR = ADR;
EE_MODE = EE_MODE & 0xf8 | 0x3;
while (EE_BUSY) {}
}

void EraseAllEEPROM()
{
EE_MODE = EE_MODE & 0xf8 | 0x4;
while (EE_BUSY) {}
}
