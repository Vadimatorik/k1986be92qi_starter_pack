/*
 *	Header file for the Milandr :
 *	1886BE5 chip
 *	High-end Microcontroller
 *  21/05/08 add LIN_CTRL bits - LG
 */

static				unsigned	char	FSR0	@ 0x01;
static	volatile	unsigned	char	PCL		@ 0x02;
static	volatile	unsigned	char	PCLATH	@ 0x03;
static	volatile	unsigned	int		PC		@ 0x02;	// word version
static	volatile	unsigned	char	ALUSTA	@ 0x04;
static				unsigned	char	T0STA	@ 0x05;
static	volatile	unsigned	char	CPUSTA	@ 0x06;
static	volatile	unsigned	char	INTSTA	@ 0x07;
static	volatile	unsigned	char	INDF1	@ 0x08;
static				unsigned	char	FSR1	@ 0x09;
static	volatile	unsigned	char	WREG	@ 0x0A;
static	volatile	unsigned	char	TMR0L	@ 0x0B;
static	volatile	unsigned	char	TMR0H	@ 0x0C;
static	volatile	unsigned	int		TMR0	@ 0x0B;
static	volatile	unsigned	char	TBLPTRL	@ 0x0D;
static	volatile	unsigned	char	TBLPTRH	@ 0x0E;
static				unsigned	char	BSR		@ 0x0F;
static	volatile	unsigned	char	PRODL	@ 0x18;
static	volatile	unsigned	char	PRODH	@ 0x19;
static	volatile	unsigned	int		PROD	@ 0x18;	// word version

static				unsigned	char	DBG1	@ 0x0FF;
static				unsigned	char	DBG2	@ 0x1FF;
static				unsigned	char	DBG3	@ 0x2FF;
static				unsigned	char	DBG4	@ 0x3FF;



	/* Bank 0 */
static				unsigned	char	LIN_CTRL	@ 0x11;
static				unsigned	char	LIN_BRG	@ 0x12;
static	volatile	unsigned	char	RCSTA1	@ 0x13;
static	volatile	unsigned	char	RCREG1	@ 0x14;
static	volatile	unsigned	char	TXSTA1	@ 0x15;
static	volatile	unsigned	char	TXREG1	@ 0x16;
static				unsigned	char	SPBRG1	@ 0x17;

	/* Bank 1 */
static				unsigned	char	DDRA	@ 0x110;
static	volatile	unsigned	char	PORTA	@ 0x111;
static				unsigned	char	DDRC	@ 0x112;
static	volatile	unsigned	char	PORTC	@ 0x113;
static				unsigned	char	DDRD	@ 0x114;
static	volatile	unsigned	char	PORTD	@ 0x115;
static				unsigned	char	DDRE	@ 0x116;
static	volatile	unsigned	char	PORTE	@ 0x117;

	/* Bank 2 */
static	volatile	unsigned	char	TMR1	@ 0x210;
static	volatile	unsigned	char	TMR3L	@ 0x212;
static	volatile	unsigned	char	TMR3H	@ 0x213;
static	volatile	unsigned	int		TMR3	@ 0x212;	// word version

static				unsigned	char	PR1		@ 0x214;
static	volatile	unsigned	char	PR3L	@ 0x216;
static	volatile	unsigned	char	PR3H	@ 0x217;
#define	CA1L	PR3L
#define	CA1H	PR3H

	/* Bank 3 */
static				unsigned	char	PW1DCL	@ 0x310;
static				unsigned	char	PW2DCL	@ 0x311;
static				unsigned	char	PW1DCH	@ 0x312;
static				unsigned	char	PW2DCH	@ 0x313;
static	volatile	unsigned	char	CA2L	@ 0x314;
static	volatile	unsigned	char	CA2H	@ 0x315;
static				unsigned	char	TCON1	@ 0x316;
static	volatile	unsigned	char	TCON2	@ 0x317;
	
	/* Bank 4 */
static				unsigned	char	CAN_FILTER_HH	@ 0x410;
static				unsigned	char	CAN_FILTER_HL	@ 0x411;
static				unsigned	char	CAN_FILTER_LH	@ 0x412;
static				unsigned	char	CAN_FILTER_LL	@ 0x413;
static				unsigned	long	CAN_FILTER	@ 0x410;
static				unsigned	char	CAN_MASK_HH	@ 0x414;
static				unsigned	char	CAN_MASK_HL	@ 0x415;
static				unsigned	char	CAN_MASK_LH	@ 0x416;
static				unsigned	char	CAN_MASK_LL	@ 0x417;
static				unsigned	long	CAN_MASK	@ 0x414;
#define CAN_FILTER1	CAN_FILTER
#define	CAN_MASK1	CAN_MASK
#define CAN_FILTER2	CAN_FILTER
#define	CAN_MASK2	CAN_MASK

	/* Bank 5 */
static	volatile	unsigned	char	PIR1	@ 0x510;
static				unsigned	char	PIE1	@ 0x511;
static	volatile	unsigned	char	PIR2	@ 0x512;
static				unsigned	char	PIE2	@ 0x513;
static	volatile	unsigned	char	EE_CON	@ 0x514;
static	volatile	unsigned	char	EE_MODE	@ 0x515;
static	volatile	unsigned	char	EE_DATA	@ 0x516;
static				unsigned	char	EE_ADR	@ 0x517;


	/* Bank 6 */
static				unsigned	char	DBH		@ 0x610;
static				unsigned	char	DBL		@ 0x611;
static				unsigned	int		DB		@ 0x610;	// word version

static				unsigned	char	EE_DIV	@ 0x613;
static	volatile	unsigned	char	ADCON0	@ 0x614;
static				unsigned	char	ADCON1	@ 0x615;
static	volatile	unsigned	char	ADRESL	@ 0x616;
static	volatile	unsigned	char	ADRESH	@ 0x617;
static	volatile	unsigned	int		ADRES	@ 0x616;	// word version


	/* Bank 7 */
static	volatile	unsigned	char	CAN_CTRL	@ 0x710;
static	volatile	unsigned	char	CAN_STAT	@ 0x711;
static				unsigned	char	CAN_BRG1	@ 0x712;
static				unsigned	char	CAN_BRG2	@ 0x713;
static				unsigned	char	CAN_BRG3	@ 0x714;
static				unsigned	char	CAN_BSR		@ 0x715;
static	volatile	unsigned	char	CAN_RXERRCNT	@ 0x716;
static	volatile	unsigned	char	CAN_TXERRCNT	@ 0x717;

	/* Bank 8 */
static	volatile	unsigned	char	CAN_RXSTAT	@ 0x810;
static	volatile	unsigned	char	CAN_TXSTAT	@ 0x811;
static	volatile	unsigned	char	CAN_BUFSTAT	@ 0x812;
static	volatile	unsigned	char	CAN_ID0		@ 0x813;
static	volatile	unsigned	char	CAN_ID1		@ 0x814;
static	volatile	unsigned	char	CAN_ID2		@ 0x815;
static	volatile	unsigned	char	CAN_ID3		@ 0x816;
static	volatile	unsigned	long	CAN_ID		@ 0x813;
static	volatile	unsigned	char	CAN_DLC		@ 0x817;

	/* Bank 9 */
static	volatile	unsigned	char	CAN_DB0		@ 0x910;
static	volatile	unsigned	char	CAN_DB1		@ 0x911;
static	volatile	unsigned	char	CAN_DB2		@ 0x912;
static	volatile	unsigned	char	CAN_DB3		@ 0x913;
static	volatile	unsigned	char	CAN_DB4		@ 0x914;
static	volatile	unsigned	char	CAN_DB5		@ 0x915;
static	volatile	unsigned	char	CAN_DB6		@ 0x916;
static	volatile	unsigned	char	CAN_DB7		@ 0x917;
static	volatile	unsigned	long	CAN_DBH		@ 0x910;
static	volatile	unsigned	long	CAN_DBL		@ 0x914;

	/* Bank 15 */
static				unsigned	char	TSTMD1	@ 0xF14;
static				unsigned	char	TSTMD2	@ 0xF16;


/* /* ===================== STATUS ================================= */
/* ALUSTA bits */
static				bit		FS3	@ (unsigned)&ALUSTA*8+7;
static				bit		FS2 @ (unsigned)&ALUSTA*8+6;
static				bit		FS1 @ (unsigned)&ALUSTA*8+5;
static				bit		FS0 @ (unsigned)&ALUSTA*8+4;
static				bit		OV @ (unsigned)&ALUSTA*8+3;
static				bit		ZERO @ (unsigned)&ALUSTA*8+2;
static				bit		DC @ (unsigned)&ALUSTA*8+1;
static				bit		CARRY @ (unsigned)&ALUSTA*8+0;

/*	T0STA bits	*/
static				bit		INTEDG	@ (unsigned)&T0STA*8+7;
static				bit		T0SE	@ (unsigned)&T0STA*8+6;
static				bit		T0CS	@ (unsigned)&T0STA*8+5;
static				bit		PS3	@ (unsigned)&T0STA*8+4;
static				bit		PS2	@ (unsigned)&T0STA*8+3;
static				bit		PS1	@ (unsigned)&T0STA*8+2;
static				bit		PS0	@ (unsigned)&T0STA*8+1;

/*	CPUSTA bits	*/
static	volatile	bit		STKAV	@ (unsigned)&CPUSTA*8+5;
static	volatile	bit		GLINTD	@ (unsigned)&CPUSTA*8+4;
static	volatile	bit		TO	@ (unsigned)&CPUSTA*8+3;
static	volatile	bit		PD	@ (unsigned)&CPUSTA*8+2;
static	volatile	bit		POR	@ (unsigned)&CPUSTA*8+1;
static	volatile	bit		BOR	@ (unsigned)&CPUSTA*8+0;

/*	INTSTA bits	*/
static	volatile	bit		PEIF	@ (unsigned)&INTSTA*8+7;
static	volatile	bit		T0CKIF	@ (unsigned)&INTSTA*8+6;
static	volatile	bit		T0IF	@ (unsigned)&INTSTA*8+5;
static	volatile	bit		INTF	@ (unsigned)&INTSTA*8+4;
static				bit		PEIE	@ (unsigned)&INTSTA*8+3;
static				bit		T0CKIE	@ (unsigned)&INTSTA*8+2;
static				bit		T0IE	@ (unsigned)&INTSTA*8+1;
static				bit		INTE	@ (unsigned)&INTSTA*8+0;

/*	RCSTA1 bits	*/
static				bit		SPEN1	@ (unsigned)&RCSTA1*8+7;
static				bit		RX91	@ (unsigned)&RCSTA1*8+6;
static				bit		SREN1	@ (unsigned)&RCSTA1*8+5;
static				bit		CREN1	@ (unsigned)&RCSTA1*8+4;
static	volatile	bit		FERR1	@ (unsigned)&RCSTA1*8+2;
static	volatile	bit		OERR1	@ (unsigned)&RCSTA1*8+1;
static	volatile	bit		RX9D1	@ (unsigned)&RCSTA1*8+0;

/*	TXSTA1 bits	*/
static				bit		CSRC1	@ (unsigned)&TXSTA1*8+7;
static				bit		TX91	@ (unsigned)&TXSTA1*8+6;
static				bit		TXEN1	@ (unsigned)&TXSTA1*8+5;
static				bit		SYNC1	@ (unsigned)&TXSTA1*8+4;
static	volatile	bit		TRMT1	@ (unsigned)&TXSTA1*8+1;
static				bit		TX9D1	@ (unsigned)&TXSTA1*8+0;


/* ===================== PORT ================================= */
/* PORTA bits */
static	volatile	bit		RBPU	@ (unsigned)&PORTA*8+7;
static	volatile	bit		RA5	@ (unsigned)&PORTA*8+5;
static	volatile	bit		RA4 @ (unsigned)&PORTA*8+4;
static	volatile	bit		RA3 @ (unsigned)&PORTA*8+3;
static	volatile	bit		RA2 @ (unsigned)&PORTA*8+2;
static	volatile	bit		RA1 @ (unsigned)&PORTA*8+1;
static	volatile	bit		RA0 @ (unsigned)&PORTA*8+0;

/*	DDRA bits	*/
static				bit		DDRA7 @ (unsigned)&DDRA*8+7;
static				bit		DDRA6 @ (unsigned)&DDRA*8+6;
static				bit		DDRA5 @ (unsigned)&DDRA*8+5;
static				bit		DDRA4 @ (unsigned)&DDRA*8+4;
static				bit		DDRA3 @ (unsigned)&DDRA*8+3;
static				bit		DDRA2 @ (unsigned)&DDRA*8+2;
static				bit		DDRA1 @ (unsigned)&DDRA*8+1;
static				bit		DDRA0 @ (unsigned)&DDRA*8+0;


/* PORTC bits */
static	volatile	bit		RC7 @ (unsigned)&PORTC*8+7;
static	volatile	bit		RC6 @ (unsigned)&PORTC*8+6;
static	volatile	bit		RC5 @ (unsigned)&PORTC*8+5;
static	volatile	bit		RC4 @ (unsigned)&PORTC*8+4;
static	volatile	bit		RC3 @ (unsigned)&PORTC*8+3;
static	volatile	bit		RC2 @ (unsigned)&PORTC*8+2;
static	volatile	bit		RC1 @ (unsigned)&PORTC*8+1;
static	volatile	bit		RC0 @ (unsigned)&PORTC*8+0;

/*	DDRC bits	*/
static				bit		DDRC7 @ (unsigned)&DDRC*8+7;
static				bit		DDRC6 @ (unsigned)&DDRC*8+6;
static				bit		DDRC5 @ (unsigned)&DDRC*8+5;
static				bit		DDRC4 @ (unsigned)&DDRC*8+4;
static				bit		DDRC3 @ (unsigned)&DDRC*8+3;
static				bit		DDRC2 @ (unsigned)&DDRC*8+2;
static				bit		DDRC1 @ (unsigned)&DDRC*8+1;
static				bit		DDRC0 @ (unsigned)&DDRC*8+0;

/* PORTD bits */
static	volatile	bit		RD7 @ (unsigned)&PORTD*8+7;
static	volatile	bit		RD6 @ (unsigned)&PORTD*8+6;
static	volatile	bit		RD5 @ (unsigned)&PORTD*8+5;
static	volatile	bit		RD4 @ (unsigned)&PORTD*8+4;
static	volatile	bit		RD3 @ (unsigned)&PORTD*8+3;
static	volatile	bit		RD2 @ (unsigned)&PORTD*8+2;
static	volatile	bit		RD1 @ (unsigned)&PORTD*8+1;
static	volatile	bit		RD0 @ (unsigned)&PORTD*8+0;

/*	DDRD bits	*/
static				bit		DDRD7 @ (unsigned)&DDRD*8+7;
static				bit		DDRD6 @ (unsigned)&DDRD*8+6;
static				bit		DDRD5 @ (unsigned)&DDRD*8+5;
static				bit		DDRD4 @ (unsigned)&DDRD*8+4;
static				bit		DDRD3 @ (unsigned)&DDRD*8+3;
static				bit		DDRD2 @ (unsigned)&DDRD*8+2;
static				bit		DDRD1 @ (unsigned)&DDRD*8+1;
static				bit		DDRD0 @ (unsigned)&DDRD*8+0;

/* PORTE bits */
static	volatile	bit		RE3 @ (unsigned)&PORTE*8+3;
static	volatile	bit		RE2 @ (unsigned)&PORTE*8+2;
static	volatile	bit		RE1 @ (unsigned)&PORTE*8+1;
static	volatile	bit		RE0 @ (unsigned)&PORTE*8+0;

/*	DDRE bits	*/
static				bit		DDRE3 @ (unsigned)&DDRE*8+3;
static				bit		DDRE2 @ (unsigned)&DDRE*8+2;
static				bit		DDRE1 @ (unsigned)&DDRE*8+1;
static				bit		DDRE0 @ (unsigned)&DDRE*8+0;

/* ===================== INTERRUPT ================================= */
/*	PIR1 bits	*/
static	volatile	bit		RBIF	@ (unsigned)&PIR1*8+7;
static	volatile	bit		TMR3IF	@ (unsigned)&PIR1*8+6;
static	volatile	bit		TMR2IF	@ (unsigned)&PIR1*8+5;
static	volatile	bit		TMR1IF	@ (unsigned)&PIR1*8+4;
static	volatile	bit		CA2IF	@ (unsigned)&PIR1*8+3;
static	volatile	bit		CA1IF	@ (unsigned)&PIR1*8+2;
static	volatile	bit		TX1IF	@ (unsigned)&PIR1*8+1;
static	volatile	bit		RC1IF	@ (unsigned)&PIR1*8+0;

/*	PIE1 bits	*/
static				bit		RBIE	@ (unsigned)&PIE1*8+7;
static				bit		TMR3IE	@ (unsigned)&PIE1*8+6;
static				bit		TMR2IE	@ (unsigned)&PIE1*8+5;
static				bit		TMR1IE	@ (unsigned)&PIE1*8+4;
static				bit		CA2IE	@ (unsigned)&PIE1*8+3;
static				bit		CA1IE	@ (unsigned)&PIE1*8+2;
static				bit		TX1IE	@ (unsigned)&PIE1*8+1;
static				bit		RC1IE	@ (unsigned)&PIE1*8+0;

/*	PIR2 bits	*/
static	volatile	bit		SSPIF	@ (unsigned)&PIR2*8+7;
static	volatile	bit		BCLIF	@ (unsigned)&PIR2*8+6;
static	volatile	bit		ADIF	@ (unsigned)&PIR2*8+5;
static	volatile	bit		CA4IF	@ (unsigned)&PIR2*8+3;
static	volatile	bit		CA3IF	@ (unsigned)&PIR2*8+2;
static	volatile	bit		TX2IF	@ (unsigned)&PIR2*8+1;
static	volatile	bit		RC2IF	@ (unsigned)&PIR2*8+0;

/*	PIE2 bits	*/
static				bit		SSPIE	@ (unsigned)&PIE2*8+7;
static				bit		BCLIE	@ (unsigned)&PIE2*8+6;
static				bit		ADIE	@ (unsigned)&PIE2*8+5;
static				bit		CA4IE	@ (unsigned)&PIE2*8+3;
static				bit		CA3IE	@ (unsigned)&PIE2*8+2;
static				bit		TX2IE	@ (unsigned)&PIE2*8+1;
static				bit		RC2IE	@ (unsigned)&PIE2*8+0;

/* ===================== CONTROL ================================= */
/* PW1DCL bits */
static				bit		DC1PW1 @ (unsigned)&PW1DCL*8+7;
static				bit		DC0PW1 @ (unsigned)&PW1DCL*8+6;

/* PW2DCL bits */
static				bit		DC1PW2 @ (unsigned)&PW2DCL*8+7;
static				bit		DC0PW2 @ (unsigned)&PW2DCL*8+6;
static				bit		TM2PW2 @ (unsigned)&PW2DCL*8+5;
      			
/* PW1DCH bits */
static				bit		DC9PW1 @ (unsigned)&PW1DCH*8+7;
static				bit		DC8PW1 @ (unsigned)&PW1DCH*8+6;
static				bit		DC7PW1 @ (unsigned)&PW1DCH*8+5;
static				bit		DC6PW1 @ (unsigned)&PW1DCH*8+4;
static				bit		DC5PW1 @ (unsigned)&PW1DCH*8+3;
static				bit		DC4PW1 @ (unsigned)&PW1DCH*8+2;
static				bit		DC3PW1 @ (unsigned)&PW1DCH*8+1;
static				bit		DC2PW1 @ (unsigned)&PW1DCH*8+0;

/* PW2DCH bits */
static				bit		DC9PW2 @ (unsigned)&PW2DCH*8+7;
static				bit		DC8PW2 @ (unsigned)&PW2DCH*8+6;
static				bit		DC7PW2 @ (unsigned)&PW2DCH*8+5;
static				bit		DC6PW2 @ (unsigned)&PW2DCH*8+4;
static				bit		DC5PW2 @ (unsigned)&PW2DCH*8+3;
static				bit		DC4PW2 @ (unsigned)&PW2DCH*8+2;
static				bit		DC3PW2 @ (unsigned)&PW2DCH*8+1;
static				bit		DC2PW2 @ (unsigned)&PW2DCH*8+0;

/*	TCON1 bits	*/
static				bit		CA2ED1	@ (unsigned)&TCON1*8+7;
static				bit		CA2ED0	@ (unsigned)&TCON1*8+6;
static				bit		CA1ED1	@ (unsigned)&TCON1*8+5;
static				bit		CA1ED0	@ (unsigned)&TCON1*8+4;
static				bit		T16	@ (unsigned)&TCON1*8+3;
static				bit		TMR3CS	@ (unsigned)&TCON1*8+2;
static				bit		TMR2CS	@ (unsigned)&TCON1*8+1;
static				bit		TMR1CS	@ (unsigned)&TCON1*8+0;

/*	TCON2 bits	*/
static	volatile	bit		CA2OVF	@ (unsigned)&TCON2*8+7;
static	volatile	bit		CA1OVF	@ (unsigned)&TCON2*8+6;
static	volatile	bit		PWM2ON	@ (unsigned)&TCON2*8+5;
static	volatile	bit		PWM1ON	@ (unsigned)&TCON2*8+4;
static				bit		CA1	@ (unsigned)&TCON2*8+3;
static				bit		TMR3ON	@ (unsigned)&TCON2*8+2;
static				bit		TMR2ON	@ (unsigned)&TCON2*8+1;
static				bit		TMR1ON	@ (unsigned)&TCON2*8+0;

/*	ADCON0 bits	*/
static				bit		CHS3	@ (unsigned)&ADCON0*8+7;
static				bit		CHS2	@ (unsigned)&ADCON0*8+6;
static				bit		CHS1	@ (unsigned)&ADCON0*8+5;
static				bit		CHS0	@ (unsigned)&ADCON0*8+4;
static	volatile	bit		GO		@ (unsigned)&ADCON0*8+2;
static				bit		ADON	@ (unsigned)&ADCON0*8+0;

/*	ADCON1 bits	*/
static				bit		ADCS1	@ (unsigned)&ADCON1*8+7;
static				bit		ADCS0	@ (unsigned)&ADCON1*8+6;
static				bit		ADFM	@ (unsigned)&ADCON1*8+5;
static				bit		PCFG3	@ (unsigned)&ADCON1*8+3;
static				bit		PCFG2	@ (unsigned)&ADCON1*8+2;
static				bit		PCFG1	@ (unsigned)&ADCON1*8+1;
static				bit		PCFG0	@ (unsigned)&ADCON1*8+0;

/* ===================== LIN ===================================== */
static	volatile	bit		BRKCNT3	@ (unsigned)&LIN_CTRL*8+7;
static	volatile	bit		BRKCNT2	@ (unsigned)&LIN_CTRL*8+6;
static	volatile	bit		BRKCNT1	@ (unsigned)&LIN_CTRL*8+5;
static	volatile	bit		BRKCNT0	@ (unsigned)&LIN_CTRL*8+4;
static	volatile	bit		BRK		@ (unsigned)&LIN_CTRL*8+3;
static	volatile	bit		SYNCH	@ (unsigned)&LIN_CTRL*8+2;
static	volatile	bit		ERR		@ (unsigned)&LIN_CTRL*8+1;
static				bit		LINEN	@ (unsigned)&LIN_CTRL*8+0;

/* ===================== EEEPROM ================================= */
/*	EE_CON bits	*/
static	volatile	bit		TEST_p	@ (unsigned)&EE_CON*8+7;
static				bit		EE_TEST	@ (unsigned)&EE_CON*8+6;
static				bit		CP_TEST	@ (unsigned)&EE_CON*8+5;
static				bit		VEE2	@ (unsigned)&EE_CON*8+4;
static				bit		VEE1	@ (unsigned)&EE_CON*8+3;
static				bit		BRG2	@ (unsigned)&EE_CON*8+2;
static				bit		BRG1	@ (unsigned)&EE_CON*8+1;
static				bit		BRG0	@ (unsigned)&EE_CON*8+0;

/*	EE_MODE bits	*/
static				bit		EE_EN		@ (unsigned)&EE_MODE*8+7;
static				bit		IE_BUSY		@ (unsigned)&EE_MODE*8+5;
static	volatile	bit		EE_BUSY		@ (unsigned)&EE_CON*8+4;
static				bit		EE_MODE2	@ (unsigned)&EE_MODE*8+2;
static				bit		EE_MODERRE1	@ (unsigned)&EE_MODE*8+1;
static				bit		EE_MODE0	@ (unsigned)&EE_MODE*8+0;

/* ===================== CAN ===================================== */
/*	CAN_CTRL bits	*/
static	volatile	bit		ERR_State1	@ (unsigned)&CAN_CTRL*8+7;
static	volatile	bit		ERR_State0	@ (unsigned)&CAN_CTRL*8+6;
static	volatile	bit		OVL_SEND	@ (unsigned)&CAN_CTRL*8+5;
static				bit		ROP			@ (unsigned)&CAN_CTRL*8+3;
static				bit		SAP			@ (unsigned)&CAN_CTRL*8+4;
static				bit		STM			@ (unsigned)&CAN_CTRL*8+2;
static				bit		ROM			@ (unsigned)&CAN_CTRL*8+1;
static				bit		CAN_EN		@ (unsigned)&CAN_CTRL*8+0;

/*	CAN_STAT bits	*/
static	volatile	bit		RX_CNT8		@ (unsigned)&CAN_STAT*8+7;
static	volatile	bit		TX_CNT8		@ (unsigned)&CAN_STAT*8+6;
static	volatile	bit		RX_BUSY		@ (unsigned)&CAN_STAT*8+5;
static	volatile	bit		TX_BUSY		@ (unsigned)&CAN_STAT*8+4;
static	volatile	bit		STUFF_ERR	@ (unsigned)&CAN_STAT*8+3;
static	volatile	bit		FRAME_ERR	@ (unsigned)&CAN_STAT*8+2;
static	volatile	bit		CRC_ERR		@ (unsigned)&CAN_STAT*8+1;
static	volatile	bit		RX_BIT_ERR	@ (unsigned)&CAN_STAT*8+0;

/*	CAN_BRG1 bits	*/
static				bit		SJW1	@ (unsigned)&CAN_BRG1*8+7;
static				bit		SJW0	@ (unsigned)&CAN_BRG1*8+6;
static				bit		BRP5	@ (unsigned)&CAN_BRG1*8+5;
static				bit		BRP4	@ (unsigned)&CAN_BRG1*8+4;
static				bit		BRP3	@ (unsigned)&CAN_BRG1*8+3;
static				bit		BRP2	@ (unsigned)&CAN_BRG1*8+2;
static				bit		BRP1	@ (unsigned)&CAN_BRG1*8+1;
static				bit		BRP0	@ (unsigned)&CAN_BRG1*8+0;

/*	CAN_BRG2 bits	*/
static				bit		SAM			@ (unsigned)&CAN_BRG2*8+6;
static				bit		SEG1_PH2	@ (unsigned)&CAN_BRG2*8+5;
static				bit		SEG1_PH1	@ (unsigned)&CAN_BRG2*8+4;
static				bit		SEG1_PH0	@ (unsigned)&CAN_BRG2*8+3;
static				bit		PR_SEG2		@ (unsigned)&CAN_BRG2*8+2;
static				bit		PR_SEG1		@ (unsigned)&CAN_BRG2*8+1;
static				bit		PR_SEG0		@ (unsigned)&CAN_BRG2*8+0;

/*	CAN_BRG3 bits	*/
static				bit		SEG2_PH2	@ (unsigned)&CAN_BRG3*8+2;
static				bit		SEG2_PH1	@ (unsigned)&CAN_BRG3*8+1;
static				bit		SEG2_PH0	@ (unsigned)&CAN_BRG3*8+0;

/*	CAN_BSR bits	*/
static				bit		MSL		@ (unsigned)&CAN_BSR*8+4;
static				bit		BSR2	@ (unsigned)&CAN_BSR*8+2;
static				bit		BSR1	@ (unsigned)&CAN_BSR*8+1;
static				bit		BSR0	@ (unsigned)&CAN_BSR*8+0;

/*	CAN_RXSTAT bits	*/
static	volatile	bit		RX_FULL			@ (unsigned)&CAN_RXSTAT*8+7;
static	volatile	bit		BIT_ERR			@ (unsigned)&CAN_RXSTAT*8+6;
static	volatile	bit		RX_RTR			@ (unsigned)&CAN_RXSTAT*8+5;
static	volatile	bit		OF				@ (unsigned)&CAN_RXSTAT*8+4;
static				bit		OF_EN			@ (unsigned)&CAN_RXSTAT*8+3;
static				bit		MASK_ACT_ID2	@ (unsigned)&CAN_RXSTAT*8+2;
static				bit		MASK_ACT_ID1	@ (unsigned)&CAN_RXSTAT*8+1;
static				bit		MASK_ACT_ID0	@ (unsigned)&CAN_RXSTAT*8+0;

/*	CAN_TXSTAT bits	*/
static	volatile	bit		TX_BIF	@ (unsigned)&CAN_TXSTAT*8+7;
static	volatile	bit		TX_ARBT	@ (unsigned)&CAN_TXSTAT*8+6;
static	volatile	bit		TX_LARB	@ (unsigned)&CAN_TXSTAT*8+5;
static	volatile	bit		TX_ERR	@ (unsigned)&CAN_TXSTAT*8+4;
static	volatile	bit		TX_REQ	@ (unsigned)&CAN_TXSTAT*8+3;
static				bit		RTR_EN	@ (unsigned)&CAN_TXSTAT*8+2;
static				bit		PRIOR1	@ (unsigned)&CAN_TXSTAT*8+1;
static				bit		PRIOR0	@ (unsigned)&CAN_TXSTAT*8+0;

/*	CAN_BUFSTAT bits	*/
static				bit		RX_IE		@ (unsigned)&CAN_BUFSTAT*8+7;
static				bit		TX_IE		@ (unsigned)&CAN_BUFSTAT*8+6;
static				bit		ERR_IE		@ (unsigned)&CAN_BUFSTAT*8+5;
static				bit		RX_TX_MODE	@ (unsigned)&CAN_BUFSTAT*8+1;
static				bit		BUF_EN		@ (unsigned)&CAN_BUFSTAT*8+0;

/*	CAN_DLC bits	*/
static	volatile	bit		RTR_RX	@ (unsigned)&CAN_DLC*8+6;
static	volatile	bit		R1		@ (unsigned)&CAN_DLC*8+5;
static	volatile	bit		R0		@ (unsigned)&CAN_DLC*8+4;
static	volatile	bit		DLC3	@ (unsigned)&CAN_DLC*8+3;
static	volatile	bit		DLC2	@ (unsigned)&CAN_DLC*8+2;
static	volatile	bit		DLC1	@ (unsigned)&CAN_DLC*8+1;
static	volatile	bit		DLC0	@ (unsigned)&CAN_DLC*8+0;


/* =============================================================== */
#if	0
/*	TSTMD1 bits	*/
static				bit		FPMM2	@ (unsigned)&TSTMD1*8+7;
static				bit		BODEN1	@ (unsigned)&TSTMD1*8+6;
static				bit		ADTST	@ (unsigned)&TSTMD1*8+0;

/*	TSTMD2 bits	*/
static				bit		TSTMUX	@ (unsigned)&TSTMD2*8+7;
static				bit		FPMM1	@ (unsigned)&TSTMD2*8+6;
static				bit		GLWP	@ (unsigned)&TSTMD2*8+5;
static				bit		FPMM0	@ (unsigned)&TSTMD2*8+4;
static				bit		NWDT1	@ (unsigned)&TSTMD2*8+3;
static				bit		NWDT0	@ (unsigned)&TSTMD2*8+2;
static				bit		SOSC1	@ (unsigned)&TSTMD2*8+1;
static				bit		SOSC0	@ (unsigned)&TSTMD2*8+0;
#endif

#define CONFIG_ADDR	0xFE00
/*osc configurations*/
#define EC		0xFFFF	// external clock
#define XT		0xFFFE	// crystal/resonator
#define RC		0xFFFD	// external resistor/capacitor
#define LF		0xFFFC	// low frequency

/*watchdog timer postscaler*/
#define WDTPS1		0xFFFF	// postscaler = 1
#define WDTPS256	0xFFFB	// postscaler = 256
#define WDTPS64		0xFFF7	// postscaler = 64
#define WDTDIS		0xFFF3	// watchdog timer is disabled

/*brown out reset*/
#define BOREN		0xFFFF	// enable brown out reset
#define BORDIS		0xBFFF	// disable brown out reset

/* PM2, PM1, PM0 Processor mode select */
#define PROTECT		0xBFAF			/* code protected microcontroller mode */
#define MICROPROCESSOR	0xFFFF			/* microprocessor mode */
#define MICROCONTROLLER	0xFFEF			/* microcontroller mode */
#define EXT_MICROCTRL	0xFFBF			/* extended microcontroller mode */

