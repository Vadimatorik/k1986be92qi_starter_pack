
#ifndef __CONFIG_C
#define __CONFIG_C

#include "opora.h"
#include "config.h"

//--- Clock configuration ---
void ClkConfig()
{
	uint32_t temp;
	RST_CLK->PER_CLOCK |= (1 << 27);				//BKP Clock enable
	temp = BKP->REG_0E;
	temp &= 0xFFFFFFC0;
	BKP->REG_0E = temp | (7 << 3) | 7;				// SelectRI = 0x7, LOW = 0x7; (for core frequency more then 80 MHz);

#ifdef REVISION_2

#ifdef HSE2_OSCILLATOR
	RST_CLK->HS_CONTROL=0x00000005;					//HSE - On, Oscillator mode; HSE2 - On, Oscillator mode
#else
	RST_CLK->HS_CONTROL=0x0000000D;					//HSE - On, Oscillator mode; HSE2 - On, Generator mode
#endif	//HSE2_OSCILLATOR

	while((RST_CLK->CLOCK_STATUS&0x0C)!=0x0C);		//Wait until HSE and HSE2 not ready
	RST_CLK->CPU_CLOCK=0x00000002;					//CPU_C1 = HSE = 8 MHz

	RST_CLK->PLL_CONTROL=(11<<8)|(1<<2);			//PLL CPU On, PLL_MULL = 11;
	while((RST_CLK->CLOCK_STATUS&0x02)!=0x02);		//wait until PLL CPU not ready
	RST_CLK->PER_CLOCK|=0x08;						//EEPROM_CTRL Clock enable
	EEPROM->CMD=3<<3;								//Delay = 3	 
	RST_CLK->PER_CLOCK&=(~0x08);					//EEPROM_CTRL Clock disable
		 
	RST_CLK->CPU_CLOCK|=0x00000106;					//CPU Clock = 12*8 MHz = 96 MHz
	RST_CLK->ETH_CLOCK=(3<<28)|(1<<27)|(1<<24);		//PHY_CLK_SEL = HSE2, ETH_CLK_EN=1, PHY_CLK_EN=1
#else
	RST_CLK->HS_CONTROL=0x00000003;					//HSE - On; Gen mode On
	while((RST_CLK->CLOCK_STATUS&0x04)!=0x04);		//Wait until HSE not ready
	RST_CLK->CPU_CLOCK=0x00000003;					//HSE/2 = 12.5 MHz

	RST_CLK->PLL_CONTROL=(7<<8)|(1<<2);				//PLL CPU On;
	while((RST_CLK->CLOCK_STATUS&0x02)!=0x02);		//wait until PLL CPU not ready
	RST_CLK->PER_CLOCK|=0x08;						//EEPROM_CTRL Clock enable
	EEPROM->CMD=4<<3;								//Delay = 4	 
	RST_CLK->PER_CLOCK&=(~0x08);					//EEPROM_CTRL Clock disable
		 
	RST_CLK->CPU_CLOCK|=0x00000107;					//CPU Clock = 8*12.5MHz = 100 MHz
	RST_CLK->ETH_CLOCK=(1<<24)|(1<<28)|(1<<27);		//PHY_CLK_SEL = HSE, ETH_CLK_EN=1, PHY_CLK_EN=1, ETH_CLK = 25MHz
#endif	//REVISION_2
	
	RST_CLK->PER_CLOCK|=(1<<24)|(1<<22)|(1<<23);	//Enable clock for PORTD, PORTC and PORTB
}

//--- Ports configuration ---
void PortConfig()
{
	//PORTC_7 - FXEN, PORTC_8 - FTX
	PORTC->FUNC=0x003C000;
	PORTC->ANALOG=0x0180;
	PORTC->PWR=0x003C000;

	//PORTD_11 - FRX, PORTD_15 - FSD
	PORTD->FUNC = 0xC0C00000;
	PORTD->ANALOG=0xFFFF;
	PORTD->RXTX=0;
	PORTD->OE|=0x7780;
	PORTD->PWR|=0xFFFFC000;

	PORTB->FUNC = 0x00;
	PORTB->ANALOG=0x3<<14;
	PORTB->RXTX=0;
	PORTB->OE|=0x3<<14;
	PORTB->PWR|=0xF<<28;
}

#endif	//__CONFIG_C
