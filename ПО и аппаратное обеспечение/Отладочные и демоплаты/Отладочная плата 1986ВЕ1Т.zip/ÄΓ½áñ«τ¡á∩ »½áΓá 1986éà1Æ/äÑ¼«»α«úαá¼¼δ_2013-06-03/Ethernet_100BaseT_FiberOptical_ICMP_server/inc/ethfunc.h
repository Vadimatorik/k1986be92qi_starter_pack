
#ifndef __ETHFUNC_H
#define __ETHFUNC_H

#include "config.h"

void	SetPHYReg(unsigned char,unsigned char,unsigned short);
unsigned short	GetPHYReg(unsigned char,unsigned char);
void	PHYInit(unsigned char);
void EthernetConfig(void);
void MACReset(void);
void ClearMemory(void);
int	SendPacket(void* buffer, int size);
uint32_t ReadPacket(_Rec_Frame*);
int	SendPacket(void*, int);

#endif	//__ETHFUNC_H

