
#ifndef __CONFIG_H
#define __CONFIG_H

void ClkConfig(void);
void PortConfig(void);
void SysTickInit(void);
void DACInit(void);

#endif	//__CONFIG_H

