
#ifndef __CONFIG_C
#define __CONFIG_C

#include "opora.h"

//--- Clock configuration ---
void ClkConfig()
{
	RST_CLK->HS_CONTROL=0x00000001;					//HSE - On, Oscillator mode
	while((RST_CLK->CLOCK_STATUS&0x04)!=0x04);		//Wait until HSE not ready
	RST_CLK->PER_CLOCK|=0x08;						//EEPROM Clock enable
	EEPROM->CMD=0;									//EEPROM Delay=0	 
	RST_CLK->PER_CLOCK&=(~0x08);					//EEPROM Clock disable

	RST_CLK->CPU_CLOCK=0x00000102;					//CPU_C3 clock = 8MHz
	RST_CLK->PER_CLOCK|=(0x3<<24)|(1<<18);			//Enable clock for DAC, PORTD, PORTE
}

//--- Ports configuration ---
void PortConfig()
{
	//*** for LED ***
	PORTD->FUNC=0;
	PORTD->ANALOG=0xFFFF;
	PORTD->RXTX=0;
	PORTD->OE|=0x7F80;
	PORTD->PWR|=0x3FFFC000;

	//*** for DAC ***
	PORTE->ANALOG=0xFFFD;	//PORTE_1 - analog (DAC 0)
}

//--- System Timer configuration ---
void SysTickInit()
{
	SysTick->LOAD=0x00009C3F;	//Pause 5 ms (HCLK=8MHz)
	SysTick->CTRL=0x00000003;	//Enabel SysTick, Enable Interrupt
}

//--- DAC configuration ---
void DACInit(void)
{
	DAC->DAC1_DATA=0x0000;
	DAC->CFG=0x0004;
}

#endif	//__CONFIG_C

