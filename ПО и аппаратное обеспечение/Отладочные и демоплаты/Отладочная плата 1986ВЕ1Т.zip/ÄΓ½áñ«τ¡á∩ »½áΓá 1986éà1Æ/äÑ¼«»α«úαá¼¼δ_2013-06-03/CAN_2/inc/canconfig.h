
#ifndef __CANCONFIG_H
#define __CANCONFIG_H

void CANConfig(void);

#endif	//__CANCONFIG_H

