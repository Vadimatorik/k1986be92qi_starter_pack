
#ifndef __CONFIG_H
#define __CONFIG_H


#define	TIMEOUT 3	//Send CAN frame every TIMEOUT seconds

#define CAN_1	1	//Select CAN1 (if CAN_1 == 1) or CAN2 (if CAN_1 != 1)

#define REVISION_2

//#define SPEED_1000K
#define SPEED_500K
//#define SPEED_250K

void ClkConfig(void);
void PortConfig(void);
void SysTickInit(void);

#endif	//__CONFIG_H

