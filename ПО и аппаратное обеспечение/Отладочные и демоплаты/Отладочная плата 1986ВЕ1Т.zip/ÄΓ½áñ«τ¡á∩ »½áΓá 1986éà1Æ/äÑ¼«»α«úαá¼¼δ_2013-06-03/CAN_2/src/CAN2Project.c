
#include "opora.h"
#include "config.h"
#include "canconfig.h"

uint32_t Sec=0, Time10=0, NextTransmit=0;

int main()
{
	ClkConfig();
	PortConfig();
	CANConfig();

#if CAN_1 == 1
	NVIC_EnableIRQ(CAN1_IRQn);
#else
	NVIC_EnableIRQ(CAN2_IRQn);
#endif	//CAN_1 == 1

	SysTickInit();
	NextTransmit=TIMEOUT;
	while(1);
}

void SysTick_Handler(void)
{
	if(Time10++ ==9)
	{
		Sec++;
		Time10=0;
	}
	if(Sec==NextTransmit)
	{

#if CAN_1 == 1		
		if((CAN1->BUF_02_CON&(1<<5))!=(1<<5))
		{		
			CAN1->BUF_02_DATAL=Sec;
			CAN1->BUF_02_DATAH=Sec;

			CAN1->BUF_02_CON|=1<<5;					//Transmit frame
		}
#else
		if((CAN2->BUF_02_CON&(1<<5))!=(1<<5))
		{
			CAN2->BUF_02_DATAL=Sec;
			CAN2->BUF_02_DATAH=Sec;

			CAN2->BUF_02_CON|=1<<5;					//Transmit frame
		}
#endif	//CAN_1 == 1

		NextTransmit=Sec+TIMEOUT;
	}
}

#if CAN_1 == 1
void CAN1_Handler()
{
	if((CAN1->STATUS&0x01)==0x01)
	{
		PORTD->RXTX=((CAN1->BUF_01_DLC&0x0F)<<7);
		CAN1->BUF_01_CON&=0xBF;	//clear RX_FULL flag
	}
}
#else
void CAN2_Handler()
{
	if((CAN2->STATUS&0x01)==0x01)
	{
		PORTD->RXTX=((CAN2->BUF_01_DLC&0x0F)<<7);
		CAN2->BUF_01_CON&=0xBF;	//clear RX_FULL flag
	}
}
#endif	//CAN_1 == 1



