
#include "opora.h"
#include "Config.h"
#include "CANConfig.h"

uint32_t Sec=0, Time10=0, LastTransmit=0;

int main()
{
	ClkConfig();
	PortConfig();
	CANConfig();
	SysTickInit();	
	while(1)
	{
#if CAN_1 == 1
		if((CAN1->BUF_01_CON&0x40)==0x40)
		{
			PORTD->RXTX = (CAN1->BUF_01_DLC&0x0F)<<7;
			CAN1->BUF_01_CON &= 0xBF;	//clear RX_READY flag
		}
#else	//CAN_1 == 1
		if((CAN2->BUF_01_CON&0x40)==0x40)
		{
			PORTD->RXTX = (CAN2->BUF_01_DLC&0x0F)<<7;
			CAN2->BUF_01_CON &= 0xBF;	//clear RX_READY flag
		}
#endif	//CAN_1 == 1
	}

}

void SysTick_Handler(void)
{
	if(Time10++ ==9)
	{
		Sec++;
		Time10=0;
	}
	if(Sec == (LastTransmit+TIMEOUT))
	{
#if CAN_1 == 1
		if((CAN1->BUF_02_CON&(1<<5)) != (1<<5))
		{		
			CAN1->BUF_02_DATAL = Sec;
			CAN1->BUF_02_DATAH = Sec;

			CAN1->BUF_02_CON |= 1<<5;					//Transmit frame
			LastTransmit = Sec;
		}
#else
		if((CAN2->BUF_02_CON&(1<<5)) != (1<<5))
		{		
			CAN2->BUF_02_DATAL = Sec;
			CAN2->BUF_02_DATAH = Sec;

			CAN2->BUF_02_CON |= 1<<5;					//Transmit frame
			LastTransmit = Sec;
		}
#endif	//CAN_1 == 1
	}
}

