
#include "opora.h"
#include "config.h"

//--- CAN1 Config ---
void CANConfig()
{
#if CAN_1 == 1

#ifdef REVISION_2

	#ifdef SPEED_1000K
		CAN1->BITTMNG = 0x08900002;			//CAN1 speed 1 Mbit/s	
	#endif	//SPEED_1000K
		
	#ifdef SPEED_500K
		CAN1->BITTMNG =	0x08900005;			//CAN1 speed 500 kbit/s
	#endif	//SPEED_500K

	#ifdef SPEED_250K
		CAN1->BITTMNG =	0x0890000B;			//CAN1 speed 250 kbit/s
	#endif	//SPEED_250K

#else

	#ifdef SPEED_1000K
		CAN1->BITTMNG = 0x01FF0000;			//CAN1 speed 1 Mbit/s
	#endif	//SPEED_1000K

	#ifdef SPEED_500K
		CAN1->BITTMNG =	0x01FF0001;			//CAN1 speed 500 kbit/s
	#endif	//SPEED_500K

	#ifdef SPEED_250K
		CAN1->BITTMNG =	0x01FF0003;			//CAN1 speed 250 kbit/s
	#endif	//SPEED_250K

#endif	//REVISION_2

	CAN1->BUF_01_CON = 0x00000003;		//Buffer 1 - Rx and enable
	CAN1->BUF_02_CON = 0x00000001;		//Buffer 2 - Tx and enable
	CAN1->INT_EN = 0;					//all interrupts disable

	CAN1->INT_RX = 0;					//Rx interrupts disable
	CAN1->INT_TX = 0;					//Tx interrupts disable
	
	CAN1->BUF_02_ID = 0x555<<18;		// 10101010101 - SID; 0 - EID
	CAN1->BUF_02_DLC = 0x00000A08;		// IDE = 0; SSR = 1; R0 = 0; R1 = 1; RTR = 0; DLC = 8 bytes

	CAN1->BUF_02_DATAL = 0x00000000;
	CAN1->BUF_02_DATAH = 0x00000000;

	CAN1->BUF_01_MASK = 0x7F8<<18;
	CAN1->BUF_01_FILTER = 0x550<<18;

	CAN1->CONTROL = 0x00000009;				//CAN1 enable

#else
	
#ifdef REVISION_2

	#ifdef SPEED_1000K
		CAN2->BITTMNG = 0x08900002;			//CAN2 speed 1 Mbit/s	
	#endif	//SPEED_1000K
		
	#ifdef SPEED_500K
		CAN2->BITTMNG =	0x08900005;			//CAN2 speed 500 kbit/s
	#endif	//SPEED_500K

	#ifdef SPEED_250K
		CAN2->BITTMNG =	0x0890000B;			//CAN2 speed 250 kbit/s
	#endif	//SPEED_250K

#else

	#ifdef SPEED_1000K
		CAN2->BITTMNG = 0x01FF0000;			//CAN2 speed 1 Mbit/s
	#endif	//SPEED_1000K

	#ifdef SPEED_500K
		CAN2->BITTMNG =	0x01FF0001;			//CAN2 speed 500 kbit/s
	#endif	//SPEED_500K

	#ifdef SPEED_250K
		CAN2->BITTMNG =	0x01FF0003;			//CAN2 speed 250 kbit/s
	#endif	//SPEED_250K
#endif	//REVISION_2

	CAN2->BUF_01_CON = 0x00000003;		//Buffer 1 - Rx and enable
	CAN2->BUF_02_CON = 0x00000001;		//Buffer 2 - Tx and enable
	CAN2->INT_EN = 0;					//all interrupts disable

	CAN2->INT_RX = 0;					//Rx interrupts disable
	CAN2->INT_TX = 0;					//Tx interrupts disable
	
	CAN2->BUF_02_ID = 0x555<<18;		// 10101010101 - SID; 0 - EID
	CAN2->BUF_02_DLC = 0x00000A08;		// IDE = 0; SSR = 1; R0 = 0; R1 = 1; RTR = 0; DLC = 8 bytes

	CAN2->BUF_02_DATAL = 0x00000000;
	CAN2->BUF_02_DATAH = 0x00000000;

	CAN2->BUF_01_MASK = 0x7F8<<18;
	CAN2->BUF_01_FILTER = 0x550<<18;

	CAN2->CONTROL = 0x00000009;				//CAN2 enable
#endif	//CAN_1 == 1
}







