
#include "opora.h"
#include "config.h"
//--- Clock configuration ---
void ClkConfig()
{
	uint32_t temp;

	RST_CLK->PER_CLOCK |= (1 << 27);				//BKP Clock enable
	temp = BKP->REG_0E;
	temp &= 0xFFFFFFC0;
	BKP->REG_0E = temp | (5 << 3) | 5;				// SelectRI = 0x5, LOW = 0x5; (for frequency below 40 MHz);

#ifdef	REVISION_2
	RST_CLK->HS_CONTROL = 0x00000001;			//HSE - On; Oscillator mode
	while(RST_CLK->CLOCK_STATUS!=0x04);			//Wait until HSE not ready
	RST_CLK->CPU_CLOCK = 0x00000002;			//CPU_C1=HSE
	RST_CLK->PLL_CONTROL=(1<<2)|(2<<8);			//PLL On, PLL_Mull=2
	while(RST_CLK->CLOCK_STATUS!=6);			//Wait until PLL not ready
	RST_CLK->PER_CLOCK|=0x08;					//Enable clock for EEPROM_CNTRL
	EEPROM->CMD=0;								//EEPROM delay = 0
	RST_CLK->PER_CLOCK&=(~0x08);				//Disable clock for EEPROM_CNTRL
	RST_CLK->CPU_CLOCK=0x00000106;				//CPU Clock = 24 MHz
#else
	RST_CLK->HS_CONTROL = 0x00000003;			//HSE - On; Generator mode On
	while((RST_CLK->CLOCK_STATUS&0x04)!=0x04);	//Wait until HSE not ready
	RST_CLK->PER_CLOCK|=0x08;					//Enable clock for EEPROM module
	EEPROM->CMD=0;								//EEPROM delay = 0
	RST_CLK->PER_CLOCK&=(~0x08);				//Disable clock for EEPROM module
	RST_CLK->CPU_CLOCK = 0x00000102;			//CPU Clock = HSE (25MHz)
#endif	//REVISION_2

	RST_CLK->PER_CLOCK |= 0x03<<23;				//clock of PORTD, PORTC On

#if CAN_1 == 1
	RST_CLK->PER_CLOCK |= 1;					//enable CLK of CAN1
	RST_CLK->CAN_CLOCK |= 1<<24;				//CAN1 clock enable
#else //CAN_1 == 1
	RST_CLK->PER_CLOCK |= 2;					//enable CLK of CAN2
	RST_CLK->CAN_CLOCK |= 1<<25;				//CAN2 clock enable
#endif	//CAN_1 == 1
}

//--- Ports configuration ---
void PortConfig()
{
	//*** Config PortD for Leds ***
	PORTD->FUNC = 0x00000000;
	PORTD->RXTX = 0x0000;
	PORTD->OE = 0x7F80;
	PORTD->ANALOG = 0x7F80;
	PORTD->PWR = 0x3FFFC000;
	//*** Config PortC for CAN1 ***
#if CAN_1 == 1
	PORTC->FUNC = 0x003C0000;
	PORTC->RXTX = 0x0000;
	PORTC->ANALOG = 0x0600;
	PORTC->PWR = 0x003C0000;
#else	//CAN_1 == 1
	PORTC->FUNC = 0x03C00000;
	PORTC->RXTX = 0x0000;
	PORTC->ANALOG = 0x1800;
	PORTC->PWR = 0x03C00000;
#endif	//CAN_1 == 1
}

//--- System Timer initialization ---
void SysTickInit()
{
#ifdef	REVISION_2
	SysTick->LOAD = 0x00249EFF;	//Pause 100 ms (HCLK = 24MHz)	
#else
	SysTick->LOAD = 0x0026259F;	//Pause 100 ms (HCLK = 25MHz)
#endif	//REVISION_2
	SysTick->CTRL = 0x00000003;	//Enabel SysTick, Enable Interrupt
}





