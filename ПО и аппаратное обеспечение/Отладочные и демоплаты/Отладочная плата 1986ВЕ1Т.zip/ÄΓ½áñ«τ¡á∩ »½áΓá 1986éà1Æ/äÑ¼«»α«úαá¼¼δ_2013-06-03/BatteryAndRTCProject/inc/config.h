
#ifndef __CONFIG_H
#define __CONFIG_H

#define REVISION_2

#define TIMEOUT	5	//the controller will wake-up through TIMEOUT seconds

void ClkConfig(void);
void PortConfig(void);
void UARTConfig(void);
void BkpInit(void);

#endif	//__CONFIG_H
