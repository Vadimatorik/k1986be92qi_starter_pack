
#include "opora.h"
#include "config.h"

void ClkConfig(void);
void PortConfig(void);
void UARTConfig(void);

uint32_t Temp, CurrentLed = 0;

int main()
{
	ClkConfig();
	PortConfig();
	UARTConfig();
	BkpInit();

	while((BKP->RTC_CS&(1<<6)) != 0);		//wait until write data in RTC
	Temp = BKP->RTC_CNT;
	while((UART1->FR&(1<<5)) == (1<<5));	//wait until FIFO Tx full
	PORTD->SETTX = 0x4000;
	UART1->DR = (unsigned char)(Temp>>24);
	UART1->DR =	(unsigned char)(Temp>>16);
	UART1->DR =	(unsigned char)(Temp>>8);
	UART1->DR =	(unsigned char)Temp;
	while((UART1->FR&(1<<3)) == (1<<3));	//wait until Tx transmit data
	BKP->REG_0F |= 0x40000000;				//STANBY mode
}



