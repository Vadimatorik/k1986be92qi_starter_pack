
#ifndef __CONFIG_H
#define __CONFIG_H

void ClkConfig(void);
void PortConfig(void);

#endif	//__CONFIG_H
