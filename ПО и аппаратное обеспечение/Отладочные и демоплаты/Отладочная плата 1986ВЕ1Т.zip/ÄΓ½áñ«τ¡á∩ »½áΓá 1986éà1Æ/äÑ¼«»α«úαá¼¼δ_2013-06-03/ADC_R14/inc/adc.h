
#ifndef __ADC_H
#define __ADC_H

void ADCInit(void);

#endif	//__ADC_H
