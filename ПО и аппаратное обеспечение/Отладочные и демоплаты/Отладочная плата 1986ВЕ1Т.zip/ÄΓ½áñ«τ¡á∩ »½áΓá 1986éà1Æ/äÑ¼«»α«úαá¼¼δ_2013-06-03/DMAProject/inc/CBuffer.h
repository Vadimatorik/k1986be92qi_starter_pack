
#ifndef	__CBUFFER_H
#define __CBUFFER_H

#include <stdint.h>

#define	LENGTH		128

typedef struct
{
	uint8_t		Data[LENGTH];
	uint32_t	IndexRx;
	uint32_t	IndexTx;
	uint32_t	Length;
	uint32_t	Overflow;
	uint32_t	Refresh;
}	CBufferTypeDef;

void CBufferInit(CBufferTypeDef*);	//function for initialization CBufferTypeDef structure


#endif	//__CBUFFER_H

