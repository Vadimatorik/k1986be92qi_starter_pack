
#ifndef __UART_H
#define __UART_H

void UARTInit(void);	//function for configuration UART1
//void SendByte(UART_TypeDef*, uint8_t);	//function for send one byte through UART
void UART1_Handler(void);	//interrupt service routine of UART1

#endif	//__UART_H

