
#ifndef __LCDB_H
#define __LCDB_H

#include "LCD.h"
#include <stdint.h>

typedef enum _notation_ {hex,dec,oct,bin} notation;

void ClearPage(uint8_t, _crystal);
void PrintSymbol(uint8_t, uint8_t, uint8_t);
void PrintConstText(uint8_t*, uint8_t, uint8_t, uint8_t);
void PrintText(uint8_t*, uint32_t,uint8_t, uint8_t, uint8_t, notation);
void DigitalToChar(uint8_t*, uint32_t, uint32_t*, notation);
uint32_t StrLen(uint8_t*);

#endif	//__LCDB_H
