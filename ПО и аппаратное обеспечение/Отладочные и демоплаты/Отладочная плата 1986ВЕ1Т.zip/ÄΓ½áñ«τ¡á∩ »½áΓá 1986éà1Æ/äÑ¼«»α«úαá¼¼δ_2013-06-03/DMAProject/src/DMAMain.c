

#include "opora.h"
#include "config.h"
#include "LCD.h"
#include "LCD_b.h"
#include "DMA.h"
#include "UART.h"
#include "CBuffer.h"

DMAManagementStructureTypeDef	ManagementStructure[2]	__attribute__((at(BASE_PTR)));	
CBufferTypeDef	Buffer									__attribute__((at(0x20100600)));
uint32_t temp,page,cnt;

int main()
{
	ClockCfg();	//Configuration of system clock signals
	PortCfg();	
	LCDInit();
	CBufferInit(&Buffer);
	UARTInit();
	DMAInit();
	NVIC_EnableIRQ(UART1_IRQn);
	
	PrintConstText("��������� �����,",0,0,0);
	PrintConstText("���������� �� UART1:",1,0,0);
	temp=0;
	page=2;
	while(1)
	{
		if(Buffer.Length>0)
		{
			for(;(Buffer.Length>0)&&(temp<4);temp++)
			{
				PrintText("% ",Buffer.Data[Buffer.IndexTx++],page,temp*30,0,hex);
				Buffer.Length--;
				if(Buffer.IndexTx==LENGTH)	Buffer.IndexTx=0;
			}
			if(temp==4)
			{
				temp=0;
				if(++page==8)	page=2;
			}
			PORTD->RXTX=cnt<<7;
		}
	}
}

