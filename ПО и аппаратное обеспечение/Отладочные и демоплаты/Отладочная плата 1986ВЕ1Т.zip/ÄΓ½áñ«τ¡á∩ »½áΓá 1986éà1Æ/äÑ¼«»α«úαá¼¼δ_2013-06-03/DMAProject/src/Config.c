
#ifndef __CONFIG_C
#define __CONFIG_C

#include "opora.h"

void ClockCfg()
{
	uint32_t temp;

	RST_CLK->HS_CONTROL=1;					//oscillator mode
	while((RST_CLK->CLOCK_STATUS&0x04)==0);	//wait, until frequency unstable
	RST_CLK->PER_CLOCK|=0x08;				//EEPROM_CNTRL Clock enable
	EEPROM->CMD=0;							//Delay = 0
	RST_CLK->PER_CLOCK&=(~0x08);			//EEPROM_CNTRL Clock disable
	RST_CLK->PER_CLOCK |= (1 << 27);		//BKP Clock enable
	temp = BKP->REG_0E;
	temp &= 0xFFFFFFC0;
	BKP->REG_0E = temp | (5 << 3) | 5;		// SelectRI = 0x5, LOW = 0x5; (for frequency below 40 MHz);

	RST_CLK->CPU_CLOCK=0x00000002;			//CPU_C1 frequency 8MHz
	
	RST_CLK->PLL_CONTROL=0x0104;			//CPU_PLL On, USB_MUL_MULL=1
	while((RST_CLK->CLOCK_STATUS&0x02)==0);	//wait, until PLL frequency unstable

	
	RST_CLK->CPU_CLOCK=0x00000106;			//CPU frequency 16MHz
}

void PortCfg()
{
	RST_CLK->PER_CLOCK|=0x01000000;			//PORTD clock enable
//------- PortD for LEDS -------
	PORTD->FUNC=0;							//Port_D - ports
	PORTD->ANALOG=0xFFFF;					//Port_D - digital
	PORTD->RXTX=0;							
	PORTD->OE=0x7F80;						//Port_D[14..7] - outputs
	PORTD->PWR=0x3FFFC000;					//Port_D[14..7] - fast edge
}


#endif	//__CONFIG_C

