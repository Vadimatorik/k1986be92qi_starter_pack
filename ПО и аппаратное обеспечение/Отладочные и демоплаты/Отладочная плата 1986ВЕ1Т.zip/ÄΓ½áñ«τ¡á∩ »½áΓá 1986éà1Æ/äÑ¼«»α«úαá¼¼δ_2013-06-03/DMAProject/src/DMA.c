
#ifndef	__DMA_C
#define	__DMA_C

#include "opora.h"
#include "DMA.h"
#include "CBuffer.h"

extern DMAManagementStructureTypeDef	ManagementStructure[2];
extern CBufferTypeDef					Buffer;

void DMAInit()
{
	RST_CLK->PER_CLOCK|=1<<5;

	ManagementStructure[1].SourceEndPointer=UART1_BASE;							//address of register UART1->DR
	ManagementStructure[1].DestinationEndPointer=(uint32_t)(&Buffer.Data[7]);	//Destination end pointer address
	ManagementStructure[1].Control=0x0C000071;									//DMA cycle = 8

	DMA->CTRL_BASE_PTR=BASE_PTR;
	DMA->CHNL_ENABLE_CLR=0xFFFFFFFF;	//disable all channel
	DMA->CHNL_REQ_MASK_SET=0xFFFFFFFF;	//disable all request
	DMA->CHNL_PRI_ALT_CLR=0xFFFFFFFF;	//all channel use primary management structure
	DMA->CHNL_USEBURST_CLR=2;			//enable dma_sreq[] for UART1
	DMA->CHNL_REQ_MASK_CLR=2;			//enable dma_sreq[] for UART1
	DMA->CHNL_ENABLE_SET=0x2;			//enable channel 1 for UART1

	DMA->CFG=1;							//DMA enable
}
#endif	//__DMA_C

