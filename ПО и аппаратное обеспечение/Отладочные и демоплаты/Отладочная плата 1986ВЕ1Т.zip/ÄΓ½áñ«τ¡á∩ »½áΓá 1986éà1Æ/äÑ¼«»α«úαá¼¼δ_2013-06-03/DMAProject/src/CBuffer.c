
#ifndef	__CBUFFER_C
#define	__CBUFFER_C

#include "CBuffer.h"

void CBufferInit(CBufferTypeDef* Buff)
{
	uint32_t temp;
	uint32_t* ptr;
	ptr=(uint32_t*)Buff;

	for(temp=0;temp<(LENGTH+20);temp++)	*ptr++ =0;
}

#endif	//__CBUFFER_C
