
#include "opora.h"
#include "config.h"

void ClkConfig(void);
void PortConfig(void);
void BkpInit(void);
void BKP_Handler(void);

unsigned int Temp;
int main()
{
	ClkConfig();
	PortConfig();
	BkpInit();
	NVIC_EnableIRQ(BKP_IRQn);
	while(1)
	{
		PORTD->SETTX = 0x4000;
		for(Temp=0;Temp<100000;Temp++);
		PORTD->CLRTX = 0x4000;
		for(Temp=0;Temp<100000;Temp++);
	}
}

//--- Clock configuration ---
void ClkConfig()
{
	uint32_t temp;

	RST_CLK->PER_CLOCK|=0x08;					//EEPROM Clock enable
	EEPROM->CMD = 0;

	RST_CLK->PER_CLOCK |= (1 << 27);			//BKP Clock enable
	temp = BKP->REG_0E;
	temp &= 0xFFFFFFC0;
	BKP->REG_0E = temp | (5 << 3) | 5;			// SelectRI = 0x5, LOW = 0x5; (for frequency below 40 MHz);

#ifndef REVISION_2
	RST_CLK->HS_CONTROL = 0x00000003;			//HSE - On; Generator mode On	
	while((RST_CLK->CLOCK_STATUS&0x04)!=0x04);	//Wait until HSE not ready
	RST_CLK->CPU_CLOCK = 0x00000102;			//CPU Clock = HSE (25MHz)
#else
	RST_CLK->HS_CONTROL = 0x00000001;			//HSE - On; Oscillator mode On
	while((RST_CLK->CLOCK_STATUS&0x04)!=0x04);	//Wait until HSE not ready
	RST_CLK->CPU_CLOCK = 0x00000002;			//CPU Clock = HSE (8MHz)
	RST_CLK->PLL_CONTROL=0x00000200;			//PLL_MUL = 2
	RST_CLK->PLL_CONTROL|=0x00000004;			//CPU PLL On
	while((RST_CLK->CLOCK_STATUS&0x02)!=0x02);	//wait until PLL CPU not ready
	RST_CLK->CPU_CLOCK=0x00000106;				//CPU Clock = 3*8MHz = 24 MHz
#endif	//REVISION_2

	RST_CLK->PER_CLOCK |= (1<<24)|(1<<27); 		//clock of PORTD and BKP On
}

//--- Ports configuration ---
void PortConfig()
{
	//*** Config port D for Leds ***
	PORTD->FUNC = 0x00000000;
	PORTD->RXTX = 0x0000;
	PORTD->OE = 0x7F80;
	PORTD->ANALOG = 0x7F80;
	PORTD->PWR = 0x3FFFC000;
}

//--- Battery Domain and Real Time Clock configuration
void BkpInit()
{
	if((BKP->REG_0F&(1<<4)) != (1<<4))			//if RTC stop
	{
		BKP->REG_0F |= 0x80000005;				//Reset RTC, select LSE for clocking RTC, oscillator mode, LSE On
		BKP->REG_0F &= 0x7FFFFFFF;

		while((BKP->REG_0F&(1<<13)) != (1<<13));	//wait until LSE not ready

		while((BKP->RTC_CS&(1<<6)) != 0);		//wait until write data in RTC
		BKP->RTC_PRL = 0x00008000;				//RTC div - 32768
		
		while((BKP->RTC_CS&(1<<6)) != 0);		//wait until write data in RTC
		BKP->REG_0F |= 0x00000010;				//RTC enable
		BKP->REG_0E = 0x0000802D;

		while((BKP->RTC_CS&(1<<6)) != 0);		//wait until write data in RTC

		BKP->RTC_ALRM = TIMEOUT-1;

		while((BKP->RTC_CS&(1<<6)) != 0);		//wait until write data in RTC
		BKP->RTC_CS = 0x00000020;				//interrupt enable
	}
	else										//if RTC alredy start up
	{
		while((BKP->RTC_CS&(1<<6)) != 0);		//wait until write data in RTC	
		BKP->RTC_ALRM = BKP->RTC_CNT + (TIMEOUT - 1);

		while((BKP->RTC_CS&(1<<6)) != 0);		//wait until write data in RTC	
		BKP->RTC_CS |= 0x00000020;				//enable ALR_IE interrupt
	}
}

void BKP_Handler()
{
	PORTD->RXTX = 1<<7;							//flash light of VD6

	while((BKP->RTC_CS&(1<<6)) != 0);			//wait until write data in RTC
	BKP->RTC_CS |= 0x00000004;					//clear ALRF in RTC_CS

	while((BKP->RTC_CS&(1<<6)) != 0);			//wait until write data in RTC
	BKP->RTC_ALRM = BKP->RTC_CNT + (TIMEOUT - 1);	//interrupt every 10 seconds

	for(Temp=0;Temp<100000;Temp++);				//little delay

	BKP->REG_0F |= 0x40000000;					//STANBY mode
}

