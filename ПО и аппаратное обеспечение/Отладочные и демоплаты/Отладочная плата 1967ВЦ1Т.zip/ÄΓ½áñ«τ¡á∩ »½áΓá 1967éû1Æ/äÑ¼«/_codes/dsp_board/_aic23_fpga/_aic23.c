/*
������ ��������� ������ 5600��1�
*/

#include "_include.h"
#include "tlv320aic23.h"

#define LSAMPLES_SIZE 40000//23
#define RSAMPLES_SIZE 0xDE

void _DSP_EN(unsigned short _p);

static void _delay(void)
{
unsigned long _i;
	for(_i=0;_i<=0x00000fff;_i++)
		asm("   NOP  ");
}

//------------------------SPI
static unsigned short _SPC_cash; //�������� default

//��������� SSP
static void _SPI_init()
{
//init cash
	_SPC_cash=0xC038; //1100 0000  0011 1000
	
	
	_SSP_SPC_SET(_SPC_cash); 	
}
static void _SPI_EN(unsigned short _p)
{
	if(_p)
		_SSP_SPC_SET(_SPC_cash | (0x00001<<6)); //on tx	
	else
		_SSP_SPC_SET(_SPC_cash & ~(0x00001<<6)); //off tx	
}



static void _SPI_send(unsigned short _data)
{

	asm("  RSBX XF  ");	
	asm("  NOP ");
	asm("  SSBX XF ");	
	
	_SPI_EN(1);
		
	while(!(_SSP_SPC_GET()&(0x0001<<11))); //���� ���� XRDY != 1
	_SSP_DXR_SET(_data);
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	//while(!(_SSP_SPC_GET()&(0x0001<<11))); //���� ���� XRDY != 1
	_SSP_DXR_SET(_data); //send ��� ������� sync FX
	while((_SSP_SPC_GET()&(0x0001<<12))); //���� ���� XSREMPTY == 1
	
	_SPI_EN(0);
}
//-------------------------------


//------------------------DSP data
static unsigned short _BSPC_cash; //�������� default
static short _lsample[LSAMPLES_SIZE];
static short _rsample[RSAMPLES_SIZE];
#pragma DATA_SECTION(_SendBuffer,".cycle1")
static unsigned short _SendBuffer[6];


//��������� BSP
static void _DSP_init()
{
	asm("  ssbx  intm  ");
	asm("  stm     #0, imr  ");
//init cash
	_BSPC_cash=0xC000; //1100 0000  0000 0000
	//_BSPC_cash=0xC038; //1100 0000  0011 1000

	
	_IMR_SET(_IMR_GET() | (0x0001<<5)); //intr BXINT0 enable
	
	_SendBuffer[0] = _lsample[0];
	_SendBuffer[1] = _lsample[0];/*_rsample[_j];*/	
	_BSP_BKX_SET(0x6); //size TX ABU
	_BSP_AXR_SET(0x0); //start TX ABU	
	_BSP_SPCE_SET(_BSP_SPCE_GET() | (0x0001<<6) | (0x0001<<12) | (0x0001<<10)); //ABU enable
	_BSP_SPC_SET(_BSPC_cash | (0x00001<<6)); //on tx	
	
	
//1kHz sine 22050Hz
//0x0000 - 0x7fff ������� �����
//0x8000 - 0xffff �����. �����
//0x0000,0x0001 ... �� 0x7fff � ������� �������
//0x0000,0xffff,0xfffe .. �� 0x8000 � �����. �������
	/*_lsample[0] = 0x8001;
	_lsample[1] = 0x23FC;
	_lsample[2] = 0x450E;
	_lsample[3] = 0x6093;
	_lsample[4] = 0x744A;
	_lsample[5] = 0x7EA4;
	_lsample[6] = 0x7EC2;
	_lsample[7] = 0x74AB;
	_lsample[8] = 0x612C;
	_lsample[9] = 0x45D2;
	_lsample[10] = 0x24DB;
	_lsample[11] = 0x00EA;
	_lsample[12] = 0xDCE5;
	_lsample[13] = 0xBBB6;
	_lsample[14] = 0xA007;
	_lsample[15] = 0x8C17;
	_lsample[16] = 0x8180;
	_lsample[17] = 0x811E;
	_lsample[18] = 0x8AF5;
	_lsample[19] = 0x9E3D;
	_lsample[20] = 0xB96A;
	_lsample[21] = 0xDA45;
	_lsample[22] = 0xFE2C;*/
	
	
_rsample[0] = 0x59;
_rsample[1] = 0x390;
_rsample[2] = 0x75d;
_rsample[3] = 0xae4;
_rsample[4] = 0xe9a;
_rsample[5] = 0x122a;
_rsample[6] = 0x15ce;
_rsample[7] = 0x195d;
_rsample[8] = 0x1cf1;
_rsample[9] = 0x2079;
_rsample[10] = 0x23ff;
_rsample[11] = 0x277b;
_rsample[12] = 0x2aee;
_rsample[13] = 0x2e5b;
_rsample[14] = 0x31ba;
_rsample[15] = 0x3513;
_rsample[16] = 0x385c;
_rsample[17] = 0x3ba1;
_rsample[18] = 0x3ed4;
_rsample[19] = 0x41fa;
_rsample[20] = 0x4511;
_rsample[21] = 0x4821;
_rsample[22] = 0x4b18;
_rsample[23] = 0x4e08;
_rsample[24] = 0x50e2;
_rsample[25] = 0x53ae;
_rsample[26] = 0x566a;
_rsample[27] = 0x590d;
_rsample[28] = 0x5ba6;
_rsample[29] = 0x5e29;
_rsample[30] = 0x609b;
_rsample[31] = 0x62f2;
_rsample[32] = 0x6537;
_rsample[33] = 0x676a;
_rsample[34] = 0x6985;
_rsample[35] = 0x6b8c;
_rsample[36] = 0x6d7a;
_rsample[37] = 0x6f55;
_rsample[38] = 0x7116;
_rsample[39] = 0x72bf;
_rsample[40] = 0x7452;
_rsample[41] = 0x75ca;
_rsample[42] = 0x772e;
_rsample[43] = 0x7875;
_rsample[44] = 0x79a5;
_rsample[45] = 0x7abd;
_rsample[46] = 0x7bb8;
_rsample[47] = 0x7c9e;
_rsample[48] = 0x7d64;
_rsample[49] = 0x7e16;
_rsample[50] = 0x7ea9;
_rsample[51] = 0x7f24;
_rsample[52] = 0x7f83;
_rsample[53] = 0x7fcb;
_rsample[54] = 0x7ff6;
_rsample[55] = 0x7ffd;
_rsample[56] = 0x7ffb;
_rsample[57] = 0x7fda;
_rsample[58] = 0x7f96;
_rsample[59] = 0x7f40;
_rsample[60] = 0x7ecb;
_rsample[61] = 0x7e3b;
_rsample[62] = 0x7d95;
_rsample[63] = 0x7cd1;
_rsample[64] = 0x7bf4;
_rsample[65] = 0x7afd;
_rsample[66] = 0x79ec;
_rsample[67] = 0x78c5;
_rsample[68] = 0x7782;
_rsample[69] = 0x7627;
_rsample[70] = 0x74b2;
_rsample[71] = 0x7326;
_rsample[72] = 0x7181;
_rsample[73] = 0x6fc6;
_rsample[74] = 0x6df1;
_rsample[75] = 0x6c0b;
_rsample[76] = 0x6a0a;
_rsample[77] = 0x67f2;
_rsample[78] = 0x65c8;
_rsample[79] = 0x6385;
_rsample[80] = 0x6130;
_rsample[81] = 0x5ec7;
_rsample[82] = 0x5c47;
_rsample[83] = 0x59b7;
_rsample[84] = 0x5715;
_rsample[85] = 0x545d;
_rsample[86] = 0x519a;
_rsample[87] = 0x4ebf;
_rsample[88] = 0x4bd6;
_rsample[89] = 0x48e0;
_rsample[90] = 0x45d7;
_rsample[91] = 0x42c1;
_rsample[92] = 0x3fa0;
_rsample[93] = 0x3c6c;
_rsample[94] = 0x392f;
_rsample[95] = 0x35e7;
_rsample[96] = 0x3291;
_rsample[97] = 0x2f31;
_rsample[98] = 0x2bc9;
_rsample[99] = 0x2857;
_rsample[100] = 0x24dd;
_rsample[101] = 0x215d;
_rsample[102] = 0x1dd1;
_rsample[103] = 0x1a42;
_rsample[104] = 0x16b1;
_rsample[105] = 0x1313;
_rsample[106] = 0xf78;
_rsample[107] = 0xbd7;
_rsample[108] = 0x833;
_rsample[109] = 0x491;
_rsample[110] = 0xe8;
_rsample[111] = 0xfd43;
_rsample[112] = 0xf99f;
_rsample[113] = 0xf5f8;
_rsample[114] = 0xf257;
_rsample[115] = 0xeebb;
_rsample[116] = 0xeb1e;
_rsample[117] = 0xe787;
_rsample[118] = 0xe3f6;
_rsample[119] = 0xe068;
_rsample[120] = 0xdce4;
_rsample[121] = 0xd965;
_rsample[122] = 0xd5ed;
_rsample[123] = 0xd281;
_rsample[124] = 0xcf1e;
_rsample[125] = 0xcbc1;
_rsample[126] = 0xc874;
_rsample[127] = 0xc530;
_rsample[128] = 0xc1f8;
_rsample[129] = 0xbed0;
_rsample[130] = 0xbbb1;
_rsample[131] = 0xb8a1;
_rsample[132] = 0xb5a4;
_rsample[133] = 0xb2b1;
_rsample[134] = 0xafd2;
_rsample[135] = 0xad03;
_rsample[136] = 0xaa47;
_rsample[137] = 0xa796;
_rsample[138] = 0xa4fd;
_rsample[139] = 0xa277;
_rsample[140] = 0xa001;
_rsample[141] = 0x9da5;
_rsample[142] = 0x9b55;
_rsample[143] = 0x9921;
_rsample[144] = 0x96ff;
_rsample[145] = 0x94f6;
_rsample[146] = 0x92fe;
_rsample[147] = 0x9120;
_rsample[148] = 0x8f59;
_rsample[149] = 0x8daa;
_rsample[150] = 0x8c10;
_rsample[151] = 0x8a91;
_rsample[152] = 0x8928;
_rsample[153] = 0x87da;
_rsample[154] = 0x86a4;
_rsample[155] = 0x8586;
_rsample[156] = 0x8485;
_rsample[157] = 0x839a;
_rsample[158] = 0x82cc;
_rsample[159] = 0x8214;
_rsample[160] = 0x817b;
_rsample[161] = 0x80f6;
_rsample[162] = 0x8091;
_rsample[163] = 0x8045;
_rsample[164] = 0x8011;
_rsample[165] = 0x8000;
_rsample[166] = 0x8001;
_rsample[167] = 0x8020;
_rsample[168] = 0x8053;
_rsample[169] = 0x80a8;
_rsample[170] = 0x8115;
_rsample[171] = 0x819f;
_rsample[172] = 0x823e;
_rsample[173] = 0x82fc;
_rsample[174] = 0x83d2;
_rsample[175] = 0x84c3;
_rsample[176] = 0x85cd;
_rsample[177] = 0x86ef;
_rsample[178] = 0x882b;
_rsample[179] = 0x8980;
_rsample[180] = 0x8aef;
_rsample[181] = 0x8c75;
_rsample[182] = 0x8e12;
_rsample[183] = 0x8fc9;
_rsample[184] = 0x9195;
_rsample[185] = 0x9379;
_rsample[186] = 0x9575;
_rsample[187] = 0x9786;
_rsample[188] = 0x99ad;
_rsample[189] = 0x9be7;
_rsample[190] = 0x9e38;
_rsample[191] = 0xa09e;
_rsample[192] = 0xa317;
_rsample[193] = 0xa5a3;
_rsample[194] = 0xa841;
_rsample[195] = 0xaaf2;
_rsample[196] = 0xadb3;
_rsample[197] = 0xb089;
_rsample[198] = 0xb36f;
_rsample[199] = 0xb660;
_rsample[200] = 0xb966;
_rsample[201] = 0xbc77;
_rsample[202] = 0xbf96;
_rsample[203] = 0xc2c7;
_rsample[204] = 0xc600;
_rsample[205] = 0xc944;
_rsample[206] = 0xcc99;
_rsample[207] = 0xcff4;
_rsample[208] = 0xd35c;
_rsample[209] = 0xd6cd;
_rsample[210] = 0xda3f;
_rsample[211] = 0xddc7;
_rsample[212] = 0xe147;
_rsample[213] = 0xe4da;
_rsample[214] = 0xe869;
_rsample[215] = 0xec04;
_rsample[216] = 0xef9f;
_rsample[217] = 0xf33b;
_rsample[218] = 0xf6ec;
_rsample[219] = 0xfa73;
_rsample[220] = 0xfe54;
_rsample[221] = 0xfe54;
	
	
	
	
	
	
}

#pragma CODE_SECTION(_DSP_EN, ".funcs")
static void _DSP_EN(unsigned short _p)
{
//�������� ��� ����� � ������������	
//�� ������� ������ BCLKX ������������ BFSX, ABU TX enabled	
	if(_p)
	{
		_BSP_BKX_SET(0x6); //size TX ABU
		_BSP_AXR_SET(0x0); //start TX ABU	
		_BSP_SPCE_SET(_BSP_SPCE_GET() | (0x0001<<6) | (0x0001<<12) | (0x0001<<10)); //ABU enable
		_BSP_SPC_SET(_BSPC_cash | (0x00001<<6)); //on tx	
	}
	else
		_BSP_SPC_SET(_BSPC_cash & ~(0x00001<<6)); //off tx	
}


#pragma CODE_SECTION(DSP_send, ".funcs")
void DSP_send()
{
static unsigned short _i=1,_j=1;
	
	_DSP_EN(0);
	_SendBuffer[0] = _lsample[_i];
	_SendBuffer[1] = _lsample[_i];/*_rsample[_j];*/
	
	//_data=0x8000;
	//asm("   SSBX INTM ");		
	//_BSP_DXR_SET(_data);
//while((_BSP_SPCE_GET()&(0x0001<<11))); //���� ���� XH == 1
//while(!(_BSP_SPC_GET()&(0x0001<<11))); //���� ���� XRDY != 1
	//_BSP_DXR_SET(_data); //�� �������� ������ ����� � poll 
	//asm("   RSBX INTM ");		
//while((_BSP_SPC_GET()&(0x0001<<12))); //���� ���� XSREMPTY == 1
	_i++;
	_j++;
	if(_i==LSAMPLES_SIZE)
		_i=0;	
	if(_j==RSAMPLES_SIZE)
		_j=0;		
	
	_DSP_EN(1);	
}
//-------------------------------


//---------------------AIC23
static unsigned short tlv320aic23_reg[16];
/*
250  * Common Crystals used
251  * 11.2896 Mhz /128 = *88.2k  /192 = 58.8k
252  * 12.0000 Mhz /125 = *96k    /136 = 88.235K
253  * 12.2880 Mhz /128 = *96k    /192 = 64k
254  * 16.9344 Mhz /128 = 132.3k /192 = *88.2k
255  * 18.4320 Mhz /128 = 144k   /192 = *96k
*/
 
/*
259  * Normal BOSR 0-256/2 = 128, 1-384/2 = 192
260  * USB BOSR 0-250/2 = 125, 1-272/2 = 136
261 */

static long bosr_usb_divisor_table[4];
static unsigned short sr_valid_mask[4];


static unsigned char sr_adc_mult_table[16];
static unsigned char sr_dac_mult_table[16];
 

static unsigned long get_score(long adc, long adc_l, long adc_h, long need_adc,long dac, long dac_l, long dac_h, long need_dac)
{
long diff_adc;
long diff_dac;

	if ((adc >= adc_l) && (adc <= adc_h) && (dac >= dac_l) && (dac <= dac_h)) 
	{
		diff_adc = need_adc - adc;
		diff_dac = need_dac - dac;
		return abs(diff_adc) + abs(diff_dac);
	}
		return UINT_MAX;
}


/*
 41  * AIC23 register cache
 42  */

static void _AIC23_init()
{
//init cash
	tlv320aic23_reg[TLV320AIC23_LINVOL]=	0x0097; 	
	tlv320aic23_reg[TLV320AIC23_RINVOL]=	0x0097;
	tlv320aic23_reg[TLV320AIC23_LCHNVOL]=	0x00F9;
	tlv320aic23_reg[TLV320AIC23_RCHNVOL]=	0x00F9;
	tlv320aic23_reg[TLV320AIC23_ANLG]=		0x001A;
	tlv320aic23_reg[TLV320AIC23_DIGT]=		0x0004;
	tlv320aic23_reg[TLV320AIC23_PWR]=		0x0007;
	tlv320aic23_reg[TLV320AIC23_DIGT_FMT]=	0x0001;
	tlv320aic23_reg[TLV320AIC23_SRATE]=		0x0020;
	tlv320aic23_reg[TLV320AIC23_ACTIVE]=	0x0000;
	tlv320aic23_reg[TLV320AIC23_RESET]=		0x0000;	
	tlv320aic23_reg[11]=					0x0000;
	tlv320aic23_reg[12]=					0x0000;
	tlv320aic23_reg[13]=					0x0000;
	tlv320aic23_reg[14]=					0x0000;
	tlv320aic23_reg[15]=					0x0000;
	
	
	
	bosr_usb_divisor_table[0]=93750; 
	bosr_usb_divisor_table[1]=96000; 
	bosr_usb_divisor_table[2]=62500; 
	bosr_usb_divisor_table[3]=88235;


	sr_valid_mask[0] = LOWER_GROUP|UPPER_GROUP;
	sr_valid_mask[1] = LOWER_GROUP;
	sr_valid_mask[2] = LOWER_GROUP|UPPER_GROUP;
	sr_valid_mask[3] = UPPER_GROUP;
	
 
	sr_adc_mult_table[0]=66;
	sr_adc_mult_table[1]=66;
	sr_adc_mult_table[2]=11;
	sr_adc_mult_table[3]=11;
	sr_adc_mult_table[4]=0;
	sr_adc_mult_table[5]=0;
	sr_adc_mult_table[6]=44;
	sr_adc_mult_table[7]=132;
	sr_adc_mult_table[8]=66;
	sr_adc_mult_table[9]=66;
	sr_adc_mult_table[10]=12;
	sr_adc_mult_table[11]=12;
	sr_adc_mult_table[12]=0;
	sr_adc_mult_table[13]=0;
	sr_adc_mult_table[14]=0;
	sr_adc_mult_table[15]=132;
	
	sr_dac_mult_table[0]=66;
	sr_dac_mult_table[1]=11;
	sr_dac_mult_table[2]=66;
	sr_dac_mult_table[3]=11;
	sr_dac_mult_table[4]=0;
	sr_dac_mult_table[5]=0;
	sr_dac_mult_table[6]=44;
	sr_dac_mult_table[7]=132;
	sr_dac_mult_table[8]=66;
	sr_dac_mult_table[9]=12;
	sr_dac_mult_table[10]=66;
	sr_dac_mult_table[11]=12;
	sr_dac_mult_table[12]=0;
	sr_dac_mult_table[13]=0;
	sr_dac_mult_table[14]=0;
	sr_dac_mult_table[15]=132;
}


/*
 51  * read tlv320aic23 register cache
 52  */
static unsigned short tlv320aic23_read_reg_cache(unsigned short reg)
{

	if (reg >= sizeof(tlv320aic23_reg))
		return -1;
    return tlv320aic23_reg[reg];
}

/*
 63  * write tlv320aic23 register cache
*/
static void tlv320aic23_write_reg_cache(unsigned short reg, unsigned short value)
{

	if (reg >= sizeof(tlv320aic23_reg))
		return;
	tlv320aic23_reg[reg] = value;
}

/*
 75  * write to the tlv320aic23 register space
*/
static unsigned short tlv320aic23_write(unsigned short reg, unsigned short value)
{
 
unsigned char data[2];
 
       /* TLV320AIC23 has 7 bit address and 9 bits of data
 84          * so we need to switch one data bit into reg and rest
 85          * of data into val
         */
 
	if (reg > 9 && reg != 15) 
	{
		return -1;
	}
 
	data[0] = (reg << 1) | (value >> 8 & 0x01);
    data[1] = value & 0xff;
 
    tlv320aic23_write_reg_cache(reg, value);
 	_SPI_send((data[0]<<8)+data[1]);
 		 	
 
    return 0;
}


static unsigned short tlv320aic23_set_bias_level(unsigned short level)
{
unsigned short reg;
	reg = tlv320aic23_read_reg_cache(TLV320AIC23_PWR) & 0xff7f;

    switch (level) 
    {
    case SND_SOC_BIAS_ON:
/* vref/mid, osc on, dac unmute */
		reg &= ~(TLV320AIC23_DEVICE_PWR_OFF | TLV320AIC23_OSC_OFF | TLV320AIC23_DAC_OFF);
		tlv320aic23_write(TLV320AIC23_PWR, reg);
	break;
	case SND_SOC_BIAS_PREPARE:
	break;
	case SND_SOC_BIAS_STANDBY:
/* everything off except vref/vmid, */
	tlv320aic23_write(TLV320AIC23_PWR, reg | TLV320AIC23_CLK_OFF);
	break;
	case SND_SOC_BIAS_OFF:
	/* everything off, dac mute, inactive */
		tlv320aic23_write(TLV320AIC23_ACTIVE, 0x0);
		tlv320aic23_write(TLV320AIC23_PWR, 0xffff);
	break;
	}

	return 0;
}

static unsigned short tlv320aic23_set_dai_fmt(void)
{
unsigned short iface_reg;
 
	iface_reg = tlv320aic23_read_reg_cache(TLV320AIC23_DIGT_FMT) & (~0x03);
/* set master/slave audio interface */
	iface_reg |= TLV320AIC23_MS_MASTER;
/* interface format */	
#if 0	
	iface_reg |= TLV320AIC23_FOR_I2S; //I2S
#else	
	//iface_reg |= TLV320AIC23_LRP_ON;
	iface_reg |= TLV320AIC23_FOR_DSP | TLV320AIC23_LRP_ON;/* | TLV320AIC23_IWL_32;*/
#endif	
	

	tlv320aic23_write(TLV320AIC23_DIGT_FMT, iface_reg);

    return 0;
}

//#pragma CODE_SECTION(find_rate, ".funcs")
static long find_rate(unsigned short mclk, unsigned long need_adc, unsigned long need_dac)
{
long i, j;
long best_i;
long best_j;
long best_div = 0;
unsigned long best_score;
long adc_l, adc_h, dac_l, dac_h;
long base;
long mask;
long adc;
long dac;
long score;

	best_i = -1;
	best_j = -1;
 	best_score = UINT_MAX;
 	adc=0x0000;
 	dac=0x0000;
 	
	need_adc *= SR_MULT;
	need_dac *= SR_MULT;
/*
311          * rates given are +/- 1/32
312          */
	adc_l = need_adc - (need_adc >> 5);
	adc_h = need_adc + (need_adc >> 5);
	dac_l = need_dac - (need_dac >> 5);
	dac_h = need_dac + (need_dac >> 5);
	for (i = 0; i < sizeof(bosr_usb_divisor_table); i++) 
	{
	
		base = bosr_usb_divisor_table[i];
		mask = sr_valid_mask[i];
		for (j = 0; j < sizeof(sr_adc_mult_table); j++, mask >>= 1) 
		{		
			if ((mask & 1) == 0)
				continue;
			adc = base * sr_adc_mult_table[j];
			dac = base * sr_dac_mult_table[j];			
    		score = get_score(adc, adc_l, adc_h, need_adc,dac, dac_l, dac_h, need_dac);
			if (best_score > score) 
			{
				best_score = score;
				best_i = i;
				best_j = j;
				best_div = 0;
			}
			score = get_score((adc >> 1), adc_l, adc_h, need_adc,(dac >> 1), dac_l, dac_h, need_dac);
/* prefer to have a /2 */
			if ((score != UINT_MAX) && (best_score >= score)) 
			{
				best_score = score;
				best_i = i;
				best_j = j;
				best_div = 1;
			}
		}
	}
	return (best_j << 2) | best_i | (best_div << TLV320AIC23_CLKIN_SHIFT);
}


static unsigned short set_sample_rate_control(unsigned long mclk,unsigned long sample_rate_adc, unsigned long sample_rate_dac)
{
/* Search for the right sample rate */
long data;

	data = find_rate(mclk, sample_rate_adc, sample_rate_dac);
	if (data < 0) 
	{
		return -1;
	}
	tlv320aic23_write(TLV320AIC23_SRATE, data );
	return 0;
	
}




static unsigned short tlv320aic23_probe()
{
	unsigned short reg;
/* Reset codec */
	tlv320aic23_write(TLV320AIC23_RESET, 0);
	
/* power on device */
	tlv320aic23_set_bias_level(SND_SOC_BIAS_ON);
	tlv320aic23_write(TLV320AIC23_DIGT, TLV320AIC23_ADCHP_ON);

/* Unmute input */
	reg = tlv320aic23_read_reg_cache(TLV320AIC23_LINVOL);
	tlv320aic23_write(TLV320AIC23_LINVOL,(reg & (~TLV320AIC23_LIM_MUTED)) |(TLV320AIC23_LRS_ENABLED));

	reg = tlv320aic23_read_reg_cache(TLV320AIC23_RINVOL);
	tlv320aic23_write(TLV320AIC23_RINVOL, (reg & (~TLV320AIC23_LIM_MUTED)) | TLV320AIC23_LRS_ENABLED);

	reg = tlv320aic23_read_reg_cache(TLV320AIC23_ANLG);
	tlv320aic23_write(TLV320AIC23_ANLG, (reg) & (~TLV320AIC23_BYPASS_ON) & (~TLV320AIC23_MICM_MUTED));

/* Default output volume */
	tlv320aic23_write(TLV320AIC23_LCHNVOL, TLV320AIC23_OUT_VOL_MAX & TLV320AIC23_OUT_VOL_MASK);
	tlv320aic23_write(TLV320AIC23_RCHNVOL, TLV320AIC23_OUT_VOL_MAX & TLV320AIC23_OUT_VOL_MASK);
	
/*������ �������� audio*/	
	tlv320aic23_set_dai_fmt();
/*sample rate playback*/	
	set_sample_rate_control(MCLK,ADC_SRATE, DAC_SRATE);

	tlv320aic23_write(TLV320AIC23_ACTIVE, 0x1);
 
	return 0;
}


//-------------------------

void test1()
{
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");

}

void _test_aic23(void)
{
#if 0
	asm("  rsbx  intm  ");
	asm("  intr 0  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 1  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 2  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 3  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 4  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 5  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 6  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 7  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 8  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 9  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 10  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 11  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 12  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 13  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 14  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 15  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 16  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 17  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 18  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 19  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 20  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 21  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 22  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 23  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
	
	asm("  intr 24  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");
#endif	
	
	
	_SPI_init();
#if 1	
	_AIC23_init();
	tlv320aic23_probe(); //���� aic23
	_PLL_init50();
	_DSP_init();
	asm("  rsbx  intm  ");
	asm("  NOP   ");
	asm("  NOP   ");
	asm("  NOP   ");	
	while(1)
	{
		asm("  NOP   ");
		asm("  NOP   ");
		asm("  NOP   ");		
	}
#endif	
	while(1)
	{
		_SPI_send(0xaaaa);
		_delay();
	}
}


