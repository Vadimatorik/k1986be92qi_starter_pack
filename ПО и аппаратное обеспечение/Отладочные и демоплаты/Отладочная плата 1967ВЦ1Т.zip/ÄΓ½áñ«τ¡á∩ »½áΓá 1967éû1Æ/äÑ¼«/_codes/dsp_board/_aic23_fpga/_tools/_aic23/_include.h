typedef unsigned short	Uint16;

#define REG16(addr)		(*(volatile Uint16*)(addr))
#define _REG_GET(RegAddr)         (Uint16)REG16(RegAddr)
#define _REG_SET(RegAddr,Val)      REG16(RegAddr)=(Uint16)(Val)

#define _PLL_CLKMD_ADDR           (0x0058u)
#define _PLL_CLKMD_GET()          _REG_GET(_PLL_CLKMD_ADDR)
#define _PLL_CLKMD_SET(Val)       _REG_SET(_PLL_CLKMD_ADDR,Val)


#define _BSCR_ADDR           	(0x0029u)
#define _BSCR_ADDR_GET()          _REG_GET(_BSCR_ADDR)
#define _BSCR_ADDR_SET(Val)       _REG_SET(_BSCR_ADDR,Val)

//Buffer SSP
#define _SSP_SPC_ADDR           (0x0032u)
#define _SSP_SPC_GET()          _REG_GET(_SSP_SPC_ADDR)
#define _SSP_SPC_SET(Val)       _REG_SET(_SSP_SPC_ADDR,Val)

#define _SSP_DXR_ADDR           (0x0031u)
#define _SSP_DXR_SET(Val)       _REG_SET(_SSP_DXR_ADDR,Val)


extern void _test_aic23(void);

extern unsigned short gvar1;

#define UINT_MAX        (~0U)


