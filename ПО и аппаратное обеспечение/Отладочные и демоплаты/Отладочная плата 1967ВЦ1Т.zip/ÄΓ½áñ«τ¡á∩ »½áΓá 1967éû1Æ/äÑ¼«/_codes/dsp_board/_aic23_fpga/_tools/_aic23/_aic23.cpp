// _aic23.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <io.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <share.h>



static unsigned char *_infile = (unsigned char *)"./_data/rand.seq";
static unsigned char *_outfile = (unsigned char *)"./_data/_rand.seq";
static FILE *_inf;
static FILE *_outf;


int _tmain(int argc, _TCHAR* argv[])
{
unsigned short _buff;
unsigned long  _counter;

	_inf = fopen((const char *)_infile,"rb");	
	_outf = fopen((const char *)_outfile,"w+b");
	_counter=0;
	while(!feof( _inf ))
	{
		fread((void *)&_buff,1,2,_inf);	
		fprintf(_outf,"0x%x\n",_buff);	
		_counter++;
	}

	fclose(_inf);
	fclose(_outf);
	fprintf(stderr,"finished\n");
	getchar();
	return 0;
}

