typedef unsigned short	Uint16;

#define REG16(addr)		(*(volatile Uint16*)(addr))
#define _REG_GET(RegAddr)         (Uint16)REG16(RegAddr)
#define _REG_SET(RegAddr,Val)      REG16(RegAddr)=(Uint16)(Val)

//IFR
#define _IFR_ADDR           (0x0001u)
#define _IFR_GET()          _REG_GET(_IFR_ADDR)
#define _IFR_SET(Val)       _REG_SET(_IFR_ADDR,Val)

//IMR
#define _IMR_ADDR           (0x000u)
#define _IMR_GET()          _REG_GET(_IMR_ADDR)
#define _IMR_SET(Val)       _REG_SET(_IMR_ADDR,Val)


#define _PLL_CLKMD_ADDR           (0x0058u)
#define _PLL_CLKMD_GET()          _REG_GET(_PLL_CLKMD_ADDR)
#define _PLL_CLKMD_SET(Val)       _REG_SET(_PLL_CLKMD_ADDR,Val)


#define _BSCR_ADDR           	(0x0029u)
#define _BSCR_ADDR_GET()          _REG_GET(_BSCR_ADDR)
#define _BSCR_ADDR_SET(Val)       _REG_SET(_BSCR_ADDR,Val)

//SSP
#define _SSP_SPC_ADDR           (0x0032u)
#define _SSP_SPC_GET()          _REG_GET(_SSP_SPC_ADDR)
#define _SSP_SPC_SET(Val)       _REG_SET(_SSP_SPC_ADDR,Val)

#define _SSP_DXR_ADDR           (0x0031u)
#define _SSP_DXR_SET(Val)       _REG_SET(_SSP_DXR_ADDR,Val)


//BSP
#define _BSP_SPC_ADDR           (0x0022u)
#define _BSP_SPC_GET()          _REG_GET(_BSP_SPC_ADDR)
#define _BSP_SPC_SET(Val)       _REG_SET(_BSP_SPC_ADDR,Val)

#define _BSP_SPCE_ADDR           (0x0023u)
#define _BSP_SPCE_GET()          _REG_GET(_BSP_SPCE_ADDR)
#define _BSP_SPCE_SET(Val)       _REG_SET(_BSP_SPCE_ADDR,Val)

#define _BSP_AXR_ADDR           (0x0038u)
#define _BSP_AXR_GET()          _REG_GET(_BSP_AXR_ADDR)
#define _BSP_AXR_SET(Val)       _REG_SET(_BSP_AXR_ADDR,Val)


#define _BSP_BKX_ADDR           (0x0039u)
#define _BSP_BKX_GET()          _REG_GET(_BSP_BKX_ADDR)
#define _BSP_BKX_SET(Val)       _REG_SET(_BSP_BKX_ADDR,Val)



#define _BSP_DXR_ADDR           (0x0021u)
#define _BSP_DXR_SET(Val)       _REG_SET(_BSP_DXR_ADDR,Val)



extern void _PLL_init50(void);
extern void _test_aic23(void);
extern void DSP_send(void);
extern void test1(void);

extern unsigned short gvar1;

#define UINT_MAX 4294967295

