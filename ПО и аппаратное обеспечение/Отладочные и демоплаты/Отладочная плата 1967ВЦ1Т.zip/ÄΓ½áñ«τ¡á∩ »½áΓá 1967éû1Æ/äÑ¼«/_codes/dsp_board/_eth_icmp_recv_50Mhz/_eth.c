/*
������ ��������� ������ 5600��1�
*/

#include "_include.h"

#define _MAC_H	0x89AB	
#define _MAC_M	0x4567
#define _MAC_T	0x0123

#define _ETH_HEADER		42
#define	_ICMP_SIZE	500  //ICMP size �� �����
#define	_ICMP_REPLY	32  //ICMP size �� �����

#define	_RX_SIZE_BYTE	_ICMP_SIZE+_ETH_HEADER //������ buffer
#define _RX_SIZE_WORD	(_RX_SIZE_BYTE/2)+10 //������ buffer � ������


static void _MAC_CTRL_opt(unsigned short _op);
unsigned short _MAC_CTRL_opt_get();


//00-1F-D0-97-4B-54
//_ADR_MAC[0]->_MAC_T->4B-54
//_ADR_MAC[1]->_MAC_M->D0-97
//_ADR_MAC[2]->_MAC_H->00-1F
//��� ������ var
static unsigned short _ADR_MAC[3];



static inline void _ioport_set(unsigned short adr,unsigned short _par)
{
unsigned short *_p;

	_p=(unsigned short *)(0xe000+(adr&0x1fff)); 
	*_p=_par; 
	
}

//#pragma CODE_SECTION(_ioport_get, ".problem")
static inline unsigned short _ioport_get(unsigned short adr)
{
unsigned short *_p;

	_p=(unsigned short *)(0xe000+(adr&0x1fff)); 	
	return *_p; 
	
}


//#pragma CODE_SECTION(_delay, "rfunc")
static void _delay(void)
{
unsigned long _i;
	for(_i=0;_i<0x000fffff;_i++)
		asm("	nop			");	
}


static void _delay1(void)
{
unsigned long _i;
	for(_i=0;_i<0x00ffffff;_i++)
		asm("	nop			");	
}

//�� ��������� 
//AC_ADDR_T(0xDFC5)->0x89AB
//AC_ADDR_M(0xDFC6)->0x4567
//AC_ADDR_H(0xDFC7)->0x0123
//� ����� ����� �� ����� � MAC ������� ����� dest ������ ����
//ab 89 67 45 23 01 
static  void _get_mac(unsigned short *_mac)
{
	
	_mac[0]=_ioport_get(0xDFC5);
	_mac[1]=_ioport_get(0xDFC6);
	_mac[2]=_ioport_get(0xDFC7);
}

static  void _set_mac(unsigned short *_mac)
{
	_ioport_set(0xDFC5,_mac[0]);
	_ioport_set(0xDFC6,_mac[1]);
	_ioport_set(0xDFC7,_mac[2]);	
}

//LINK_PERIOD set
static void _PHY_LINK_opt(void)
{
//11-6 bits
//111111	
	_ioport_set(0xDFCE,_ioport_get(0xDFCE) | (0x0001<<6));
	_ioport_set(0xDFCE,_ioport_get(0xDFCE) | (0x0001<<7));
	_ioport_set(0xDFCE,_ioport_get(0xDFCE) | (0x0001<<8));
	_ioport_set(0xDFCE,_ioport_get(0xDFCE) | (0x0001<<9));
	_ioport_set(0xDFCE,_ioport_get(0xDFCE) | (0x0001<<10));
	_ioport_set(0xDFCE,_ioport_get(0xDFCE) | (0x0001<<11));
}

//_op->0 bit set/unset ���������/��������� tx
//_op->1 bit set/unset ���������/��������� rx
//_op->2 bit set/unset RESET ���������/no RESET ���������
//_op->3 bit set/unset HALFD
//_op->4 bit set/unset DLB
//_op->5 bit set/unset LB 
static void _PHY_opt(unsigned short _op)
{
	if(_op&(0x0001<<0))
	{
		//��������� tx
		_ioport_set(0xDFCE,_ioport_get(0xDFCE) | (0x0001<<13));
		//portDFCE |= (0x0001<<13);
	}
	else
	{
		//��������� tx
		_ioport_set(0xDFCE,_ioport_get(0xDFCE) & ~(0x0001<<13));
		//portDFCE &= ~(0x0001<<13);
	}

	if(_op&(0x0001<<4))
	{
		//��������� DLB
		_ioport_set(0xDFCE,_ioport_get(0xDFCE) | (0x0001<<1));
		//portDFCE |= (0x0001<<1);
	}
	else
	{
		//��������� DLB
		_ioport_set(0xDFCE,_ioport_get(0xDFCE) & ~(0x0001<<1));
		//portDFCE &= ~(0x0001<<1);
	}

	if(_op&(0x0001<<5))
	{
		//��������� LB
		_ioport_set(0xDFCE,_ioport_get(0xDFCE) | (0x0001<<0));
		//portDFCE |= (0x0001<<0);
	}
	else
	{
		//��������� LB
		_ioport_set(0xDFCE,_ioport_get(0xDFCE) & ~(0x0001<<0));
		//portDFCE &= ~(0x0001<<0);
	}

	if(_op&(0x0001<<1))
	{
		//��������� rx
		_ioport_set(0xDFCE,_ioport_get(0xDFCE) | (0x0001<<12));
		//portDFCE |= (0x0001<<12);
	}
	else
	{
		//��������� rx
		_ioport_set(0xDFCE,_ioport_get(0xDFCE) & ~(0x0001<<12));
		//portDFCE &= ~(0x0001<<12);
	}

	if(_op&(0x0001<<2))
	{
		//������ RESET ���������
		_ioport_set(0xDFCE,_ioport_get(0xDFCE) | (0x0001<<15));
		//portDFCE |= (0x0001<<15);
	}
	else
	{
		//��� RESET ���������
		_ioport_set(0xDFCE,_ioport_get(0xDFCE) & ~(0x0001<<15));
		//portDFCE &= ~(0x0001<<15);
	}

	if(_op&(0x0001<<3))
	{
		//������ HALFD ���������
		_ioport_set(0xDFCE,_ioport_get(0xDFCE) | (0x0001<<2));
		//portDFCE |= (0x0001<<2);
	}
	else
	{
		//��� HALFD ���������
		_ioport_set(0xDFCE,_ioport_get(0xDFCE) & ~(0x0001<<2));
		//portDFCE &= ~(0x0001<<2);
	}
	
}

static unsigned short _PHY_opt_get()
{

	return _ioport_get(0xDFCE);//portDFCE;
}

static unsigned short _GCTRL_opt_get()
{
	return _ioport_get(0xDFDF);//portDFDF;
}

//_op->0 bit set/unset _RST
//_op->1 bit set/unset ASYNC_MODE
static void _GCTRL_opt(unsigned short _op)
{
	if(_op&(0x0001<<0))
	{
		//��������� _RST
		_ioport_set(0xDFDF,_ioport_get(0xDFDF) | (0x0001<<15));
		//portDFDF |= (0x0001<<15);
	}
	else
	{
		//��������� _RST
		_ioport_set(0xDFDF,_ioport_get(0xDFDF) & ~(0x0001<<15));
		//portDFDF &= ~(0x0001<<15);
	}

	if(_op&(0x0001<<1))
	{
		//��������� ASYNC_MODE
		_ioport_set(0xDFDF,_ioport_get(0xDFDF) | (0x0001<<12));
		//portDFDF |= (0x0001<<12);
	}
	else
	{
		//��������� ASYNC_MODE
		_ioport_set(0xDFDF,_ioport_get(0xDFDF) & ~(0x0001<<12));
		//portDFDF &= ~(0x0001<<12);
	}

	
}



static unsigned short _PHY_STAT_opt_get()
{
	return _ioport_get(0xDFCF);//portDFCF;
}


static unsigned short _STAT_RX_all()
{
	return _ioport_get(0xDFD4);//portDFD4;
}


static unsigned short _STAT_TX_all()
{
	return _ioport_get(0xDFD8);//portDFD8;
}


static unsigned short _STAT_RX_OK()
{
	return _ioport_get(0xDFD5);//portDFD5;
}

static unsigned short _STAT_RX_OVR()
{
	return _ioport_get(0xDFD6);//portDFD6;
}

static unsigned short _STAT_RX_LOS()
{
	return _ioport_get(0xDFD7);//portDFD7;
}

static unsigned short _STAT_TX_ALL()
{
	return _ioport_get(0xDFD8);//portDFD8;
}


static unsigned short _STAT_TX_OK()
{
	return _ioport_get(0xDFD9);//portDFD9;
}


static unsigned short _base_RXBD()
{
	return _ioport_get(0xDFDC);//portDFDC;
}

static unsigned short _base_RXBF()
{
	return _ioport_get(0xDFDA);//portDFDA;
}

static unsigned short _base_TXBD()
{
	return _ioport_get(0xDFDD);//portDFDD;
}

static void _set_base_TXBD(unsigned short _p)
{
	_ioport_set(0xDFDD,_p);
	//portDFDD=_p;
}

static unsigned short _base_TXBF()
{
	return _ioport_get(0xDFDB);//portDFDB;
}

static unsigned short _INT_SRC()
{
	return _ioport_get(0xDFCD);//portDFCD;
}




//��������� ����� ����� RX 
static void _RXBD_set(void)
{
unsigned short _res;		
//�� ��������� base_RXBD=0x0800
//�� ��������� base_RXBF=0x0000


//��������� RX_RST			
	_ioport_set(0xDFC0,_ioport_get(0xDFC0) | (0x0001<<14));					

	
	
	_ioport_set(0xC801,0x0800);
	_ioport_set(0xC802,0);
	_ioport_set(0xC803,0x0000);	
	_ioport_set(0xC800,0xC000);
	
	
//������� RX_RST			
	_ioport_set(0xDFC0,_ioport_get(0xDFC0) & ~(0x0001<<14));				

//���� ������ ���� ������������ OE � '1' �� PHY ��� ������ �����
//��� ������ �� RESET	
	*((unsigned short *)(0xe802)) = 0x0000;	
	
}

//��������� ����� ����� TX
//_p->0x01 clr 0 descr 
static void _TXBD_set(unsigned short _p)
{
unsigned short _i;	
unsigned short _res;	
//�� ��������� base_RXBD=0x0800
//�� ��������� base_RXBF=0x0000
//128 words TXBD
	if(_p)
	{
		for(_i=0;_i<32;_i++)
		{
			_ioport_set(0xD801+_i*4,0x0000); //41 bytes ����� � ������
			_ioport_set(0xD802+_i*4,0);
			_ioport_set(0xD803+_i*4,0x0000);	
			_ioport_set(0xD800+_i*4,0x0000);
		}
	}
	else
	{
			do
				_res=_ioport_get(0xD800);
			while(_res & 0x8000);
			

//��������� TX_RST			
			_ioport_set(0xDFC0,_ioport_get(0xDFC0) | (0x0001<<15));//������� TX_RST						
			
			
			
			_ioport_set(0xD801,_ETH_HEADER+_ICMP_REPLY); 			
			_ioport_set(0xD802,0);
			_ioport_set(0xD803,0x1000);	
			_ioport_set(0xD800,0xC000);
			
//������� TX_RST									
			_ioport_set(0xDFC0,_ioport_get(0xDFC0) & ~(0x0001<<15));
			
				
			
			
		
	}
//���� ������ ���� ������������ OE � '1' �� PHY ��� ������ �����
//��� ������ �� RESET		
	*((unsigned short *)(0xe802)) = 0x0000;		
	
}

//������� ����� ����� TX 
static void _TXBD_get(void)
{
unsigned short _res_d,_res_l,_res_ah,_res_al;
unsigned short _i;		
//�� ��������� base_RXBD=0x0800
//�� ��������� base_RXBF=0x0000
	for(_i=0;_i<32;_i++)
	{
		_res_d=_ioport_get(0xD800+_i*4);
		_res_l=_ioport_get(0xD801+_i*4); 
		_res_ah=_ioport_get(0xD802+_i*4);
		_res_al=_ioport_get(0xD803+_i*4);
		//if(_res_d != 0x4000)
			//_delay();	
	}
	
}


//get RX buffer
static unsigned short _rx_buff[_RX_SIZE_WORD];
static void _RXBF_get(void)
{
unsigned short _i;	

	for(_i=0;_i<_RX_SIZE_WORD;_i++)
		_rx_buff[_i]=_ioport_get(0xC000+_i);

	
}


//get pack type
static unsigned short _RXBF_get_type(void)
{
unsigned short _i;
unsigned short SrcIP[2];	
	
	//192.168.1.87
	SrcIP[0]=0xA8C0;
	SrcIP[1]=0x5701;
		

	for(_i=0;_i<_RX_SIZE_WORD;_i++)
		_rx_buff[_i] = *((unsigned short *)(0xe000+_i));			
		//_rx_buff[_i]=_ioport_get(0xC000+_i);


	if (_rx_buff[6]==0x0608)
	{	
		if ((_rx_buff[19]==SrcIP[0]) && (_rx_buff[20]==SrcIP[1]))
			return 1; //ARP ������ �� ��� IP
	}
		

	if (_rx_buff[6]==0x0008 & (_rx_buff[11] & 0xff00)==0x0100)
		return 3; //ICMP
		
		
	return 0;	
	
}

//test RX buff
static void _RXBF_test(void)
{
unsigned short _i,_j;
unsigned short _count;
unsigned short _res;	

	for(_i=0;_i<0x000c;_i++)
	{
		_count=0xffff;
		_ioport_set(0xC000+_i,0x0000);
		for(_j=0;_j<16;_j++)
		{
			_count = _count & ~(0x0001<<_j);
			_ioport_set(0xC000+_i,_count);
			_res=_ioport_get(0xC000+_i);
			if(_res!=_count)
				_delay();

			_count = _count | (0x0001<<_j);
			_ioport_set(0xC000+_i,_count);
			_res=_ioport_get(0xC000+_i);
			if(_res!=_count)
				_delay();
			
		}
	}
	
	
}


//test TX buff
static void _TXBF_test(void)
{
unsigned short _i,_j;
unsigned short _count;
unsigned short _res;	

	for(_i=0;_i<0x000c;_i++)
	{
		_count=0xffff;
		_ioport_set(0xD000+_i,0x0000);
		for(_j=0;_j<16;_j++)
		{
			_count = _count & ~(0x0001<<_j);
			_ioport_set(0xD000+_i,_count);
			_res=_ioport_get(0xD000+_i);
			if(_res!=_count)
				_delay();

			_count = _count | (0x0001<<_j);
			_ioport_set(0xD000+_i,_count);
			_res=_ioport_get(0xD000+_i);
			if(_res!=_count)
				_delay();
			
		}
	}
	
	
}

//set TX buffer
static void _TXBF_set(void)
{
unsigned short _i;
unsigned short _res;	
	
//dest adr
	_res=0x0;
	while(_res!=0xFFFF)
	{
		_ioport_set(0xD000+0x0,0xFFFF);
		_res=_ioport_get(0xD000+0x0);
	}
	_res=0x0;
	while(_res!=0xFFFF)
	{
		_ioport_set(0xD000+0x01,0xFFFF);
		_res=_ioport_get(0xD000+0x01);
	}
	_res=0x0;
	while(_res!=0xFFFF)
	{
		_ioport_set(0xD000+0x02,0xFFFF);
		_res=_ioport_get(0xD000+0x02);
	}
	
///src adr	
	_res=0x0;
	while(_res!=0xab00)
	{	
		_ioport_set(0xD000+0x03,0xab00);
		_res=_ioport_get(0xD000+0x03);
	}
	_res=0x0;
	while(_res!=0x4567)
	{	
		_ioport_set(0xD000+0x04,0x4567);
		_res=_ioport_get(0xD000+0x04);
	}
	_res=0x0;
	while(_res!=0x0123)
	{	
		_ioport_set(0xD000+0x05,0x0123);
		_res=_ioport_get(0xD000+0x05);
	}
	
//size	
	_res=0x0;
	while(_res!=0x0700)
	{
		_ioport_set(0xD000+0x06,0x0700);
		_res=_ioport_get(0xD000+0x06);
	}
//ind 802.3/LLC
	_res=0x0;
	while(_res!=0xaaaa)
	{
		_ioport_set(0xD000+0x07,0xaaaa);
		_res=_ioport_get(0xD000+0x07);
	}
	_res=0x0;
	while(_res!=0x0003)
	{	
		_ioport_set(0xD000+0x08,0x0003);
		_res=_ioport_get(0xD000+0x08);
	}
//data	
	_res=0x0;
	while(_res!=0x8281)
	{	
		_ioport_set(0xD000+0x09,0x8281);
		_res=_ioport_get(0xD000+0x09);
	}
	_res=0x0;
	while(_res!=0x8483)
	{	
		_ioport_set(0xD000+0x0a,0x8483);
		_res=_ioport_get(0xD000+0x0a);
	}
	_res=0x0;
	while(_res!=0x8685)
	{	
		_ioport_set(0xD000+0x0b,0x8685);
		_res=_ioport_get(0xD000+0x0b);
	}
		
}

//set TX buffer  ��� ARP �����
static void _TXBF_set_ARP(unsigned short *RxP)
{
unsigned short _i,_j;
unsigned short _res;	
unsigned short SrcMAC[3],SrcIP[2];	
	

	SrcMAC[0]=0x8900;
	SrcMAC[1]=0x4567;	
	SrcMAC[2]=0x0123;
	//192.168.1.87
	SrcIP[0]=0xA8C0;
	SrcIP[1]=0x5701;
	_j=0;
	
	//for (i=0;i<6;i++)	*(TxP+i)=*(RxP+i+6);
	for (_i=0;_i<3;_i++)
	{
		_ioport_set(0xD000+_j,RxP[_i+6/2]);
		_j++;
	}
	//for (i=0;i<6;i++)	*(TxP+i+6)=SrcMAC[i];
	for (_i=0;_i<3;_i++)
	{
		_ioport_set(0xD000+_j,SrcMAC[_i]);
		_j++;
	}
	//*(TxP+12)=0x08; *(TxP+13)=0x06;
	_ioport_set(0xD000+_j,0x0608);
	_j++;
	//*(TxP+14)=0x00;		*(TxP+15)=0x01;
	_ioport_set(0xD000+_j,0x0100);
	_j++;
	//*(TxP+16)=0x08;		*(TxP+17)=0x00;
	_ioport_set(0xD000+_j,0x0008);
	_j++;
	//*(TxP+18)=0x06;		*(TxP+19)=0x04;
	_ioport_set(0xD000+_j,0x0406);
	_j++;
	//*(TxP+20)=0x00;		*(TxP+21)=0x02;
	_ioport_set(0xD000+_j,0x0200);
	_j++;
	//for (i=0;i<6;i++) *(TxP+i+22)=SrcMAC[i];
	for (_i=0;_i<3;_i++)
	{
		_ioport_set(0xD000+_j,SrcMAC[_i]);
		_j++;
	}
	//for (i=0;i<4;i++)	*(TxP+i+28)=SrcIP[i];
	for (_i=0;_i<2;_i++)
	{
		_ioport_set(0xD000+_j,SrcIP[_i]);
		_j++;
	}
	//for (i=0;i<6;i++) *(TxP+i+32)=*(RxP+i+22);
	for (_i=0;_i<3;_i++)
	{
		_ioport_set(0xD000+_j,RxP[_i+22/2]);
		_j++;
	}
	//for (i=0;i<4;i++) *(TxP+i+38)=*(RxP+i+28);
	for (_i=0;_i<3;_i++)
	{
		_ioport_set(0xD000+_j,RxP[_i+28/2]);
		_j++;
	}
			
}

//check sum ICMP ver2
unsigned short checksum2(unsigned short *buffer, unsigned short size)
{
unsigned long cksum;
	cksum=0;

	while(size >1) 
	{
		cksum+=*buffer++;
		size -=2;
	}

	if(size ) 
	{
		cksum += *(unsigned char*)buffer;
	}

	cksum = (cksum >> 16) + (cksum & 0xffff);
	cksum += (cksum >>16);

	return (unsigned short)(~cksum);
}

//check sum ICMP
unsigned short checksum(unsigned short * data,unsigned short length)
{	
long value;
unsigned short i;
	value=0;
	for(i=0;i<(length>>1);i++) 
		value+=data[i]; // add
	if((length&1)==1) 
		value+=(data[i]<<8); // compensate of odd amount of datas
	value=(value&65535)+(value>>16); // complements one to one
	
return(~value); // XOR the result
} 


//set TX buffer  ��� ICMP �����
unsigned short _buff1[20];
static void _TXBF_set_ICMP(unsigned short *RxP)
{
unsigned short _i,_j;
unsigned short _res,_res1;	
unsigned short SrcMAC[3],SrcIP[2];	
unsigned short csum;
unsigned long sum,ChkSum;
	

	SrcMAC[0]=0x8900;
	SrcMAC[1]=0x4567;	
	SrcMAC[2]=0x0123;
	//192.168.1.87
	SrcIP[0]=0xA8C0;
	SrcIP[1]=0x5701;
	_j=0;	

	//for (_i=0;_i<74/2;_i++) *(TxP+i)=*(RxP+i);
	for (_i=0;_i<(_ETH_HEADER+_ICMP_REPLY)/2;_i++)
	{
		*((unsigned short *)(0xf000+_j++)) = RxP[_i];		
		
	}
	
	
	//for (i=0;i<6;i++){*(TxP+i)=*(RxP+i+6); *(TxP+i+6)=SrcMAC[i];}
	_j=0;
	for (_i=0;_i<6/2;_i++)
	{
		*((unsigned short *)(0xf000+_j)) = RxP[_i+6/2];		
		//_ioport_set(0xD000+_j,RxP[_i+6/2]);
		*((unsigned short *)(0xf000+_j+6/2)) = SrcMAC[_i];		
		//_ioport_set(0xD000+_j+6/2,SrcMAC[_i]);
		
		_j++;
	}
	
	//*(TxP+24)=0x00;		*(TxP+25)=0x00;
	_ioport_set(0xD000+24/2,0x0000);
	//*(TxP+34)=0x00;
	_res1=_ioport_get(0xD000+34/2);
	_ioport_set(0xD000+34/2,_res1 & 0xff00);
	
	//*(TxP+36)=0x00;		*(TxP+37)=0x00;
	_ioport_set(0xD000+36/2,0x0000);
	
	//for (i=0;i<4;i++)	{*(TxP+i+30)=*(RxP+i+26); *(TxP+i+26)=SrcIP[i];	}
	for (_i=0;_i<4/2;_i++)
	{
		_ioport_set(0xD000+30/2+_i,RxP[_i+26/2]);
		
		_ioport_set(0xD000+_i+26/2,SrcIP[_i]);
		
	}
	
	_ioport_set(0xD000+16/2,(_ICMP_REPLY+28)<<8); //ICMP size
	
	sum=0;
	//for (i=0;i<20;i++) 
	//{ sum=sum+256*(*(TxP+34+(i<<1)))+*(TxP+34+(i<<1)+1); }
	for (_i=0;_i<(6+28/2);_i++)
	{
		
		_buff1[_i] = *((unsigned short *)(0xf000+_i+34/2));		
		
		//_buff1[_i]=_ioport_get(0xD000+_i+34/2);
		
		//sum=sum+256*(_res1);
	}
	
	csum=checksum2(_buff1,12+28);
	//*(TxP+36)=(unsigned char)(csum>>8);		
	//*(TxP+37)=(unsigned char)(csum&0xFF);
	_ioport_set(0xD000+36/2,csum);
	
	
	//for (i=0;i<10;i++) 
	//{ sum=sum+((*(TxP+14+(i<<1)))<<8)+*(TxP+14+(i<<1)+1); }
	for (_i=0;_i<20/2;_i++) 
	{ 
		_buff1[_i] = *((unsigned short *)(0xf000+14/2+_i));		
		//_buff1[_i]=_ioport_get(0xD000+14/2+_i);
		
		//sum=sum+((_res1<<8)&0xff00)+((_res1>>8)&0x00ff); 
	}
	//csum=checksum(_buff1,10);
	csum=checksum2(_buff1,20);
	//*(TxP+24)=(unsigned char)(csum>>8);		
	//*(TxP+25)=(unsigned char)(csum&0xFF);
	_ioport_set(0xD000+24/2,csum);
	
	
	
			
}


unsigned short _tx_buff[100];
static void _TXBF_get(void)
{
unsigned short _i;	

	for(_i=0;_i<100;_i++)
		_tx_buff[_i]=_ioport_get(0xD000+_i);
	

	
}



//_op->0 bit set/unset ���������/��������� RX_RST
//_op->1 bit set/unset ���������/��������� HALFD_EN
//_op->2 bit set/unset CTRL_FRAME_EN
//_op->3 bit set/unset SHRT_FRAME_EN
//_op->4 bit set/unset BCA_EN
//_op->5 bit set/unset LB_EN
//_op->6 bit set/unset SCAN_EN
//_op->7 bit set/unset TX_RST
static void _MAC_CTRL_opt(unsigned short _op)
{
	if(_op&(0x0001<<0))
	{
		//��������� RX_RST
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) | (0x0001<<14));
		//portDFC0 |= (0x0001<<14);
	}
	else
	{
		//��������� RX_RST
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) & ~(0x0001<<14));
		//portDFC0 &= ~(0x0001<<14);
	}


	if(_op&(0x0001<<7))
	{
		//��������� TX_RST
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) | (0x0001<<15));
		//portDFC0 |= (0x0001<<15);
	}
	else
	{
		//��������� TX_RST
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) & ~(0x0001<<15));
		//portDFC0 &= ~(0x0001<<15);
	}


	if(_op&(0x0001<<6))
	{
		//��������� SCAN_EN
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) | (0x0001<<12));
		//portDFC0 |= (0x0001<<12);
	}
	else
	{
		//��������� SCAN_EN
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) & ~(0x0001<<12));
		//portDFC0 &= ~(0x0001<<12);
	}

	if(_op&(0x0001<<5))
	{
		//��������� LB_EN
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) | (0x0001<<0));
		//portDFC0 |= (0x0001<<0);
	}
	else
	{
		//��������� LB_EN
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) & ~(0x0001<<0));
		//portDFC0 &= ~(0x0001<<0);
	}


	if(_op&(0x0001<<1))
	{
		//��������� HALFD
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) | (0x0001<<2));
		//portDFC0 |= (0x0001<<2);
	}
	else
	{
		//��������� HALFD
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) & ~(0x0001<<2));
		//portDFC0 &= ~(0x0001<<2);
	}


	if(_op&(0x0001<<2))
	{
		//��������� CTRL_FRAME_EN
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) | (0x0001<<7));
		//portDFC0 |= (0x0001<<7);
	}
	else
	{
		//��������� CTRL_FRAME_EN
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) & ~(0x0001<<7));
		//portDFC0 &= ~(0x0001<<7);
	}

	if(_op&(0x0001<<3))
	{
		//��������� SHRT_FRAME_EN
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) | (0x0001<<5));
		//portDFC0 |= (0x0001<<5);
	}
	else
	{
		//��������� SHRT_FRAME_EN
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) & ~(0x0001<<5));
		//portDFC0 &= ~(0x0001<<5);
	}

	if(_op&(0x0001<<4))
	{
		//��������� BCA_EN
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) | (0x0001<<9));
		//portDFC0 |= (0x0001<<9);
	}
	else
	{
		//��������� BCA_EN
		_ioport_set(0xDFC0,_ioport_get(0xDFC0) & ~(0x0001<<9));
		//portDFC0 &= ~(0x0001<<9);
	}
	
}


static unsigned short _MAC_CTRL_opt_get()
{
	return _ioport_get(0xDFC0);//portDFC0;
}


static void _init_eth()
{
}


static void _toogle_()
{
unsigned short _var;

	_var=0x0;
	while(1)
	{
			switch(_var & 0x0001)
			{
				case 0:
					asm("  RSBX XF ");
				break;
				
				case 1:
					asm("  SSBX XF ");
				break;
			};		
			
		_var++;	
	}
				
				
}

unsigned short _res3;
void _test_eth(void)
{
unsigned short _res;
unsigned short _par;
unsigned short _mac[3];
unsigned short _op;
unsigned short _res_OK;
unsigned short _res_ALL;
unsigned short _res_OVR;
unsigned short _res_LOS;
unsigned short _res_GCRL;
unsigned short _res_MAC;
unsigned short _res_PHY;
unsigned short _pack_type;

unsigned short *_p;
unsigned short _var;


#if 1
		_res=0x0;
		_res=_MAC_CTRL_opt_get();
		
#endif

		_op=0x0;
		_op |= (0x0001<<0); //to toogle global RST
		_GCTRL_opt(_op);
		_op=0x0;
		//_op |= (0x0001<<1); //ASYNC
		_GCTRL_opt(_op);
		_res=0x0;
		
		//_delay();

		_TXBD_set(1); //������� descr

		_ADR_MAC[0]=0x8900;
		_ADR_MAC[1]=0x4567;
		_ADR_MAC[2]=0x0123;
		_set_mac(_ADR_MAC);
		_get_mac(_mac); //��� ��������
//�������� �����/�������� ��������
		_op &= ~(0x0003);
		_PHY_opt(_op);
		_op=_PHY_opt_get();
		_op=0x0;
//�������� �����/��������   RESET off
		_op |= (0x0001<<1);
		_op |= (0x0001<<0);
		_op &= ~(0x0001<<2);
//HALFD unset		
		_op &= ~(0x0001<<3);
//DLB unset		
		//_op |= (0x0001<<4);
//LB set		
		//_op |= (0x0001<<5);		
		_PHY_opt(_op);
		//_delay();
		//_PHY_LINK_opt();
		_res=_PHY_opt_get();
		//_res=_GCTRL_opt_get();
		_op=0x0;
//��������� RX_RST		
		_op |= (0x0001<<0);
//��������� TX_RST		
		_op |= (0x0001<<7);		
//��������� HALFD_DIS		
		_op &= ~(0x0001<<1);
//��������� CTRL_FRAME_EN		
		_op |= (0x0001<<2);
//��������� SHRT_FRAME_EN		
		_op |= (0x0001<<3);
//set BCA_EN(broadcast �����)		
		_op |= (0x0001<<4);
//LB_EN unset							
		//_op |= (0x0001<<5);
//SCAN_EN set							
		//_op |= (0x0001<<6);																		
		_MAC_CTRL_opt(_op);
		_res=_MAC_CTRL_opt_get();
		//_delay();
		//_res=_PHY_STAT_opt_get();
		
#if 1
//recieve		
		_RXBD_set();	
		
		while(1)
		{
#if 1		
			_res=_ioport_get(0xC800);
			
			//_res_OK=_STAT_RX_OK();
			//_res_ALL=_STAT_RX_all();
			//_res_OVR=_STAT_RX_OVR();
			//_res_LOS=_STAT_RX_LOS();
						
			if(!(_res & 0x8000))
			{
				
				_pack_type=_RXBF_get_type(); //������� ��� ������
				if(_pack_type==0x01)
				{
					_RXBD_set();
					//��� �� �������� ARP ������
					_TXBF_set_ARP(_rx_buff); //�������� � ����� IP � MAC
					//_toogle_();
					_TXBD_set(0); //��������														
					continue;
				}
#if 1				
				if(_pack_type==0x03)
				{
					_RXBD_set();
					
					//��� �� �������� ICMP ������
					
						
					_TXBF_set_ICMP(_rx_buff); //ICMP �����
					_TXBD_set(0); //��������				
					continue;											
					
				}
#endif				
				_RXBD_set();
				
			}
			
#endif			

		}
#endif			
								
		

		_par=_ioport_get(0xDFC0); //MAC_CTRL reg ����

	_delay();		
}


