#include "types.h"
void TEST(void);
void TEST2(void);
void COMPINIT();
void PADINIT();
void ADCTEST();
void TEMP_TEST();
void EXTRAM_TEST(void);