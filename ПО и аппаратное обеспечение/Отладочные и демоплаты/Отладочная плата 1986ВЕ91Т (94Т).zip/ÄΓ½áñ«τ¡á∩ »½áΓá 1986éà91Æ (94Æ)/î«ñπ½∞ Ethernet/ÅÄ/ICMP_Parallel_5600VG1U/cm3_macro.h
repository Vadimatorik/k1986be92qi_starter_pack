#ifndef __CM3_MACRO_H
#define __CM3_MACRO_H

typedef volatile unsigned long   __io_reg;

#endif /* __CM3_MACRO_H */
