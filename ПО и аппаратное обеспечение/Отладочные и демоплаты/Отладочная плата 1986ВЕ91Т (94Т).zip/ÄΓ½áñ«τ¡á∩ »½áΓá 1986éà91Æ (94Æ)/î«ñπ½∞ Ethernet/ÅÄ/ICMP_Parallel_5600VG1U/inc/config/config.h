
#ifndef __CONFIG_H
#define __CONFIG_H

#define TMS_CODE_SIZE 	0x3F7F
#define TMS_VECTOR_SIZE	0x0080
#define	TMS_DATA_SIZE 0x3700

#define CODE_ADDR_DSP 0x4000
#define CODE_ADDR_ARM CODE_ADDR_DSP*2

#define VECTOR_ADDR_DSP 0xFF80
#define VECTOR_ADDR_ARM VECTOR_ADDR_DSP*2

#define	DATA_ADDR_DSP 0x0A80
#define	DATA_ADDR_ARM DATA_ADDR_DSP*2

#define NUM_OF_SAMPLES	0x4000

//���������� 16-������ ���� � ��� DSP
#define DSP_RAM_SIZE	0xFF80


void ClockConfig(void);
void PortConfig(void);
void UART1Config(void);

#endif	//__CONFIG_H

