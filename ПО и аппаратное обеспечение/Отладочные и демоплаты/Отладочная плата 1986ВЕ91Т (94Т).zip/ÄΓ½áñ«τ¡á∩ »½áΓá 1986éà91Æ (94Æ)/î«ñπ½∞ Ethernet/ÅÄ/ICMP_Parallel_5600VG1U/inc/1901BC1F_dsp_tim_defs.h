/**
  ******************************************************************************
  * @file    1901BC1F_dsp_tim_defs.h
  * @author  Phyton Application Team
  * @version V1.0.0
  * @date    14/01/2011
  * @brief   This file contains all the Special Function Registers definitions
  *          for the DSP_TIM peripheral unit used in the Milandr 1901BC1F
  *          microcontrollers.
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, PHYTON SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2010 Phyton</center></h2>
  ******************************************************************************
  * FILE 1901BC1F_dsp_tim_defs.h
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __1901BC1F_DSP_TIM_DEFS_H
#define __1901BC1F_DSP_TIM_DEFS_H

/** @addtogroup __CMSIS CMSIS
  * @{
  */

/** @addtogroup __1901BC1F_Peripheral_Units 1901BC1F Peripheral Units
  * @{
  */

/** @defgroup Periph_DSP_TIM DSP_TIM
  * @{
  */

/** @defgroup Periph_DSP_TIM_Data_Structures Data Structures
  * @{
  */

/** @defgroup Periph_DSP_TIM_TypeDef DSP_TIM_TypeDef
  * @{
  */

typedef struct
{
  __IO uint32_t TIM_PRD;
  __IO uint32_t TCR;
}DSP_TIM_TypeDef;

/** @} */ /* End of group Periph_DSP_TIM_TypeDef */

/** @} */ /* End of group Periph_DSP_TIM_Data_Structures */

/** @defgroup Periph_DSP_TIM_Defines Defines
  * @{
  */

/** @defgroup Periph_DSP_TIM_DSP_TIM_TCR_Bits DSP_TIM_TCR
  * @{
  */

#define DSP_TIM_TCR_TDDR0_Pos                   0
#define DSP_TIM_TCR_TDDR0                       ((uint32_t)0x00000001)

#define DSP_TIM_TCR_TDDR1_Pos                   1
#define DSP_TIM_TCR_TDDR1                       ((uint32_t)0x00000002)

#define DSP_TIM_TCR_TDDR2_Pos                   2
#define DSP_TIM_TCR_TDDR2                       ((uint32_t)0x00000004)

#define DSP_TIM_TCR_TDDR3_Pos                   3
#define DSP_TIM_TCR_TDDR3                       ((uint32_t)0x00000008)

#define DSP_TIM_TCR_TSS_Pos                     4
#define DSP_TIM_TCR_TSS                         ((uint32_t)0x00000010)

#define DSP_TIM_TCR_TRB_Pos                     5
#define DSP_TIM_TCR_TRB                         ((uint32_t)0x00000020)

#define DSP_TIM_TCR_PSC0_Pos                    6
#define DSP_TIM_TCR_PSC0                        ((uint32_t)0x00000040)

#define DSP_TIM_TCR_PSC1_Pos                    7
#define DSP_TIM_TCR_PSC1                        ((uint32_t)0x00000080)

#define DSP_TIM_TCR_PSC2_Pos                    8
#define DSP_TIM_TCR_PSC2                        ((uint32_t)0x00000100)

#define DSP_TIM_TCR_PSC3_Pos                    9
#define DSP_TIM_TCR_PSC3                        ((uint32_t)0x00000200)

#define DSP_TIM_TCR_FREE_Pos                    10
#define DSP_TIM_TCR_FREE                        ((uint32_t)0x00000400)

#define DSP_TIM_TCR_SOFT_Pos                    11
#define DSP_TIM_TCR_SOFT                        ((uint32_t)0x00000800)


/** @} */ /* End of group Periph_DSP_TIM_DSP_TIM_TCR_Bits */

/** @} */ /* End of group Periph_DSP_TIM_Defines */

/** @} */ /* End of group Periph_DSP_TIM */

/** @} */ /* End of group __1901BC1F_Peripheral_Units */

/** @} */ /* End of group __CMSIS */

#endif /* __1901BC1F_DSP_TIM_DEFS_H */

/******************* (C) COPYRIGHT 2010 Phyton *********************************
*
* END OF FILE 1901BC1F_dsp_tim_defs.h */
