
#ifndef __UART_H
#define __UART_H

uint32_t UARTSendData(UART_TypeDef*,uint8_t*, uint32_t);

#endif	//__UART_H

