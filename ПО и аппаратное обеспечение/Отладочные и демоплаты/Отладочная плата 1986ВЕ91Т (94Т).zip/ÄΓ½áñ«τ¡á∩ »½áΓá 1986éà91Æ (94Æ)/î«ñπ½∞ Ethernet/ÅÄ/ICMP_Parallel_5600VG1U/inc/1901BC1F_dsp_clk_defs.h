/**
  ******************************************************************************
  * @file    1901BC1F_dsp_clk_defs.h
  * @author  Phyton Application Team
  * @version V1.0.0
  * @date    14/01/2011
  * @brief   This file contains all the Special Function Registers definitions
  *          for the DSP_CLK peripheral unit used in the Milandr 1901BC1F
  *          microcontrollers.
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, PHYTON SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2010 Phyton</center></h2>
  ******************************************************************************
  * FILE 1901BC1F_dsp_clk_defs.h
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __1901BC1F_DSP_CLK_DEFS_H
#define __1901BC1F_DSP_CLK_DEFS_H

/** @addtogroup __CMSIS CMSIS
  * @{
  */

/** @addtogroup __1901BC1F_Peripheral_Units 1901BC1F Peripheral Units
  * @{
  */

/** @defgroup Periph_DSP_CLK DSP_CLK
  * @{
  */

/** @defgroup Periph_DSP_CLK_Data_Structures Data Structures
  * @{
  */

/** @defgroup Periph_DSP_CLK_TypeDef DSP_CLK_TypeDef
  * @{
  */

typedef struct
{
  __IO uint32_t CLKMD;
}DSP_CLK_TypeDef;

/** @} */ /* End of group Periph_DSP_CLK_TypeDef */

/** @} */ /* End of group Periph_DSP_CLK_Data_Structures */

/** @defgroup Periph_DSP_CLK_Defines Defines
  * @{
  */

/** @defgroup Periph_DSP_CLK_DSP_CLK_CLKMD_Bits DSP_CLK_CLKMD
  * @{
  */

#define DSP_CLK_CLKMD_CRP_Pos                   0
#define DSP_CLK_CLKMD_CRP                       ((uint32_t)0x00000001)

#define DSP_CLK_CLKMD_CDC_Pos                   1
#define DSP_CLK_CLKMD_CDC                       ((uint32_t)0x00000002)

#define DSP_CLK_CLKMD_TMR_Pos                   2
#define DSP_CLK_CLKMD_TMR                       ((uint32_t)0x00000004)

#define DSP_CLK_CLKMD_DMA_Pos                   3
#define DSP_CLK_CLKMD_DMA                       ((uint32_t)0x00000008)

#define DSP_CLK_CLKMD_MC3_Pos                   4
#define DSP_CLK_CLKMD_MC3                       ((uint32_t)0x00000010)

#define DSP_CLK_CLKMD_PC3_Pos                   5
#define DSP_CLK_CLKMD_PC3                       ((uint32_t)0x00000020)

#define DSP_CLK_CLKMD_MC2_Pos                   6
#define DSP_CLK_CLKMD_MC2                       ((uint32_t)0x00000040)

#define DSP_CLK_CLKMD_PC2_Pos                   7
#define DSP_CLK_CLKMD_PC2                       ((uint32_t)0x00000080)

#define DSP_CLK_CLKMD_MC1_Pos                   8
#define DSP_CLK_CLKMD_MC1                       ((uint32_t)0x00000100)

#define DSP_CLK_CLKMD_PC1_Pos                   9
#define DSP_CLK_CLKMD_PC1                       ((uint32_t)0x00000200)

#define DSP_CLK_CLKMD_CDM_Pos                   10
#define DSP_CLK_CLKMD_CDM                       ((uint32_t)0x00000400)

#define DSP_CLK_CLKMD_CPM_Pos                   11
#define DSP_CLK_CLKMD_CPM                       ((uint32_t)0x00000800)

#define DSP_CLK_CLKMD_CPU_Pos                   12
#define DSP_CLK_CLKMD_CPU                       ((uint32_t)0x00001000)


/** @} */ /* End of group Periph_DSP_CLK_DSP_CLK_CLKMD_Bits */

/** @} */ /* End of group Periph_DSP_CLK_Defines */

/** @} */ /* End of group Periph_DSP_CLK */

/** @} */ /* End of group __1901BC1F_Peripheral_Units */

/** @} */ /* End of group __CMSIS */

#endif /* __1901BC1F_DSP_CLK_DEFS_H */

/******************* (C) COPYRIGHT 2010 Phyton *********************************
*
* END OF FILE 1901BC1F_dsp_clk_defs.h */
