/**
  ******************************************************************************
  * @file    1901BC1F.h
  * @author  Phyton Application Team
  * @version V1.0.0
  * @date    14/01/2011
  * @brief   This file contains all the Special Function Registers definitions
  *          for the Milandr 1901BC1F microcontroller.
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, PHYTON SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2010 Phyton</center></h2>
  ******************************************************************************
  * FILE 1901BC1F.h
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __1901BC1F_H
#define __1901BC1F_H

/** @addtogroup __CMSIS CMSIS
  * @{
  */

/** @defgroup __1901BC1F 1901BC1F
  * @{
  */

/** @defgroup __Exported_types Exported types
  * @{
  */

/**
  * @brief 1901BC1F Interrupt Number Definition
  */

typedef enum IRQn
{
/******  Cortex-M3 Processor Exceptions Numbers ***************************************************/
  NonMaskableInt_IRQn         = -14,    /*!< 2 Non Maskable Interrupt                             */
  HardFault_IRQn              = -13,    /*!< 3 Cortex-M3 Hard Fault Interrupt                     */
  MemoryManagement_IRQn       = -12,    /*!< 4 Cortex-M3 Memory Management Interrupt              */
  BusFault_IRQn               = -11,    /*!< 5 Cortex-M3 Bus Fault Interrupt                      */
  UsageFault_IRQn             = -10,    /*!< 6 Cortex-M3 Usage Fault Interrupt                    */
  SVCall_IRQn                 = -5,     /*!< 11 Cortex-M3 SV Call Interrupt                       */
  PendSV_IRQn                 = -2,     /*!< 14 Cortex-M3 Pend SV Interrupt                       */
  SysTick_IRQn                = -1,     /*!< 15 Cortex-M3 System Tick Interrupt                   */

/****** 1901BC1F specific Interrupt Numbers *******************************************************/
  SSP3_IRQn                   = 0,      /*!< SPI3 Interrupt                                       */
  SSP4_IRQn                   = 1,      /*!< SPI4 Interrupt                                       */
  USB_IRQn                    = 2,      /*!< USB Host Interrupt                                   */
  DSP_BSP1_IRQn               = 3,      /*!< DSP_BSP1 Interrupt                                   */
  DSP_BSP2_IRQn               = 4,      /*!< DSP_BSP2 Interrupt                                   */
  DMA_IRQn                    = 5,      /*!< DMA Interrupt                                        */
  UART1_IRQn                  = 6,      /*!< UART1 Interrupt                                      */
  UART2_IRQn                  = 7,      /*!< UART2 Interrupt                                      */
  SSP1_IRQn                   = 8,      /*!< SSP1 Interrupt                                       */
  DSP_BSP3_IRQn               = 9,      /*!< DSP_BSP3 Interrupt                                   */
  I2C_IRQn                    = 10,     /*!< I2C Interrupt                                        */
  Power_IRQn                  = 11,     /*!< Power Detect Interrupt                               */
  WWDG_IRQn                   = 12,     /*!< Window Watchdog Interrupt                            */
  DSP_DMA_IRQn				  = 13,		/*!< DSP DMA Interrupt									  */		
  Timer1_IRQn                 = 14,     /*!< Timer1 Interrupt                                     */
  Timer2_IRQn                 = 15,     /*!< Timer2 Interrupt                                     */
  Timer3_IRQn                 = 16,     /*!< Timer3 Interrupt                                     */
  ADC_IRQn                    = 17,     /*!< ADC Interrupt                                        */
  COMPARATOR_IRQn             = 19,     /*!< COMPARATOR Interrupt                                 */
  SSP2_IRQn                   = 20,     /*!< SSP2 Interrupt                                       */
  DSP_ACD_IRQn                = 21,     /*!< DSP Audio Codec Interrupt                            */
  DSP_CRPT_IRQn               = 22,     /*!< DSP Crypto Unit Interrupt                            */
  DSP_TIM_IRQn                = 23,     /*!< DSP Timer Interrupt                                  */
  DSP_IRQ_IRQn                = 24,     /*!< DSP Interrupts                                       */
  DSP_STATE_IRQn              = 25,     /*!< DSP IDLE Interrupt                                   */
  UART3_IRQn                  = 26,     /*!< UART3 Interrupt                                      */
  BACKUP_IRQn                 = 27,     /*!< BACKUP Interrupt                                     */
  EXT_INT1_IRQn               = 28,     /*!< EXT_INT1 Interrupt                                   */
  EXT_INT2_IRQn               = 29,     /*!< EXT_INT2 Interrupt                                   */
  EXT_INT3_IRQn               = 30,     /*!< EXT_INT3 Interrupt                                   */
  EXT_INT4_IRQn               = 31      /*!< EXT_INT4 Interrupt                                   */
}IRQn_Type;

/* Includes ------------------------------------------------------------------*/
#include "core_cm3.h"

#include "1901BC1F_spi_defs.h"
#include "1901BC1F_usb_defs.h"
#include "1901BC1F_eeprom_defs.h"
#include "1901BC1F_rst_clk_defs.h"
#include "1901BC1F_dma_defs.h"
#include "1901BC1F_uart_defs.h"
#include "1901BC1F_sdio_defs.h"
#include "1901BC1F_i2c_defs.h"
#include "1901BC1F_power_defs.h"
#include "1901BC1F_wwdg_defs.h"
#include "1901BC1F_iwdg_defs.h"
#include "1901BC1F_timer_defs.h"
#include "1901BC1F_adc_defs.h"
#include "1901BC1F_dac_defs.h"
#include "1901BC1F_comp_defs.h"
#include "1901BC1F_port_defs.h"
#include "1901BC1F_bkp_defs.h"
#include "1901BC1F_ext_bus_cntrl_defs.h"
#include "1901BC1F_dsp_bsp_defs.h"
#include "1901BC1F_dsp_tim_defs.h"
#include "1901BC1F_dsp_irq_defs.h"
#include "1901BC1F_dsp_crpt_defs.h"
#include "1901BC1F_dsp_acd_defs.h"
#include "1901BC1F_dsp_clk_defs.h"
#include "1901BC1F_dsp_dma_defs.h"

typedef enum {RESET = 0, SET = !RESET} FlagStatus, ITStatus;

typedef enum {DISABLE = 0, ENABLE = !DISABLE} FunctionalState;
#define IS_FUNCTIONAL_STATE(STATE) (((STATE) == DISABLE) || ((STATE) == ENABLE))

typedef enum {ERROR = 0, SUCCESS = !ERROR} ErrorStatus;

/** @} */ /* End of group __Exported_types */


/** @defgroup __Peripheral_Memory_Map Peripheral Memory Map
  * @{
  */

#define SPI3_BASE           0x40000000
#define SPI4_BASE           0x40008000
#define USB_BASE            0x40010000
#define EEPROM_BASE         0x40018000
#define RST_CLK_BASE        0x40020000
#define DMA_BASE            0x40028000
#define UART1_BASE          0x40030000
#define UART2_BASE          0x40038000
#define SPI1_BASE           0x40040000
#define SDIO_BASE           0x40048000
#define I2C_BASE            0x40050000
#define POWER_BASE          0x40058000
#define WWDG_BASE           0x40060000
#define IWDG_BASE           0x40068000
#define TIMER1_BASE         0x40070000
#define TIMER2_BASE         0x40078000
#define TIMER3_BASE         0x40080000
#define ADC_BASE            0x40088000
#define DAC_BASE            0x40090000
#define COMP_BASE           0x40098000
#define SPI2_BASE           0x400A0000
#define PORTA_BASE          0x400A8000
#define PORTB_BASE          0x400B0000
#define PORTC_BASE          0x400B8000
#define PORTD_BASE          0x400C0000
#define PORTE_BASE          0x400C8000
#define UART3_BASE          0x400D0000
#define BKP_BASE            0x400D8000
#define PORTF_BASE          0x400E8000
#define EXT_BUS_CNTRL_BASE  0x400F0000
#define DSP_BSP1_BASE       0x30000040
#define DSP_BSP2_BASE       0x30000050
#define DSP_BSP3_BASE       0x30000060
#define DSP_TIM_BASE        0x30000070
#define DSP_IRQ_BASE        0x30000078
#define DSP_CRPT_BASE       0x30000080
#define DSP_ACD_BASE        0x300000A0
#define DSP_CLK_BASE        0x300000BC
#define DSP_DMA_BASE        0x300000C0

/** @} */ /* End of group __Peripheral_Memory_Map */

/** @defgroup __Peripheral_declaration Peripheral declaration
  * @{
  */

#define SPI3                ((SPI_TypeDef*)     SPI3_BASE)
#define SPI4                ((SPI_TypeDef*)     SPI4_BASE)
#define USB                 ((USB_TypeDef*)     USB_BASE)
#define EEPROM              ((EEPROM_TypeDef*)  EEPROM_BASE)
#define RST_CLK             ((RST_CLK_TypeDef*) RST_CLK_BASE)
#define DMA                 ((DMA_TypeDef*)     DMA_BASE)
#define UART1               ((UART_TypeDef*)    UART1_BASE)
#define UART2               ((UART_TypeDef*)    UART2_BASE)
#define SPI1                ((SPI_TypeDef*)     SPI1_BASE)
#define SDIO                ((SDIO_TypeDef*)    SDIO_BASE)
#define I2C                 ((I2C_TypeDef*)     I2C_BASE)
#define POWER               ((POWER_TypeDef*)   POWER_BASE)
#define WWDG                ((WWDG_TypeDef*)    WWDG_BASE)
#define IWDG                ((IWDG_TypeDef*)    IWDG_BASE)
#define TIMER1              ((TIMER_TypeDef*)   TIMER1_BASE)
#define TIMER2              ((TIMER_TypeDef*)   TIMER2_BASE)
#define TIMER3              ((TIMER_TypeDef*)   TIMER3_BASE)
#define ADC                 ((ADC_TypeDef*)     ADC_BASE)
#define DAC                 ((DAC_TypeDef*)     DAC_BASE)
#define COMP                ((COMP_TypeDef*)    COMP_BASE)
#define SPI2                ((SPI_TypeDef*)     SPI2_BASE)
#define PORTA               ((PORT_TypeDef*)    PORTA_BASE)
#define PORTB               ((PORT_TypeDef*)    PORTB_BASE)
#define PORTC               ((PORT_TypeDef*)    PORTC_BASE)
#define PORTD               ((PORT_TypeDef*)    PORTD_BASE)
#define PORTE               ((PORT_TypeDef*)    PORTE_BASE)
#define UART3               ((UART_TypeDef*)    UART3_BASE)
#define BKP                 ((BKP_TypeDef*)     BKP_BASE)
#define PORTF               ((PORT_TypeDef*)    PORTF_BASE)
#define EXT_BUS_CNTRL       ((EXT_BUS_CNTRL_TypeDef*)EXT_BUS_CNTRL_BASE)
#define DSP_BSP1            ((DSP_BSP_TypeDef*) DSP_BSP1_BASE)
#define DSP_BSP2            ((DSP_BSP_TypeDef*) DSP_BSP2_BASE)
#define DSP_BSP3            ((DSP_BSP_TypeDef*) DSP_BSP3_BASE)
#define DSP_TIM             ((DSP_TIM_TypeDef*) DSP_TIM_BASE)
#define DSP_IRQ             ((DSP_IRQ_TypeDef*) DSP_IRQ_BASE)
#define DSP_CRPT            ((DSP_CRPT_TypeDef*)DSP_CRPT_BASE)
#define DSP_ACD             ((DSP_ACD_TypeDef*) DSP_ACD_BASE)
#define DSP_CLK             ((DSP_CLK_TypeDef*) DSP_CLK_BASE)
#define DSP_DMA             ((DSP_DMA_TypeDef*) DSP_DMA_BASE)

/** @} */ /* End of group __Peripheral_declaration */

/** @} */ /* End of group __1901BC1F */

/** @} */ /* End of group __CMSIS */

#endif /* __1901BC1F_H */

/******************* (C) COPYRIGHT 2010 Phyton *********************************
*
* END OF FILE 1901BC1F.h */
