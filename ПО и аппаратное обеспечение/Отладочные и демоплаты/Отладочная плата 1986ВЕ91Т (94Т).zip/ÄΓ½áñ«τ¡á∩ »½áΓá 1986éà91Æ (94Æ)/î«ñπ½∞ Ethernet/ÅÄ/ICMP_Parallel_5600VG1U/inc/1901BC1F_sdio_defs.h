/**
  ******************************************************************************
  * @file    1901BC1F_sdio_defs.h
  * @author  Phyton Application Team
  * @version V1.0.0
  * @date    14/01/2011
  * @brief   This file contains all the Special Function Registers definitions
  *          for the SDIO peripheral unit used in the Milandr 1901BC1F
  *          microcontrollers.
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, PHYTON SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2010 Phyton</center></h2>
  ******************************************************************************
  * FILE 1901BC1F_sdio_defs.h
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __1901BC1F_SDIO_DEFS_H
#define __1901BC1F_SDIO_DEFS_H

/** @addtogroup __CMSIS CMSIS
  * @{
  */

/** @addtogroup __1901BC1F_Peripheral_Units 1901BC1F Peripheral Units
  * @{
  */

/** @defgroup Periph_SDIO SDIO
  * @{
  */

/** @defgroup Periph_SDIO_Data_Structures Data Structures
  * @{
  */

/** @defgroup Periph_SDIO_TypeDef SDIO_TypeDef
  * @{
  */

typedef struct
{
  __IO uint32_t SD_CR;
  __IO uint32_t SD_SR;
  __IO uint32_t SD_CMDDR;
  __IO uint32_t SD_DATDR;
  __IO uint32_t SD_CMDCRC;
  __IO uint32_t SD_DATA0CRC;
  __IO uint32_t SD_DATA1CRC;
  __IO uint32_t SD_DATA2CRC;
  __IO uint32_t SD_DATA3CRC;
  __IO uint32_t SD_CMDtransfer;
  __IO uint32_t SD_DATtransfer;
}SDIO_TypeDef;

/** @} */ /* End of group Periph_SDIO_TypeDef */

/** @} */ /* End of group Periph_SDIO_Data_Structures */

/** @defgroup Periph_SDIO_Defines Defines
  * @{
  */

/** @defgroup Periph_SDIO_SDIO_SD_CR_Bits SDIO_SD_CR
  * @{
  */

#define SDIO_SD_CR_DIRCMD_Pos                   0
#define SDIO_SD_CR_DIRCMD                       ((uint32_t)0x00000001)

#define SDIO_SD_CR_DIRDAT_Pos                   1
#define SDIO_SD_CR_DIRDAT                       ((uint32_t)0x00000002)

#define SDIO_SD_CR_WORK_Pos                     2
#define SDIO_SD_CR_WORK                         ((uint32_t)0x00000004)

#define SDIO_SD_CR_SBITCMD_Pos                  3
#define SDIO_SD_CR_SBITCMD                      ((uint32_t)0x00000008)

#define SDIO_SD_CR_SBITDAT_Pos                  4
#define SDIO_SD_CR_SBITDAT                      ((uint32_t)0x00000010)

#define SDIO_SD_CR_BR0_Pos                      5
#define SDIO_SD_CR_BR0                          ((uint32_t)0x00000020)

#define SDIO_SD_CR_BR1_Pos                      6
#define SDIO_SD_CR_BR1                          ((uint32_t)0x00000040)

#define SDIO_SD_CR_BR2_Pos                      7
#define SDIO_SD_CR_BR2                          ((uint32_t)0x00000080)

#define SDIO_SD_CR_CRCEN_DAT_Pos                8
#define SDIO_SD_CR_CRCEN_DAT                    ((uint32_t)0x00000100)

#define SDIO_SD_CR_CRCEN_CMD_Pos                9
#define SDIO_SD_CR_CRCEN_CMD                    ((uint32_t)0x00000200)

#define SDIO_SD_CR_TXEIE_DAT_Pos                10
#define SDIO_SD_CR_TXEIE_DAT                    ((uint32_t)0x00000400)

#define SDIO_SD_CR_RXNEIE_DAT_Pos               11
#define SDIO_SD_CR_RXNEIE_DAT                   ((uint32_t)0x00000800)

#define SDIO_SD_CR_RXFIE_DAT_Pos                12
#define SDIO_SD_CR_RXFIE_DAT                    ((uint32_t)0x00001000)

#define SDIO_SD_CR_TXEIE_CMD_Pos                13
#define SDIO_SD_CR_TXEIE_CMD                    ((uint32_t)0x00002000)

#define SDIO_SD_CR_RXNEIE_CMD_Pos               14
#define SDIO_SD_CR_RXNEIE_CMD                   ((uint32_t)0x00004000)

#define SDIO_SD_CR_RXFIE_CMD_Pos                15
#define SDIO_SD_CR_RXFIE_CMD                    ((uint32_t)0x00008000)

#define SDIO_SD_CR_WIDTHDAT_Pos                 16
#define SDIO_SD_CR_WIDTHDAT                     ((uint32_t)0x00010000)

#define SDIO_SD_CR_WRITECMD_Pos                 17
#define SDIO_SD_CR_WRITECMD                     ((uint32_t)0x00020000)

#define SDIO_SD_CR_ENDBUSY_Pos                  18
#define SDIO_SD_CR_ENDBUSY                      ((uint32_t)0x00040000)

#define SDIO_SD_CR_WORK2_Pos                    19
#define SDIO_SD_CR_WORK2                        ((uint32_t)0x00080000)

#define SDIO_SD_CR_CLKOE_Pos                    20
#define SDIO_SD_CR_CLKOE                        ((uint32_t)0x00100000)


/** @} */ /* End of group Periph_SDIO_SDIO_SD_CR_Bits */

/** @} */ /* End of group Periph_SDIO_Defines */

/** @defgroup Periph_SDIO_Defines Defines
  * @{
  */

/** @defgroup Periph_SDIO_SDIO_SD_SR_Bits SDIO_SD_SR
  * @{
  */

#define SDIO_SD_SR_FIFODAT_FULL_Pos             0
#define SDIO_SD_SR_FIFODAT_FULL                 ((uint32_t)0x00000001)

#define SDIO_SD_SR_FIFOCMD_FULL_Pos             1
#define SDIO_SD_SR_FIFOCMD_FULL                 ((uint32_t)0x00000002)

#define SDIO_SD_SR_FIFODAT_EMPTY_Pos            2
#define SDIO_SD_SR_FIFODAT_EMPTY                ((uint32_t)0x00000004)

#define SDIO_SD_SR_FIFOCMD_EMPTY_Pos            3
#define SDIO_SD_SR_FIFOCMD_EMPTY                ((uint32_t)0x00000008)


/** @} */ /* End of group Periph_SDIO_SDIO_SD_SR_Bits */

/** @} */ /* End of group Periph_SDIO_Defines */

/** @} */ /* End of group Periph_SDIO */

/** @} */ /* End of group __1901BC1F_Peripheral_Units */

/** @} */ /* End of group __CMSIS */

#endif /* __1901BC1F_SDIO_DEFS_H */

/******************* (C) COPYRIGHT 2010 Phyton *********************************
*
* END OF FILE 1901BC1F_sdio_defs.h */
