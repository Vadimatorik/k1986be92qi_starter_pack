/**
  ******************************************************************************
  * @file    1901BC1F_dsp_bsp_defs.h
  * @author  Phyton Application Team
  * @version V1.0.0
  * @date    14/01/2011
  * @brief   This file contains all the Special Function Registers definitions
  *          for the DSP_BSP peripheral unit used in the Milandr 1901BC1F
  *          microcontrollers.
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, PHYTON SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2010 Phyton</center></h2>
  ******************************************************************************
  * FILE 1901BC1F_dsp_bsp_defs.h
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __1901BC1F_DSP_BSP_DEFS_H
#define __1901BC1F_DSP_BSP_DEFS_H

/** @addtogroup __CMSIS CMSIS
  * @{
  */

/** @addtogroup __1901BC1F_Peripheral_Units 1901BC1F Peripheral Units
  * @{
  */

/** @defgroup Periph_DSP_BSP DSP_BSP
  * @{
  */

/** @defgroup Periph_DSP_BSP_Data_Structures Data Structures
  * @{
  */

/** @defgroup Periph_DSP_BSP_TypeDef DSP_BSP_TypeDef
  * @{
  */

typedef struct
{
  __IO uint32_t DDR;
  __IO uint32_t DXR;
  __IO uint32_t SPSA;
  __IO uint32_t CtrlD;
}DSP_BSP_TypeDef;

/** @} */ /* End of group Periph_DSP_BSP_TypeDef */

/** @} */ /* End of group Periph_DSP_BSP_Data_Structures */

/** @} */ /* End of group Periph_DSP_BSP */

/** @} */ /* End of group __1901BC1F_Peripheral_Units */

/** @} */ /* End of group __CMSIS */

#endif /* __1901BC1F_DSP_BSP_DEFS_H */

/******************* (C) COPYRIGHT 2010 Phyton *********************************
*
* END OF FILE 1901BC1F_dsp_bsp_defs.h */
