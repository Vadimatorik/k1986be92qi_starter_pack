/**
  ******************************************************************************
  * @file    1901BC1F_dsp_crpt_defs.h
  * @author  Phyton Application Team
  * @version V1.0.0
  * @date    14/01/2011
  * @brief   This file contains all the Special Function Registers definitions
  *          for the DSP_CRPT peripheral unit used in the Milandr 1901BC1F
  *          microcontrollers.
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, PHYTON SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2010 Phyton</center></h2>
  ******************************************************************************
  * FILE 1901BC1F_dsp_crpt_defs.h
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __1901BC1F_DSP_CRPT_DEFS_H
#define __1901BC1F_DSP_CRPT_DEFS_H

/** @addtogroup __CMSIS CMSIS
  * @{
  */

/** @addtogroup __1901BC1F_Peripheral_Units 1901BC1F Peripheral Units
  * @{
  */

/** @defgroup Periph_DSP_CRPT DSP_CRPT
  * @{
  */

/** @defgroup Periph_DSP_CRPT_Data_Structures Data Structures
  * @{
  */

/** @defgroup Periph_DSP_CRPT_TypeDef DSP_CRPT_TypeDef
  * @{
  */

typedef struct
{
  __IO uint32_t CWR;
  __IO uint32_t SR;
  __IO uint32_t DATA;
  __IO uint32_t KR;
  __IO uint32_t SYNR;
  __IO uint32_t CR;
  __IO uint32_t IMIT;
  __IO uint32_t ITER;
}DSP_CRPT_TypeDef;

/** @} */ /* End of group Periph_DSP_CRPT_TypeDef */

/** @} */ /* End of group Periph_DSP_CRPT_Data_Structures */

/** @defgroup Periph_DSP_CRPT_Defines Defines
  * @{
  */

/** @defgroup Periph_DSP_CRPT_DSP_CRPT_CWR_Bits DSP_CRPT_CWR
  * @{
  */

#define DSP_CRPT_CWR_MODE0_CRPT_Pos             0
#define DSP_CRPT_CWR_MODE0_CRPT                 ((uint32_t)0x00000001)

#define DSP_CRPT_CWR_MODE1_CRPT_Pos             1
#define DSP_CRPT_CWR_MODE1_CRPT                 ((uint32_t)0x00000002)

#define DSP_CRPT_CWR_IM_Pos                     2
#define DSP_CRPT_CWR_IM                         ((uint32_t)0x00000004)

#define DSP_CRPT_CWR_START_Pos                  3
#define DSP_CRPT_CWR_START                      ((uint32_t)0x00000008)

#define DSP_CRPT_CWR_DIR_Pos                    4
#define DSP_CRPT_CWR_DIR                        ((uint32_t)0x00000010)

#define DSP_CRPT_CWR_IE_CRPT_Pos                5
#define DSP_CRPT_CWR_IE_CRPT                    ((uint32_t)0x00000020)

#define DSP_CRPT_CWR_RST_Pos                    6
#define DSP_CRPT_CWR_RST                        ((uint32_t)0x00000040)

#define DSP_CRPT_CWR_BIST_Pos                   7
#define DSP_CRPT_CWR_BIST                       ((uint32_t)0x00000080)


/** @} */ /* End of group Periph_DSP_CRPT_DSP_CRPT_CWR_Bits */

/** @} */ /* End of group Periph_DSP_CRPT_Defines */

/** @defgroup Periph_DSP_CRPT_Defines Defines
  * @{
  */

/** @defgroup Periph_DSP_CRPT_DSP_CRPT_SR_Bits DSP_CRPT_SR
  * @{
  */

#define DSP_CRPT_SR_READY_CRPT_Pos              0
#define DSP_CRPT_SR_READY_CRPT                  ((uint32_t)0x00000001)

#define DSP_CRPT_SR_ERROR_CRPT_Pos              1
#define DSP_CRPT_SR_ERROR_CRPT                  ((uint32_t)0x00000002)

#define DSP_CRPT_SR_KF_Pos                      2
#define DSP_CRPT_SR_KF                          ((uint32_t)0x00000004)

#define DSP_CRPT_SR_DW_Pos                      3
#define DSP_CRPT_SR_DW                          ((uint32_t)0x00000008)

#define DSP_CRPT_SR_DR_Pos                      4
#define DSP_CRPT_SR_DR                          ((uint32_t)0x00000010)

#define DSP_CRPT_SR_SW_Pos                      5
#define DSP_CRPT_SR_SW                          ((uint32_t)0x00000020)

#define DSP_CRPT_SR_KW_Pos                      6
#define DSP_CRPT_SR_KW                          ((uint32_t)0x00000040)

#define DSP_CRPT_SR_DNC_BIST_Pos                7
#define DSP_CRPT_SR_DNC_BIST                    ((uint32_t)0x00000080)


/** @} */ /* End of group Periph_DSP_CRPT_DSP_CRPT_SR_Bits */

/** @} */ /* End of group Periph_DSP_CRPT_Defines */

/** @defgroup Periph_DSP_CRPT_Defines Defines
  * @{
  */

/** @defgroup Periph_DSP_CRPT_DSP_CRPT_ITER_Bits DSP_CRPT_ITER
  * @{
  */

#define DSP_CRPT_ITER_ITER0_Pos                 0
#define DSP_CRPT_ITER_ITER0                     ((uint32_t)0x00000001)

#define DSP_CRPT_ITER_ITER1_Pos                 1
#define DSP_CRPT_ITER_ITER1                     ((uint32_t)0x00000002)

#define DSP_CRPT_ITER_ITER2_Pos                 2
#define DSP_CRPT_ITER_ITER2                     ((uint32_t)0x00000004)

#define DSP_CRPT_ITER_ITER3_Pos                 3
#define DSP_CRPT_ITER_ITER3                     ((uint32_t)0x00000008)

#define DSP_CRPT_ITER_ITER4_Pos                 4
#define DSP_CRPT_ITER_ITER4                     ((uint32_t)0x00000010)

#define DSP_CRPT_ITER_ITER5_Pos                 5
#define DSP_CRPT_ITER_ITER5                     ((uint32_t)0x00000020)

#define DSP_CRPT_ITER_EN_CRPT_Pos               6
#define DSP_CRPT_ITER_EN_CRPT                   ((uint32_t)0x00000040)


/** @} */ /* End of group Periph_DSP_CRPT_DSP_CRPT_ITER_Bits */

/** @} */ /* End of group Periph_DSP_CRPT_Defines */

/** @} */ /* End of group Periph_DSP_CRPT */

/** @} */ /* End of group __1901BC1F_Peripheral_Units */

/** @} */ /* End of group __CMSIS */

#endif /* __1901BC1F_DSP_CRPT_DEFS_H */

/******************* (C) COPYRIGHT 2010 Phyton *********************************
*
* END OF FILE 1901BC1F_dsp_crpt_defs.h */
