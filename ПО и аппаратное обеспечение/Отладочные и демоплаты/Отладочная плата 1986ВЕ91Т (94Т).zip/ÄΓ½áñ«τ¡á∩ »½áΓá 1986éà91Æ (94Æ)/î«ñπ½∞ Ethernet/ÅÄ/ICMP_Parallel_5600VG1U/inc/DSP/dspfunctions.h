
#ifndef __DSPFUNCTIONS_H
#define	__DSPFUNCTIONS_H

void DownloadProgrammDSP(const uint16_t*, uint32_t,uint32_t);
void ClearRAMDSP(void);
void DownloadRAMDSP(const uint16_t*, uint32_t, uint32_t);

#endif	//__DSPFUNCTIONS_H

