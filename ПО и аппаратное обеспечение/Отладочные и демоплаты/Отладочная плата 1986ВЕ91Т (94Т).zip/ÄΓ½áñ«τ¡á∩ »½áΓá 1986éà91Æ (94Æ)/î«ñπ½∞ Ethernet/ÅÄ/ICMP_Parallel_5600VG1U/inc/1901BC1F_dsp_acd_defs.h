/**
  ******************************************************************************
  * @file    1901BC1F_dsp_acd_defs.h
  * @author  Phyton Application Team
  * @version V1.0.0
  * @date    14/01/2011
  * @brief   This file contains all the Special Function Registers definitions
  *          for the DSP_ACD peripheral unit used in the Milandr 1901BC1F
  *          microcontrollers.
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, PHYTON SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2010 Phyton</center></h2>
  ******************************************************************************
  * FILE 1901BC1F_dsp_acd_defs.h
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __1901BC1F_DSP_ACD_DEFS_H
#define __1901BC1F_DSP_ACD_DEFS_H

/** @addtogroup __CMSIS CMSIS
  * @{
  */

/** @addtogroup __1901BC1F_Peripheral_Units 1901BC1F Peripheral Units
  * @{
  */

/** @defgroup Periph_DSP_ACD DSP_ACD
  * @{
  */

/** @defgroup Periph_DSP_ACD_Data_Structures Data Structures
  * @{
  */

/** @defgroup Periph_DSP_ACD_TypeDef DSP_ACD_TypeDef
  * @{
  */

typedef struct
{
  __IO uint32_t POWCTL;
  __IO uint32_t ADCCTL;
  __IO uint32_t DACCTL;
  __IO uint32_t MASKCTL;
  __IO uint32_t IRQFLAG;
  __IO uint32_t ADCREG;
  __IO uint32_t DACREG;
}DSP_ACD_TypeDef;

/** @} */ /* End of group Periph_DSP_ACD_TypeDef */

/** @} */ /* End of group Periph_DSP_ACD_Data_Structures */

/** @defgroup Periph_DSP_ACD_Defines Defines
  * @{
  */

/** @defgroup Periph_DSP_ACD_DSP_ACD_POWCTL_Bits DSP_ACD_POWCTL
  * @{
  */

#define DSP_ACD_POWCTL_ADCEN_Pos                0
#define DSP_ACD_POWCTL_ADCEN                    ((uint32_t)0x00000001)

#define DSP_ACD_POWCTL_DACEN_Pos                1
#define DSP_ACD_POWCTL_DACEN                    ((uint32_t)0x00000002)

#define DSP_ACD_POWCTL_IIREN_Pos                2
#define DSP_ACD_POWCTL_IIREN                    ((uint32_t)0x00000004)


/** @} */ /* End of group Periph_DSP_ACD_DSP_ACD_POWCTL_Bits */

/** @} */ /* End of group Periph_DSP_ACD_Defines */

/** @defgroup Periph_DSP_ACD_Defines Defines
  * @{
  */

/** @defgroup Periph_DSP_ACD_DSP_ACD_ADCCTL_Bits DSP_ACD_ADCCTL
  * @{
  */

#define DSP_ACD_ADCCTL_ADGGAIN0_Pos             0
#define DSP_ACD_ADCCTL_ADGGAIN0                 ((uint32_t)0x00000001)

#define DSP_ACD_ADCCTL_ADGGAIN1_Pos             1
#define DSP_ACD_ADCCTL_ADGGAIN1                 ((uint32_t)0x00000002)

#define DSP_ACD_ADCCTL_ADGGAIN2_Pos             2
#define DSP_ACD_ADCCTL_ADGGAIN2                 ((uint32_t)0x00000004)

#define DSP_ACD_ADCCTL_ADGGAIN3_Pos             3
#define DSP_ACD_ADCCTL_ADGGAIN3                 ((uint32_t)0x00000008)

#define DSP_ACD_ADCCTL_ADGGAIN4_Pos             4
#define DSP_ACD_ADCCTL_ADGGAIN4                 ((uint32_t)0x00000010)

#define DSP_ACD_ADCCTL_ADGGAIN5_Pos             5
#define DSP_ACD_ADCCTL_ADGGAIN5                 ((uint32_t)0x00000020)

#define DSP_ACD_ADCCTL_INBG0_Pos                6
#define DSP_ACD_ADCCTL_INBG0                    ((uint32_t)0x00000040)

#define DSP_ACD_ADCCTL_INBG1_Pos                7
#define DSP_ACD_ADCCTL_INBG1                    ((uint32_t)0x00000080)

#define DSP_ACD_ADCCTL_AINSEL0_Pos              8
#define DSP_ACD_ADCCTL_AINSEL0                  ((uint32_t)0x00000100)

#define DSP_ACD_ADCCTL_AINSEL1_Pos              9
#define DSP_ACD_ADCCTL_AINSEL1                  ((uint32_t)0x00000200)

#define DSP_ACD_ADCCTL_ODADC_Pos                10
#define DSP_ACD_ADCCTL_ODADC                    ((uint32_t)0x00000400)

#define DSP_ACD_ADCCTL_ICONT_Pos                11
#define DSP_ACD_ADCCTL_ICONT                    ((uint32_t)0x00000800)

#define DSP_ACD_ADCCTL_ADCRES_Pos               12
#define DSP_ACD_ADCCTL_ADCRES                   ((uint32_t)0x00001000)


/** @} */ /* End of group Periph_DSP_ACD_DSP_ACD_ADCCTL_Bits */

/** @} */ /* End of group Periph_DSP_ACD_Defines */

/** @defgroup Periph_DSP_ACD_Defines Defines
  * @{
  */

/** @defgroup Periph_DSP_ACD_DSP_ACD_DACCTL_Bits DSP_ACD_DACCTL
  * @{
  */

#define DSP_ACD_DACCTL_DAGAIN0_Pos              0
#define DSP_ACD_DACCTL_DAGAIN0                  ((uint32_t)0x00000001)

#define DSP_ACD_DACCTL_DAGGAIN1_Pos             1
#define DSP_ACD_DACCTL_DAGGAIN1                 ((uint32_t)0x00000002)

#define DSP_ACD_DACCTL_DAGGAIN2_Pos             2
#define DSP_ACD_DACCTL_DAGGAIN2                 ((uint32_t)0x00000004)

#define DSP_ACD_DACCTL_DAGGAIN3_Pos             3
#define DSP_ACD_DACCTL_DAGGAIN3                 ((uint32_t)0x00000008)

#define DSP_ACD_DACCTL_DAGGAIN4_Pos             4
#define DSP_ACD_DACCTL_DAGGAIN4                 ((uint32_t)0x00000010)

#define DSP_ACD_DACCTL_DAGGAIN5_Pos             5
#define DSP_ACD_DACCTL_DAGGAIN5                 ((uint32_t)0x00000020)

#define DSP_ACD_DACCTL_MUTE1_Pos                6
#define DSP_ACD_DACCTL_MUTE1                    ((uint32_t)0x00000040)

#define DSP_ACD_DACCTL_ODAMP_Pos                7
#define DSP_ACD_DACCTL_ODAMP                    ((uint32_t)0x00000080)

#define DSP_ACD_DACCTL_ODBIAS_Pos               8
#define DSP_ACD_DACCTL_ODBIAS                   ((uint32_t)0x00000100)

#define DSP_ACD_DACCTL_ODDAC_Pos                9
#define DSP_ACD_DACCTL_ODDAC                    ((uint32_t)0x00000200)

#define DSP_ACD_DACCTL_OVECBF_Pos               10
#define DSP_ACD_DACCTL_OVECBF                   ((uint32_t)0x00000400)

#define DSP_ACD_DACCTL_OVECBS_Pos               11
#define DSP_ACD_DACCTL_OVECBS                   ((uint32_t)0x00000800)

#define DSP_ACD_DACCTL_SIDETON0_Pos             12
#define DSP_ACD_DACCTL_SIDETON0                 ((uint32_t)0x00001000)

#define DSP_ACD_DACCTL_SIDETON1_Pos             13
#define DSP_ACD_DACCTL_SIDETON1                 ((uint32_t)0x00002000)

#define DSP_ACD_DACCTL_SIDETON2_Pos             14
#define DSP_ACD_DACCTL_SIDETON2                 ((uint32_t)0x00004000)

#define DSP_ACD_DACCTL_DACRES_Pos               15
#define DSP_ACD_DACCTL_DACRES                   ((uint32_t)0x00008000)


/** @} */ /* End of group Periph_DSP_ACD_DSP_ACD_DACCTL_Bits */

/** @} */ /* End of group Periph_DSP_ACD_Defines */

/** @defgroup Periph_DSP_ACD_Defines Defines
  * @{
  */

/** @defgroup Periph_DSP_ACD_DSP_ACD_MASKCTL_Bits DSP_ACD_MASKCTL
  * @{
  */

#define DSP_ACD_MASKCTL_DAOVFM_Pos              0
#define DSP_ACD_MASKCTL_DAOVFM                  ((uint32_t)0x00000001)

#define DSP_ACD_MASKCTL_ADCVFM_Pos              1
#define DSP_ACD_MASKCTL_ADCVFM                  ((uint32_t)0x00000002)

#define DSP_ACD_MASKCTL_ADCNSM_Pos              2
#define DSP_ACD_MASKCTL_ADCNSM                  ((uint32_t)0x00000004)

#define DSP_ACD_MASKCTL_DACNSM_Pos              3
#define DSP_ACD_MASKCTL_DACNSM                  ((uint32_t)0x00000008)

#define DSP_ACD_MASKCTL_OVERCURM_Pos            4
#define DSP_ACD_MASKCTL_OVERCURM                ((uint32_t)0x00000010)


/** @} */ /* End of group Periph_DSP_ACD_DSP_ACD_MASKCTL_Bits */

/** @} */ /* End of group Periph_DSP_ACD_Defines */

/** @defgroup Periph_DSP_ACD_Defines Defines
  * @{
  */

/** @defgroup Periph_DSP_ACD_DSP_ACD_IRQFLAG_Bits DSP_ACD_IRQFLAG
  * @{
  */

#define DSP_ACD_IRQFLAG_DAOVF_Pos               0
#define DSP_ACD_IRQFLAG_DAOVF                   ((uint32_t)0x00000001)

#define DSP_ACD_IRQFLAG_ADCVF_Pos               1
#define DSP_ACD_IRQFLAG_ADCVF                   ((uint32_t)0x00000002)

#define DSP_ACD_IRQFLAG_ADCNS_Pos               2
#define DSP_ACD_IRQFLAG_ADCNS                   ((uint32_t)0x00000004)

#define DSP_ACD_IRQFLAG_DACNS_Pos               3
#define DSP_ACD_IRQFLAG_DACNS                   ((uint32_t)0x00000008)

#define DSP_ACD_IRQFLAG_OVERCUR_Pos             4
#define DSP_ACD_IRQFLAG_OVERCUR                 ((uint32_t)0x00000010)


/** @} */ /* End of group Periph_DSP_ACD_DSP_ACD_IRQFLAG_Bits */

/** @} */ /* End of group Periph_DSP_ACD_Defines */

/** @} */ /* End of group Periph_DSP_ACD */

/** @} */ /* End of group __1901BC1F_Peripheral_Units */

/** @} */ /* End of group __CMSIS */

#endif /* __1901BC1F_DSP_ACD_DEFS_H */

/******************* (C) COPYRIGHT 2010 Phyton *********************************
*
* END OF FILE 1901BC1F_dsp_acd_defs.h */
