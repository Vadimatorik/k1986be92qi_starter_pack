
#include "types.h"


typedef struct {
	__io_reg MAC_CTRL;
	__io_reg MinFrame;
	__io_reg MaxFrame;
	__io_reg CollConfig;
	__io_reg IPGTx;
	__io_reg MAC_ADDR_T;
	__io_reg MAC_ADDR_M;
	__io_reg MAC_ADDR_H;
	__io_reg HASH0;
	__io_reg HASH1;
	__io_reg HASH2;
	__io_reg HASH3;
	__io_reg INT_MSK;
	__io_reg INT_SRC;
	__io_reg PHY_CTRL;
	__io_reg PHY_STAT;
	__io_reg RXBF_HEAD;
	__io_reg RXBF_TAIL;
	__io_reg dammy0;
	__io_reg dammy1;
	__io_reg STAT_RX_ALL;
	__io_reg STAT_RX_OK;
	__io_reg STAT_RX_OVF;
	__io_reg STAT_RX_LOST;
	__io_reg STAT_TX_ALL;
	__io_reg STAT_TX_OK;
	__io_reg base_RxBF;
	__io_reg base_TxBF;
	__io_reg base_RxBD;
	__io_reg base_TxBD;
	__io_reg base_RG;
	__io_reg GCTRL;
} _ethernet;

// RX buffer base address
#define BASE_ETH_RXBF			   0x60000000 
// RX descriptor base address
#define BASE_ETH_RXDS			   0x60002000
// TX buffer base address
#define BASE_ETH_TXBF			   0x60004000 
// TX descriptor base address
#define BASE_ETH_TXDS			   0x60006000
// Control Reg Ethernet 
#define BASE_ETHERNET              0x60007F00

#define ETH1                  ((_ethernet *)BASE_ETHERNET)
#define ETH1RXBF              ((int *)BASE_ETH_RXBF) 
#define ETH1RXDC              ((int *)BASE_ETH_RXDS)
#define ETH1TXBF              ((int *)BASE_ETH_TXBF)
#define ETH1TXDC              ((int *)BASE_ETH_TXDS)


_ethernet TEST;

int main(void) 
{
int i;
 
RST_CLK->PER_CLOCK = 0xFFFFFFFF;
   
PORTB->ANALOG = 1<<11;
PORTB->PWR = 0xFFFFFFFF;
PORTB->RXTX = 0<<11;
PORTB->OE = 1<<11;
PORTB->OE = 0<<11;


PORTA->ANALOG = 0xFFFF; // Data 0-15
PORTB->ANALOG = 0xFFFF; // RESET
PORTC->ANALOG = 0xFFFF; // OE-WE
PORTD->ANALOG = 0xFFFF; // OE-WE
PORTE->ANALOG = 0xFFFF; // CS
PORTF->ANALOG = 0xFFFF; // ADDR[15-2]


PORTA->PWR = 0xFFFFFFFF; // Data 0-15
PORTB->PWR = 0xFFFFFFFF; // RESET
PORTC->PWR = 0xFFFFFFFF; // OE-WE
PORTE->PWR = 0xFFFFFFFF; // CS
PORTD->PWR = 0xFFFFFFFF; // CS
PORTF->PWR = 0xFFFFFFFF; // ADDR[15-2]

PORTA->FUNC = 0x55555555; // Data 0-15
PORTB->FUNC = 0x00000000; // RESET
PORTC->FUNC = 0x00000014; // OE-WE
PORTE->FUNC = 0x55555555; // CS
PORTF->FUNC = 0x55555550; // ADDR[15-2]

PORTD->FUNC = 0x55550000; // Leds

PORTC->PD   = 0x00000000; // OE-WE

// RESET;
PORTB->RXTX = 0<<11;
PORTB->OE = 1<<11;
PORTB->OE = 0<<11;

RST_CLK->TIM_CLOCK = 0x01000000;
TIMER1->ARR = 0x100;
TIMER1->PSG = 0xFFFF;
TIMER1->CNTRL = 0x001;
TIMER1->CCR1 = 0x050;
TIMER1->CCR2 = 0x050;

TIMER1->CH1_CNTRL = 0xE00;
TIMER1->CH2_CNTRL = 0xE00;

TIMER1->CH1_CNTRL1 = 0x00A;
TIMER1->CH2_CNTRL1 = 0x00A;





EXT_BUS_CNTRL->EXT_BUS_CONTROL = 0x2002; // EXT BUS ON

ETH1->GCTRL = 0x5382;

// test memory RXBUFFER
for (i=0;i<0x800;i++)
	ETH1RXBF[i] = i;
for (i=0;i<0x800;i++)
	if (ETH1RXBF[i] != i)
	{
		TIMER1->PSG = 0x00FF;		
		while (1) {};
	};

// test memory TXBUFFER
for (i=0;i<0x800;i++)
	ETH1TXBF[i] = i;
for (i=0;i<0x800;i++)
	if (ETH1TXBF[i] != i)
	{
		TIMER1->PSG = 0x00FF;		
		while (1) {};
	};

// test memory RX DESCR
for (i=0;i<0x80;i++)
	ETH1RXDC[i] = i;
for (i=0;i<0x80;i++)
	if (ETH1RXDC[i] != i)
	{
		TIMER1->PSG = 0x00FF;		
		while (1) {};
	};

// test memory RX DESCR
for (i=0;i<0x80;i++)
	ETH1TXDC[i] = i;
for (i=0;i<0x80;i++)
	if (ETH1TXDC[i] != i)
	{
		TIMER1->PSG = 0x00FF;		
		while (1) {};
	};
	

while (1){};

};

/*============================================================================================
 * ����� ����� Main.c
 *============================================================================================*/

